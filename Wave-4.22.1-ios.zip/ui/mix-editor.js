/* Wave 4.15: global mix editor. Actual audio analysis runs in mix-analysis.js. */
"use strict";
const MXUI = { index: 0, cache: new Map(), pending: new Map(), ctx: null };
const MX_MOBILE = document.documentElement.hasAttribute("data-mobile");
const MX_LIMIT = (MX_MOBILE ? 10 : 60) * 1024 * 1024;
let MX_ANALYSIS_TURN = Promise.resolve();
const MX_PRESETS = {
  auto: { vol: "overlap", eq: "mid", fx: "none" },
  fade: { vol: "fade", eq: "none", fx: "none" },
  rise: { vol: "overlap", eq: "end", fx: "lowpass" },
  blend: { vol: "overlap", eq: "mid", fx: "none" },
  echo: { vol: "fade", eq: "none", fx: "echo" },
  cut: { vol: "cut", eq: "none", fx: "none" },
};
function mxBarsLength(bars, bpm) {
  return Math.max(0.5, Math.min(40, ((+bars || 4) * 4 * 60) / (+bpm || 120)));
}
function mxPairSettings(p, i) {
  const a = p.tracks[i],
    b = p.tracks[i + 1];
  if (!a || !b) return null;
  const h = mixOf(p).tr[mixKey(a, b)] || {};
  return {
    style: h.style || "rise",
    bars: h.bars || 4,
    vol: h.vol || "overlap",
    eq: h.eq || "end",
    fx: h.fx || "lowpass",
    out: h.out || 0,
    in: h.in || 0,
    bpmA: h.bpmA || null,
    curveVol: h.curveVol || 50,
    curveEq: h.curveEq || 50,
    curveFx: h.curveFx || 50,
  };
}
function mxSave(p, i, changes) {
  const a = p.tracks[i],
    b = p.tracks[i + 1];
  if (!a || !b) return;
  mixPatch(p, { tr: { [mixKey(a, b)]: changes } });
}
function mxCacheLoad(id) {
  if (MXUI.cache.has(id)) return MXUI.cache.get(id);
  try {
    const all = JSON.parse(localStorage.getItem("wave.mix.analysis.v1") || "{}"),
      v = all[id];
    if (v && Array.isArray(v.peaks) && v.peaks.length === 320) {
      MXUI.cache.set(id, v);
      return v;
    }
  } catch {}
  return null;
}
function mxCacheSave(id, v) {
  MXUI.cache.set(id, v);
  try {
    let all = JSON.parse(localStorage.getItem("wave.mix.analysis.v1") || "{}");
    all[id] = v;
    const keys = Object.keys(all);
    while (keys.length > 60) delete all[keys.shift()];
    localStorage.setItem("wave.mix.analysis.v1", JSON.stringify(all));
  } catch {}
}
async function mxReadBytes(res) {
  if (!res.ok) throw Error("Сервер не отдал аудио");
  const len = +res.headers.get("content-length");
  if (len > MX_LIMIT) throw Error("Файл слишком большой для анализа");
  if (!res.body?.getReader) {
    const buf = await res.arrayBuffer();
    if (buf.byteLength > MX_LIMIT) throw Error("Файл слишком большой для анализа");
    return buf;
  }
  const reader = res.body.getReader(),
    parts = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > MX_LIMIT) {
        await reader.cancel();
        throw Error("Файл слишком большой для анализа");
      }
      parts.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const out = new Uint8Array(total);
  let at = 0;
  for (const part of parts) {
    out.set(part, at);
    at += part.length;
  }
  return out.buffer;
}
async function mxAnalyze(t) {
  const cached = mxCacheLoad(t.id);
  if (cached) return cached;
  if (MXUI.pending.has(t.id)) return MXUI.pending.get(t.id);
  const job = (async () => {
    let release;
    if (MX_MOBILE) { const previous = MX_ANALYSIS_TURN; MX_ANALYSIS_TURN = new Promise((r) => (release = r)); await previous; }
    try {
    // SoundCloud supplies an actual amplitude envelope without downloading or decoding the HLS audio.
    if (/^sc:[0-9]+$/.test(t.id)) {
      const wave = await api("mix-waveform", { id: t.id }).catch(() => null);
      if (wave?.peaks?.length === 320) {
        wave.duration ||= t.duration || 0;
        mxCacheSave(t.id, wave);
        return wave;
      }
    }
    const stream = await api("stream", { track: t, prefetch: true });
    if (/^sc:[0-9]+$/.test(stream?.via?.id || "")) {
      const wave = await api("mix-waveform", { id: stream.via.id }).catch(() => null);
      if (wave?.peaks?.length === 320) {
        wave.duration ||= t.duration || 0;
        mxCacheSave(t.id, wave);
        return wave;
      }
    }
    if (!stream?.url || stream.type === "hls") throw Error("Волна для этого потока недоступна");
    if (MX_MOBILE && (!t.duration || t.duration > 240)) throw Error("Анализ длинного аудио ограничен на телефоне");
    const response = await fetch(stream.url, { signal: AbortSignal.timeout(30000) });
    const bytes = await mxReadBytes(response);
    const C = window.AudioContext || window.webkitAudioContext;
    if (!C) throw Error("Нет декодера аудио");
    const ctx = MXUI.ctx || (MXUI.ctx = new C());
    const audioBuffer = await ctx.decodeAudioData(bytes);
    if (audioBuffer.duration > 900) throw Error("Трек слишком длинный для анализа");
    // Copy samples once, then resample and analyze off the renderer thread.
    const channels = Array.from({ length: Math.min(2, audioBuffer.numberOfChannels) }, (_, i) =>
      audioBuffer.getChannelData(i).slice(),
    );
    const value = await new Promise((resolve, reject) => {
      const w = new Worker("mix-analysis.js");
      const timer = setTimeout(() => {
        w.terminate();
        reject(Error("Анализ занял слишком много времени"));
      }, 30000);
      w.onmessage = (e) => {
        clearTimeout(timer);
        w.terminate();
        e.data.error ? reject(Error(e.data.error)) : resolve(e.data.result);
      };
      w.onerror = () => {
        clearTimeout(timer);
        w.terminate();
        reject(Error("Ошибка анализа"));
      };
      w.postMessage(
        { channels, inputRate: audioBuffer.sampleRate },
        channels.map((x) => x.buffer),
      );
    });
    mxCacheSave(t.id, value);
    return value;
    } finally { release?.(); }
  })().finally(() => MXUI.pending.delete(t.id));
  MXUI.pending.set(t.id, job);
  return job;
}
function mxWave(info, part, offset = 0) {
  if (!info) return '<div class="me-loading">Анализ аудио…</div>';
  if (info.error && !info.peaks) return `<div class="me-loading">Волна недоступна · переход работает без неё</div>`;
  const peaks = info.peaks,
    duration = info.duration || 1,
    count = peaks.length,
    span = Math.max(1, Math.round(count * 0.3));
  const shift = Math.round((offset / duration) * count);
  const end = part === "a" ? Math.max(1, count - shift) : Math.min(count, shift + span);
  const start = part === "a" ? Math.max(0, end - span) : Math.max(0, Math.min(count - 1, shift));
  const p = peaks.slice(start, end),
    width = 600,
    step = width / p.length;
  return `<svg viewBox="0 0 600 100" preserveAspectRatio="none" aria-label="Волновая форма"><path class="me-grid" d="M0 50H600 M150 0V100 M300 0V100 M450 0V100"/><path class="me-peaks" d="${p
    .map((v, i) => {
      const h = Math.max(1, Math.min(46, v * 90));
      const x = (i * step).toFixed(1);
      return `M${x} ${(50 - h).toFixed(1)}V${(50 + h).toFixed(1)}`;
    })
    .join(" ")}"/></svg>`;
}
function mxCurves(h, part) {
  const shape = mixCustomShape(h);
  const path = (fn) =>
    Array.from(
      { length: 49 },
      (_, i) =>
        `${i ? "L" : "M"}${((i * 600) / 48).toFixed(1)} ${(88 - Math.max(0, Math.min(1, fn(i / 48))) * 76).toFixed(1)}`,
    ).join(" ");
  const eq = shape.aLo ? (x) => -shape.aLo(x) / 24 : () => 0;
  const fx = shape.aLp
    ? (x) => Math.log(20000 / shape.aLp(x)) / Math.log(20000 / 350)
    : shape.bHp
      ? (x) => Math.log(1800 / shape.bHp(x)) / Math.log(1800 / 20)
      : shape.send || (() => 0);
  return `<svg class="me-curves" viewBox="0 0 600 100" preserveAspectRatio="none" aria-hidden="true"><path class="vol" d="${path(part === "a" ? shape.a : shape.b)}"/><path class="eq" d="${path(eq)}"/><path class="fx" d="${path(fx)}"/></svg>`;
}
function mxMeta(t, info) {
  return `<span class="me-cover" ${t.cover ? bg(t.cover, "s") : ""}>${t.cover ? "" : icon("note")}</span><span class="me-meta"><b>${esc(t.title)}</b><small>${esc(t.artist || "Неизвестный исполнитель")}</small></span><span class="me-tempo">${info?.bpm ? `≈ ${info.bpm} BPM` : "BPM —"}</span><span class="me-key">${info?.key?.camelot ? esc(info.key.camelot) : "—"}</span><span>${fmt(t.duration || info?.duration || 0)}</span>`;
}
function mxOption(value, opts) {
  return opts.map(([v, label]) => `<option value="${v}"${v === value ? " selected" : ""}>${label}</option>`).join("");
}
const MX_TIPS = {
  bars: "Длина наложения в тактах. Если темп неизвестен, расчёт временно использует 120 BPM.",
  vol: {
    overlap: "Треки ненадолго звучат вместе: второй появляется раньше, чем затихает первый.",
    fade: "Плавно уменьшает громкость первого трека и увеличивает громкость второго.",
    cut: "Переключает громкость почти мгновенно, без плавного смешивания.",
  },
  eq: {
    none: "Не меняет частоты треков.",
    mid: "Меняет бас между треками примерно в середине перехода.",
    end: "Оставляет бас первого трека дольше и передаёт его второму ближе к концу.",
  },
  fx: {
    none: "Не добавляет звуковых эффектов.",
    lowpass: "Постепенно приглушает высокие частоты первого трека, будто звук уходит под воду.",
    highpass: "Второй трек начинается с высоких частот; низкие частоты постепенно возвращаются.",
    echo: "Добавляет затухающее эхо к первому треку.",
  },
  presets: {
    auto: "Автоматический переход: может начать раньше на тихой концовке.",
    fade: "Обычный плавный кроссфейд без дополнительных эффектов.",
    rise: "Второй трек плавно появляется, первый уходит с фильтром низких частот.",
    blend: "Треки накладываются друг на друга, бас меняется в середине.",
    echo: "Первый трек уходит с эхом.",
    cut: "Склеивает треки почти без наложения.",
  },
};
function mxTip(text) {
  return `data-tip="${esc(text)}"`;
}
function mxSyncPlayhead() {
  const stage = document.querySelector(".me-stage"),
    play = document.querySelector('[data-me="hear"]');
  if (!stage || !play || !globalMix().tracks.length) return;
  const p = globalMix(),
    i = MXUI.index,
    a = p.tracks[i],
    b = p.tracks[i + 1],
    h = mxPairSettings(p, i);
  const active = !!(
    a &&
    b &&
    S.ctx?.preview &&
    S.ctx?.pair === mixKey(a, b) &&
    (S.current?.id === a.id || S.current?.id === b.id)
  );
  play.innerHTML = icon(active && !audio.paused ? "pause" : "play");
  play.title = active && !audio.paused ? "Пауза" : active ? "Продолжить переход" : "Прослушать переход";
  play.setAttribute("aria-label", play.title);
  const line = stage.querySelector(".me-playhead");
  if (!line) return;
  line.hidden = !active;
  if (!active) return;
  const len = Math.max(0.06, mixPair(a, b, mixOf(p)).len || 0.06),
    duration = curDur(),
    now = audio.currentTime || 0;
  const pos = S.current.id === a.id ? (now - (duration - h.out - len)) / len : (now - h.in) / len;
  line.style.left = `${Math.max(0, Math.min(100, pos * 100))}%`;
}
function globalMixEditor() {
  const was = document.querySelector(".me-page"),
    scroll = was ? document.querySelector("#content").scrollTop : 0,
    listOpen = !!was?.querySelector(".me-list-wrap")?.open,
    focusKey = was?.contains(document.activeElement) ? document.activeElement?.dataset?.meSelect : null;
  const p = globalMix(),
    list = p.tracks;
  for (let k = 0; k < list.length - 1; k++) {
    const saved = mixOf(p).tr[mixKey(list[k], list[k + 1])] || {};
    if (!(Number.isFinite(+saved.bars) && +saved.bars > 0)) {
      const style = MX_PRESETS[saved.style] ? saved.style : "rise";
      mxSave(p, k, { style, ...MX_PRESETS[style], bars: 4 });
    }
  }
  MXUI.index = Math.max(0, Math.min(MXUI.index, Math.max(0, list.length - 2)));
  const i = MXUI.index,
    a = list[i],
    b = list[i + 1],
    h = mxPairSettings(p, i);
  const infos = [a, b].map((t) => (t ? MXUI.cache.get(t.id) || mxCacheLoad(t.id) : null));
  const tracks = list
    .map(
      (t, k) =>
        `<div class="me-listrow"><span>${k + 1}</span><b>${esc(t.title)}</b><small>${esc(t.artist || "")}</small><button data-move="${k}" data-dir="-1" ${k === 0 ? "disabled" : ""} title="Вверх">↑</button><button data-move="${k}" data-dir="1" ${k === list.length - 1 ? "disabled" : ""} title="Вниз">↓</button><button data-remove="${k}" title="Убрать">×</button></div>`,
    )
    .join("");
  const choices = (name, val, items) =>
    `<label class="me-field" tabindex="0" ${mxTip(MX_TIPS[name][val])}><span>${{ vol: "Громкость", eq: "Бас", fx: "Эффект" }[name]} <i aria-hidden="true">ⓘ</i></span><select data-me-select="${name}" aria-label="${{ vol: "Громкость", eq: "Бас", fx: "Эффект" }[name]}">${mxOption(val, items)}</select></label>`;
  setContent(
    `<div class="me-page"><div class="me-top"><div><h1 class="page">Микс</h1><p class="page-sub">Треки идут друг за другом, плавно переходя один в другой.</p></div><div class="me-actions">${list.length ? '<button class="btn acc" data-me="play">Слушать микс</button>' : ""}<button class="btn" data-me="search">Добавить треки</button></div></div>${list.length ? `<details class="me-list-wrap" ${listOpen ? "open" : ""}><summary>Треки в миксе · ${list.length} <span>Изменить порядок</span></summary><div class="me-list">${tracks}</div></details>` : '<div class="empty"><b>Пока нет треков</b>Добавьте композиции через пункт «Микс» в меню трека.</div>'}${
      list.length < 2
        ? '<div class="empty">Добавьте хотя бы два трека для перехода</div>'
        : `<div class="me-section-title"><b>Переход</b><span>Выберите пару и настройте её звучание</span></div><div class="me-pairs">${list
            .slice(0, -1)
            .map(
              (t, k) =>
                `<button data-pair="${k}" class="${k === i ? "on" : ""}">${esc(t.title)} → ${esc(list[k + 1].title)}</button>`,
            )
            .join(
              "",
            )}</div><section class="me-editor"><div class="me-track me-track-top">${mxMeta(a, infos[0])}</div><div class="me-stage"><div class="me-wave a" data-wave="a" title="Перетащите, чтобы изменить конец первого трека">${mxWave(infos[0], "a", h.out)}${mxCurves(h, "a")}<span>A</span></div><div class="me-wave b" data-wave="b" title="Перетащите, чтобы изменить начало второго трека">${mxWave(infos[1], "b", h.in)}${mxCurves(h, "b")}<span>B</span></div><i class="me-playhead" hidden></i><button class="me-play" data-me="hear" title="Прослушать переход" aria-label="Прослушать переход">${icon("play")}</button><label class="me-bars" ${mxTip(MX_TIPS.bars)}><select data-me-select="bars" aria-label="Длина перехода">${[1, 2, 4, 8, 16].map((n) => `<option value="${n}"${n === h.bars ? " selected" : ""}>${n} такт${n === 1 ? "" : n < 5 ? "а" : "ов"}</option>`).join("")}</select></label></div><div class="me-track me-track-bottom">${mxMeta(b, infos[1])}</div><p class="me-hint">${h.bpmA ? `≈ ${mxBarsLength(h.bars, h.bpmA).toFixed(1)} с · ${h.bpmA} BPM` : `≈ ${mxBarsLength(h.bars, 120).toFixed(1)} с · расчёт по 120 BPM`}. Перетащите волну, чтобы изменить место перехода. <span>Конец A: −${h.out.toFixed(1)} с · начало B: ${h.in.toFixed(1)} с</span></p><div class="me-legend"><span>● Громкость</span><span>● Бас</span><span>● Эффект</span></div><div class="me-controls">${choices(
            "vol",
            h.vol,
            [
              ["overlap", "Overlap"],
              ["fade", "Crossfade"],
              ["cut", "Cut"],
            ],
          )}${choices("eq", h.eq, [
            ["none", "Без EQ"],
            ["mid", "Bass swap"],
            ["end", "End bass swap"],
          ])}${choices("fx", h.fx, [
            ["none", "Без эффекта"],
            ["lowpass", "Low pass"],
            ["highpass", "High pass"],
            ["echo", "Echo"],
          ])}</div><div class="me-curve-controls"><b>Форма кривых</b><small>Двигайте ползунки, чтобы изменить момент перехода</small><div>${[
            ["curveVol", "Громкость"],
            ["curveEq", "Бас"],
            ["curveFx", "Эффект"],
          ]
            .map(
              ([key, label]) =>
                `<label>${label}<input type="range" data-curve="${key}" min="10" max="90" step="1" value="${h[key]}" aria-label="Момент: ${label}"><span>${h[key]}%</span></label>`,
            )
            .join("")}</div></div><div class="me-presets">${[
            ["auto", "Auto"],
            ["fade", "Fade"],
            ["rise", "Rise"],
            ["blend", "Blend"],
            ["echo", "Echo"],
            ["cut", "Cut"],
          ]
            .map(
              ([v, n]) =>
                `<button data-preset="${v}" ${mxTip(MX_TIPS.presets[v])} class="${h.style === v ? "on" : ""}">${n}</button>`,
            )
            .join(
              "",
            )}</div><p class="me-note">Наведите на настройки, чтобы узнать больше. ${infos.some((x) => x?.error) ? '<button class="me-retry" data-me="retry">Повторить анализ</button> · ' : ""}Темп определяется приблизительно при анализе файла или после 30 секунд прослушивания в миксе; EQ и эффекты требуют Web Audio.</p></section>`
    }</div>`,
  );
  const page = $(".me-page");
  if (was) $("#content").scrollTop = scroll;
  if (focusKey) page.querySelector(`[data-me-select="${focusKey}"]`)?.focus({ preventScroll: true });
  page.onclick = (e) => {
    const x = e.target.closest("button");
    if (!x) return;
    if (x.dataset.me === "search") return go("search");
    if (x.dataset.me === "play") {
      S.shuffle = false;
      if (S.repeat === "one") S.repeat = "off";
      syncModes();
      return playList(list, 0, { title: "Микс", go: "mix:@all" });
    }
    if (x.dataset.me === "hear") {
      if (S.ctx?.preview && S.ctx?.pair === mixKey(a, b) && [a.id, b.id].includes(S.current?.id)) {
        togglePlay();
        mxSyncPlayhead();
        return;
      }
      return mixHear(p, i);
    }
    if (x.dataset.me === "retry") {
      for (const t of [a, b]) if (t && MXUI.cache.get(t.id)?.error) MXUI.cache.delete(t.id);
      return globalMixEditor();
    }
    if (x.dataset.pair !== undefined) {
      MXUI.index = +x.dataset.pair;
      return globalMixEditor();
    }
    if (x.dataset.remove !== undefined) {
      list.splice(+x.dataset.remove, 1);
      saveGlobalMix();
      return globalMixEditor();
    }
    if (x.dataset.move !== undefined) {
      const j = +x.dataset.move,
        k = j + +x.dataset.dir;
      if (k >= 0 && k < list.length) [list[j], list[k]] = [list[k], list[j]];
      saveGlobalMix();
      return globalMixEditor();
    }
    if (x.dataset.preset) {
      const style = x.dataset.preset;
      mxSave(p, i, {
        style,
        ...MX_PRESETS[style],
        bars: h.bars,
        bpmA: h.bpmA,
        curveVol: null,
        curveEq: null,
        curveFx: null,
      });
      globalMixEditor();
    }
  };
  page.onchange = (e) => {
    const key = e.target.dataset.meSelect;
    if (!key || !h) return;
    let value = e.target.value;
    if (key === "bars") value = +value;
    mxSave(p, i, {
      [key]: value,
      bars: key === "bars" ? value : h.bars,
      style: key === "bars" ? h.style : "custom",
      bpmA: h.bpmA,
    });
    globalMixEditor();
  };
  page.querySelectorAll("[data-curve]").forEach((el) => {
    el.oninput = () => {
      h[el.dataset.curve] = +el.value;
      el.nextElementSibling.textContent = el.value + "%";
      for (const wave of page.querySelectorAll("[data-wave]"))
        wave.querySelector(".me-curves").outerHTML = mxCurves(h, wave.dataset.wave);
    };
    el.onchange = () => {
      mxSave(p, i, { [el.dataset.curve]: +el.value, style: "custom", bars: h.bars, bpmA: h.bpmA });
    };
  });
  page.querySelectorAll("[data-wave]").forEach((el) => {
    el.onpointerdown = (e) => {
      if (e.button !== 0) return;
      const part = el.dataset.wave,
        initial = part === "a" ? h.out : h.in,
        start = e.clientX,
        width = el.clientWidth,
        beat = 60 / ((part === "a" ? infos[0]?.bpm : infos[1]?.bpm) || 0);
      let value = initial;
      el.setPointerCapture(e.pointerId);
      el.onpointermove = (ev) => {
        value = Math.max(0, Math.min(30, initial + ((ev.clientX - start) / width) * 30 * (part === "a" ? -1 : 1)));
        if (Number.isFinite(beat)) value = Math.round(value / beat) * beat;
      };
      el.onpointerup = () => {
        mxSave(p, i, {
          [part === "a" ? "out" : "in"]: Math.round(value * 10) / 10,
          bars: h.bars,
          style: h.style,
          bpmA: h.bpmA,
        });
        globalMixEditor();
      };
    };
  });
  mxSyncPlayhead();
  if (h)
    [a, b].forEach((t, k) => {
      if (infos[k] || MXUI.pending.has(t.id)) return;
      mxAnalyze(t)
        .then((v) => {
          if (k === 0 && v.bpm) {
            const current = globalMix(),
              at = current.tracks.findIndex((x) => x.id === a.id);
            if (at >= 0 && current.tracks[at + 1]?.id === b.id) mxSave(current, at, { bpmA: v.bpm });
          }
          if (S.route === "mix:@all" || S.route === "mix") globalMixEditor();
        })
        .catch(() => {
          MXUI.cache.set(t.id, { error: true });
          if (S.route === "mix:@all" || S.route === "mix") globalMixEditor();
        });
    });
}

// Automatic tempo from actual playback, sampled only while the mix editor is visible.
const MX_TEMPO = { id: null, samples: [], buffer: null, last: 0 };
function mxEstimateTempo(values, rate = 20) {
  if (values.length < rate * 20) return null;
  const onset = values.map((v, i) => Math.max(0, v - (values[i - 1] || v) * 0.85));
  let best = 0,
    bpm = null;
  for (let tempo = 70; tempo <= 180; tempo++) {
    const lag = (rate * 60) / tempo;
    let c = 0,
      aa = 0,
      bb = 0;
    for (let i = Math.ceil(lag); i < onset.length; i++) {
      const j = i - lag,
        lo = Math.floor(j),
        f = j - lo,
        x = onset[i],
        y = onset[lo] * (1 - f) + onset[lo + 1] * f;
      c += x * y;
      aa += x * x;
      bb += y * y;
    }
    const score = c / Math.sqrt(aa * bb + 1e-12);
    if (score > best) {
      best = score;
      bpm = tempo;
    }
  }
  return best >= 0.22 ? bpm : null;
}
function mxTempoStart() {
  if (MX_TEMPO.timer || !/^mix(?::@all)?$/.test(S.route || "") || audio.paused || !AX.ok || document.hidden) return;
  MX_TEMPO.timer = setInterval(mxTempoTick, 50);
}
function mxTempoTick() {
  if (!/^mix(?::@all)?$/.test(S.route || "") || !S.current || audio.paused || !AX.fx || !AX.ok || document.hidden) {
    clearInterval(MX_TEMPO.timer);
    MX_TEMPO.timer = null;
    MX_TEMPO.id = null;
    return;
  }
  const id = S.current.id,
    now = performance.now();
  if (MX_TEMPO.id !== id)
    Object.assign(MX_TEMPO, { id, samples: [], last: now, buffer: new Float32Array(AX.fx.fftSize) });
  if (now - MX_TEMPO.last < 40) return;
  // Reset after stalls or throttling; a non-uniform envelope would create invented tempo.
  if (now - MX_TEMPO.last > 150) MX_TEMPO.samples = [];
  MX_TEMPO.last = now;
  AX.fx.getFloatTimeDomainData(MX_TEMPO.buffer);
  let energy = 0;
  for (const v of MX_TEMPO.buffer) energy += v * v;
  MX_TEMPO.samples.push(Math.sqrt(energy / MX_TEMPO.buffer.length));
  if (MX_TEMPO.samples.length < 600) return;
  const bpm = mxEstimateTempo(MX_TEMPO.samples);
  MX_TEMPO.samples = [];
  if (!bpm) return;
  const old = MXUI.cache.get(id) || mxCacheLoad(id) || { error: true };
  if (old.bpm === bpm) return;
  old.bpm = bpm;
  MXUI.cache.set(id, old);
  if (old.peaks) mxCacheSave(id, old);
  const mix = globalMix(),
    idx = mix.tracks.findIndex((t) => t.id === id);
  if (idx >= 0 && mix.tracks[idx + 1]) mxSave(mix, idx, { bpmA: bpm });
  if (/^mix(?::@all)?$/.test(S.route || "")) globalMixEditor();
}
