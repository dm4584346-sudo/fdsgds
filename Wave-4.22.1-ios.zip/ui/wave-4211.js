/* Wave 4.21.1 — «Black» polish: the lyrics follow the singer, working submenus, playlist picker */
(function () {
  "use strict";
  const q = (s) => document.querySelector(s);
  const ok = (f) => { try { return f(); } catch (e) { return undefined; } };

  /* ---------------- lyrics ---------------- */
  const TS = /\[(\d{1,2}):(\d{1,2}(?:[.,]\d{1,3})?)\]/g;
  const player = () => ok(() => audio) || q("#audio");
  function curDur() {
    const a = player();
    if (a && isFinite(a.duration) && a.duration > 0) return a.duration;
    const t = ok(() => S.current) || {};
    let d = +(t.duration || t.dur || t.durationMs || t.len || 0);
    if (d > 10000) d /= 1000;
    return d > 0 ? d : 0;
  }
  function parseLrc(lines) {
    const out = [];
    for (const l of lines) {
      const s = String(l.text || "");
      TS.lastIndex = 0;
      const times = [];
      let m;
      while ((m = TS.exec(s))) times.push(+m[1] * 60 + parseFloat(m[2].replace(",", ".")));
      if (!times.length) continue;
      const text = s.replace(TS, "").trim();
      for (const t of times) out.push({ t, text });
    }
    return out.sort((a, b) => a.t - b.t);
  }
  // unsynced text: every line gets a time from the track length (longer lines — longer), so it still follows the song
  function estimate(d) {
    const dur = curDur() || 210;
    if (d._estDur && Math.abs(dur - d._estDur) < 1) return false;
    d._estDur = dur;
    const intro = Math.min(14, dur * 0.07), outro = Math.min(18, dur * 0.08);
    const span = Math.max(10, dur - intro - outro);
    const w = d.lines.map((l) => (l.text ? 1.2 + Math.min(60, l.text.length) / 12 : 0.6));
    const tot = w.reduce((a, b) => a + b, 0) || 1;
    let acc = intro;
    d.lines.forEach((l, i) => { l.t = acc; acc += (span * w[i]) / tot; });
    return true;
  }
  function fixData(d) {
    if (!d || d._w4211 || d.error || d.instrumental || !Array.isArray(d.lines) || !d.lines.length) return d;
    d._w4211 = true;
    if (!d.synced) {
      const arr = [];
      for (const l of d.lines) {
        const s = typeof l === "string" ? l : (l && l.text) || "";
        String(s).split(/\r?\n/).forEach((x) => arr.push({ text: x }));
      }
      const p = parseLrc(arr);
      if (p.length >= 3) { d.lines = p; d.synced = true; return d; }
      let ls = arr.map((x) => ({ t: 0, text: String(x.text).trim() }));
      while (ls.length && !ls[0].text) ls.shift();
      while (ls.length && !ls[ls.length - 1].text) ls.pop();
      // several empty lines in a row → one
      ls = ls.filter((l, i) => l.text || (ls[i - 1] && ls[i - 1].text));
      if (ls.filter((l) => l.text).length < 2) return d;
      d.lines = ls;
      d.synced = true;
      d._est = true;
      estimate(d);
      return d;
    }
    d.lines.forEach((l) => { if (typeof l.t === "string") l.t = parseFloat(l.t) || 0; });
    // some sources give milliseconds instead of seconds — then the text never left the first line
    const ts = d.lines.map((l) => +l.t).filter(isFinite);
    const mx = ts.length ? Math.max.apply(null, ts) : 0, dur = curDur();
    if (mx > 1000 && (dur ? mx > dur * 5 : mx > 3600)) d.lines.forEach((l) => (l.t = +l.t / 1000));
    return d;
  }
  if (typeof window.renderLyrics === "function") {
    const origRender = window.renderLyrics;
    window.renderLyrics = function () {
      ok(() => LY.data && fixData(LY.data));
      const r = origRender.apply(this, arguments);
      ok(() => {
        if (LY.data && LY.data._est) {
          const s = q("#ly-src");
          if (s && !/по длительности/.test(s.textContent)) s.insertAdjacentText("beforeend", " · синхронизация по длительности трека");
        }
      });
      return r;
    };
  }
  // the karaoke keeps going even if the rAF loop was stopped (background flag stuck, WebView paused frames…)
  setInterval(() => {
    ok(() => {
      if (document.hidden || typeof lyOpen !== "function" || !lyOpen() || !LY.data) return;
      if (!LY.data._w4211) { window.renderLyrics(); return; }
      if (LY.data._est && estimate(LY.data)) { window.renderLyrics(); return; }
      lySync();
      if (!LY.raf) { if (S.bg) S.bg = false; lyStart(); }
    });
  }, 250);

  /* ---------------- menus ---------------- */
  // «Добавить в плейлист» without any playlist → straight to «Новый плейлист» (created with this track)
  if (typeof window.menu === "function") {
    const origMenu = window.menu;
    window.menu = function (e, items) {
      ok(() => {
        items = items.map((it) => {
          if (Array.isArray(it) && it[0] === "Добавить в плейлист" && Array.isArray(it[2])) {
            const real = it[2].filter((x) => x !== "-");
            if (real.length === 1) return [it[0], it[1], real[0][2]];
          }
          return it;
        });
      });
      return origMenu.call(this, e, items);
    };
  }
  const mob = () => document.documentElement.hasAttribute("data-mobile");
  const imp = (el, props) => { if (el) for (const k in props) el.style.setProperty(k, props[k], "important"); };
  // a submenu opened by a tap: on top of the menu (it used to open underneath it), the menu itself steps aside
  if (typeof window.openSubMenu === "function") {
    const origSub = window.openSubMenu;
    window.openSubMenu = function () {
      const r = origSub.apply(this, arguments);
      ok(() => {
        const sm = q("#menu-sub");
        if (!sm || !mob()) return;
        sm.hidden = false;
        sm.scrollTop = 0;
        imp(sm, { "z-index": "260", position: "fixed", left: "6px", right: "6px", top: "auto", bottom: "6px", "max-height": "72vh", "overflow-y": "auto", background: "#000", "background-image": "none", "backdrop-filter": "none", "-webkit-backdrop-filter": "none", "pointer-events": "auto" });
        imp(q("#menu"), { visibility: "hidden" });
      });
      return r;
    };
  }
  if (typeof window.hideSubMenu === "function") {
    const origHide = window.hideSubMenu;
    window.hideSubMenu = function () {
      const r = origHide.apply(this, arguments);
      ok(() => { const m = q("#menu"); if (m) m.style.removeProperty("visibility"); });
      return r;
    };
  }
  // the submenu items: run the action even if something swallowed the click
  document.addEventListener("click", (e) => {
    ok(() => {
      const b = e.target.closest && e.target.closest("#menu .has-sub");
      if (!b || !mob() || b._w4211retry) return;
      setTimeout(() => ok(() => {
        const sm = q("#menu-sub");
        if ((!sm || sm.hidden) && !q("#menu").hidden) { b._w4211retry = true; b.click(); b._w4211retry = false; }
      }), 120);
    });
  }, true);

  /* ---------------- black panels, enforced inline (beats any skin / inline colour) ---------------- */
  const BLACK = { background: "#000", "background-color": "#000", "background-image": "none", "backdrop-filter": "none", "-webkit-backdrop-filter": "none" };
  const GLASS = { background: "rgba(0,0,0,.66)", "background-color": "rgba(0,0,0,.66)", "background-image": "none", "backdrop-filter": "blur(24px)", "-webkit-backdrop-filter": "blur(24px)" };
  const TOP = "calc(var(--m-head-top, 28px) + 10px)";
  function paint() {
    if (!mob()) return;
    ok(() => {
      ["#menu", "#menu-sub", "#tpanel", ".tpanel", "#sndp", ".sndp"].forEach((s) => document.querySelectorAll(s).forEach((el) => imp(el, BLACK)));
      document.querySelectorAll("#tpanel > *, .tpanel > *, #sndp > *").forEach((el) => {
        const bg = getComputedStyle(el).backgroundColor;
        const m = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(bg);
        if (m && +m[3] > +m[1] + 12) imp(el, { background: "transparent", "background-image": "none" });
      });
      const fq = q("#fpq");
      if (fq) {
        imp(fq, Object.assign({ "padding-top": TOP }, GLASS));
        fq.querySelectorAll(".fpq-list, .fpq-h, .fpq-empty").forEach((el) => imp(el, { background: "transparent", "background-image": "none" }));
        const done = fq.querySelector(".m-queue-close");
        if (done) imp(done, { "margin-top": "0", background: "rgba(255,255,255,.14)", color: "#fff" });
      }
      const fp = q("#fullplayer");
      if (fp && fp.classList.contains("q")) imp(fp, { background: "#000", "background-image": "none" });
      else if (fp) ["background", "background-image"].forEach((k) => fp.style.getPropertyPriority(k) && fp.style.removeProperty(k));
      const lc = q("#lyrics .ly-close");
      if (lc) {
        imp(lc, { position: "absolute", top: TOP, left: "10px", right: "auto", width: "56px", height: "56px", display: "flex", "align-items": "center", "justify-content": "center", padding: "0", "border-radius": "50%", background: "rgba(0,0,0,.4)", color: "#fff", "z-index": "40" });
        const sv = lc.querySelector("svg");
        if (sv) imp(sv, { width: "34px", height: "34px" });
        imp(q("#lyrics .ly-body"), { "padding-top": "calc(var(--m-head-top, 28px) + 76px)" });
      }
      const t = q("#toast");
      if (t) imp(t, { background: "transparent", "background-image": "none", border: "0", "box-shadow": "none", "backdrop-filter": "none", "-webkit-backdrop-filter": "none", color: "#fff", "font-weight": "700", "text-shadow": "0 1px 2px rgba(0,0,0,.95), 0 0 10px rgba(0,0,0,.85), 0 0 22px rgba(0,0,0,.6)", "pointer-events": "none", "z-index": "400" });
    });
  }
  paint();
  new MutationObserver(() => { clearTimeout(paint.t); paint.t = setTimeout(paint, 30); }).observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ["hidden", "class"] });

  /* ---------------- lyrics are fetched as soon as a track starts, not when the text is opened ---------------- */
  const pending = new Map();
  function prefetch(t) {
    if (!t || !t.id || ok(() => LY.cache.has(t.id)) || pending.has(t.id)) return pending.get(t && t.id);
    const p = ok(() => lyricsCache(t));
    if (!p || !p.then) return;
    const w = p.catch(() => {}).finally(() => pending.delete(t.id));
    pending.set(t.id, w);
    return w;
  }
  let lastId = null;
  setInterval(() => ok(() => {
    const t = S.current;
    if (!t || t.id === lastId) return;
    lastId = t.id;
    prefetch(t);
    // the next track of the queue too, a bit later
    setTimeout(() => ok(() => {
      const qq = S.queue || [];
      const i = qq.findIndex((x) => x && x.id === t.id);
      const nx = i >= 0 ? qq[i + 1] : null;
      if (nx && nx.id !== t.id) prefetch(nx);
    }), 4000);
  }), 400);
  /* ---------------- profile banner: the pencil was covered by the profile head — hit-test by coordinates ---------------- */
  let beAt = 0, beDown = null, beSwallow = 0;
  const pencil = () => q(".content > .pbanner .pb-edit") || q(".pbanner .pb-edit") || q("[data-banner-edit]");
  const inPencil = (x, y) => {
    const b = pencil();
    if (!b || !b.offsetParent && getComputedStyle(b).position !== "fixed") return false;
    const r = b.getBoundingClientRect(), pad = 12;
    return r.width > 0 && x >= r.left - pad && x <= r.right + pad && y >= r.top - pad && y <= r.bottom + pad;
  };
  async function openBanner() {
    if (Date.now() - beAt < 900) return;
    beAt = Date.now();
    try {
      const ed = window.bannerEditor || ok(() => bannerEditor);
      await ed();
    } catch (e) {
      // the editor failed — at least let the user pick a new picture
      try {
        if (await pickProfileImage("banner")) { ok(() => applySettings()); ok(() => reroute()); toast("Баннер обновлён", 1800); }
      } catch (e2) { ok(() => toast("Не удалось открыть баннер: " + (e2.message || e.message), 4000)); }
    }
  }
  window.addEventListener("pointerdown", (e) => {
    beDown = q("dialog[open], #dialog[open]") ? null : inPencil(e.clientX, e.clientY) ? { x: e.clientX, y: e.clientY } : null;
  }, true);
  window.addEventListener("pointerup", (e) => {
    const d = beDown;
    beDown = null;
    if (!d || Math.abs(e.clientX - d.x) > 14 || Math.abs(e.clientY - d.y) > 14 || !inPencil(e.clientX, e.clientY)) return;
    beSwallow = Date.now() + 700;
    e.preventDefault();
    e.stopPropagation();
    openBanner();
  }, true);
  window.addEventListener("click", (e) => {
    if (q("dialog[open], #dialog[open]")) return;
    if (Date.now() < beSwallow || inPencil(e.clientX, e.clientY)) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      if (Date.now() >= beSwallow) openBanner();
    }
  }, true);

  if (typeof window.loadLyrics === "function") {
    const origLoad = window.loadLyrics;
    window.loadLyrics = async function () {
      const t = ok(() => S.current);
      const p = t && pending.get(t.id);
      if (p && !ok(() => LY.cache.has(t.id))) {
        ok(() => { q("#ly-lines").innerHTML = '<div class="ly-empty"><span class="ly-spin"></span><b>Ищу текст песни…</b></div>'; });
        await p;
      }
      return origLoad.apply(this, arguments);
    };
  }
})();
