"use strict";
/* Wave 4.21.7 — edge swipe closes the player, liked tile cover, creator badge, recovery after an iOS WebView restart */
(() => {
  const $ = (s, el = document) => el.querySelector(s);
  const isIOS = !!(window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.wave);
  const body = document.body;

  /* ---------- 1. Right edge, right-to-left swipe closes the full player ---------- */
  const fp = () => document.getElementById("fullplayer");
  const isOpen = () => body.classList.contains("fp-open") && fp() && !fp().hidden;
  const reset = () => { const el = fp(); if (!el) return; el.style.transition = ""; el.style.transform = ""; el.style.opacity = ""; };
  const edgeMove = (dx) => {
    const el = fp(); if (!el) return;
    const x = Math.min(0, dx);
    el.style.transition = "none";
    el.style.transform = `translateX(${x}px)`;
    el.style.opacity = String(Math.max(0.5, 1 + (x / innerWidth) * 0.5));
  };
  const edgeEnd = (dx, v) => {
    const el = fp(); if (!el) return;
    const close = dx < -Math.min(110, innerWidth * 0.28) || (dx < -30 && v < -500);
    if (close) {
      el.style.transition = "transform .22s ease-out, opacity .22s ease-out";
      el.style.transform = "translateX(-100%)";
      el.style.opacity = "0";
      setTimeout(() => {
        try { closeFull(true); } catch { $('[data-cmd="fp-close"]')?.click(); }
        setTimeout(reset, 60);
      }, 220);
    } else {
      el.style.transition = "transform .2s ease-out, opacity .2s ease-out";
      el.style.transform = "";
      el.style.opacity = "";
      setTimeout(reset, 220);
    }
  };
  // native iOS edge pan (WaveViewController) calls this
  let nativeActive = false;
  window.__waveEdge = (phase, dx = 0, v = 0) => {
    if (phase === "begin") { nativeActive = isOpen(); return; }
    if (!nativeActive) return;
    if (phase === "move") edgeMove(dx);
    else if (phase === "end") { nativeActive = false; edgeEnd(dx, v); }
    else { nativeActive = false; edgeEnd(0, 0); }
  };
  // JS fallback (Android 10–17, iOS without the native recognizer). The zone is wider than the Android system back strip.
  let drag = null;
  addEventListener("touchstart", (e) => {
    drag = null;
    if (!isOpen() || e.touches.length !== 1) return;
    const t = e.touches[0];
    const zone = isIOS ? 28 : 56;
    if (t.clientX < innerWidth - zone || t.clientY < innerHeight * 0.18 || t.clientY > innerHeight * 0.88) return;
    if (t.target.closest?.("[data-seek], input, .fpa-progress")) return;
    drag = { x: t.clientX, y: t.clientY, t: performance.now(), lock: false, lx: t.clientX, lt: performance.now(), v: 0 };
    e.stopPropagation();
  }, { capture: true, passive: true });
  addEventListener("touchmove", (e) => {
    if (!drag || nativeActive) return;
    const t = e.touches[0];
    const dx = t.clientX - drag.x, dy = t.clientY - drag.y;
    if (!drag.lock) {
      if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return;
      if (Math.abs(dy) > Math.abs(dx) || dx > 0) { drag = null; return; }
      drag.lock = true;
    }
    const now = performance.now();
    drag.v = ((t.clientX - drag.lx) / Math.max(1, now - drag.lt)) * 1000;
    drag.lx = t.clientX; drag.lt = now;
    e.stopPropagation();
    if (e.cancelable) e.preventDefault();
    edgeMove(dx);
  }, { capture: true, passive: false });
  const end = (e) => {
    if (!drag) return;
    const d = drag; drag = null;
    if (!d.lock || nativeActive) return;
    e.stopPropagation();
    const t = e.changedTouches[0];
    edgeEnd(t ? t.clientX - d.x : 0, d.v);
  };
  addEventListener("touchend", end, { capture: true, passive: true });
  addEventListener("touchcancel", (e) => { if (drag?.lock) edgeEnd(0, 0); drag = null; }, { capture: true, passive: true });

  /* ---------- 2. «Мне нравится»: the own (live) cover wins over the skin gradients ---------- */
  const LIKE_SEL = ".m-heart, .m-lhi.likes, .ctile.likes, .ylk-cover.likes, .pc.likes";
  const fixLikes = () => {
    let lc = null;
    try { lc = typeof S !== "undefined" ? S.likesCover : null; } catch {}
    for (const el of document.querySelectorAll(LIKE_SEL)) {
      const src = lc || el.dataset.bg || "";
      if (!src) { if (el.classList.contains("wv-own")) { el.classList.remove("wv-own"); el.style.removeProperty("background-image"); } continue; }
      if (el.dataset.wvOwn === src && el.style.getPropertyPriority("background-image") === "important") continue;
      if (el.dataset.gifBg !== undefined) continue; // frozen while the window is hidden
      el.dataset.wvOwn = src;
      el.removeAttribute("data-bg");
      el.style.setProperty("background-image", `url("${String(src).replace(/["\\\n\r]/g, (c) => "\\" + c)}")`, "important");
      el.classList.add("wv-own");
    }
  };

  /* ---------- 3. Creator badge ---------- */
  const CREATORS = ["yota3301", "xantepxl"];
  const RX = new RegExp("@(" + CREATORS.join("|") + ")\\s*$", "i");
  const CHECK = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="12" fill="#20A4F3"/><path d="M7 12.4l3.3 3.3L17.2 8.8" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const badge = () => {
    const b = document.createElement("span");
    b.className = "wv-verified";
    b.setAttribute("role", "img");
    b.setAttribute("aria-label", "Официальный профиль создателя Wave");
    b.innerHTML = CHECK;
    return b;
  };
  const scanBadges = () => {
    const w = document.createTreeWalker(body, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (n.nodeValue && n.nodeValue.length < 60 && RX.test(n.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT),
    });
    const hits = [];
    while (w.nextNode()) hits.push(w.currentNode);
    for (const n of hits) {
      const p = n.parentElement;
      if (!p || p.closest("input, textarea, [contenteditable], .wv-vtip, script, style")) continue;
      if (n.nextSibling && n.nextSibling.classList?.contains("wv-verified")) continue;
      n.after(badge());
    }
  };
  let tip = null, tipTimer = 0;
  const hideTip = () => { clearTimeout(tipTimer); tip?.remove(); tip = null; };
  document.addEventListener("click", (e) => {
    const b = e.target.closest?.(".wv-verified");
    if (!b) { hideTip(); return; }
    e.preventDefault(); e.stopPropagation();
    hideTip();
    const r = b.getBoundingClientRect();
    tip = document.createElement("div");
    tip.className = "wv-vtip";
    tip.textContent = "Это официальный профиль создателя Wave";
    const x = Math.max(130, Math.min(innerWidth - 130, r.left + r.width / 2));
    tip.style.left = x + "px";
    tip.style.top = r.top - 8 + "px";
    body.append(tip);
    const arrowShift = r.left + r.width / 2 - x;
    if (arrowShift) tip.style.setProperty("--wv-shift", arrowShift + "px");
    tipTimer = setTimeout(hideTip, 2600);
  }, true);
  addEventListener("scroll", hideTip, { capture: true, passive: true });

  /* ---------- run on every render ---------- */
  let raf = 0;
  const tick = () => { raf = 0; try { fixLikes(); } catch {} try { scanBadges(); } catch {} };
  const schedule = () => { if (!raf) raf = requestAnimationFrame(tick); };
  new MutationObserver(schedule).observe(body, { childList: true, subtree: true, characterData: true });
  schedule();

  /* ---------- 4. Recovery: the iOS WebView was killed and reloaded, «Друзья и комнаты» lost the connection ---------- */
  const getRoute = () => { try { return typeof S !== "undefined" ? S.route : ""; } catch { return ""; } };
  setInterval(() => { const r = getRoute(); if (r) try { localStorage.setItem("wave.lastRoute", JSON.stringify({ r, at: Date.now() })); } catch {} }, 2000);
  if (/[?&]recover=1/.test(location.search)) {
    setTimeout(() => {
      try {
        const saved = JSON.parse(localStorage.getItem("wave.lastRoute") || "null");
        if (!saved || Date.now() - saved.at > 30 * 60 * 1000 || !saved.r || saved.r === getRoute()) return;
        const b = document.createElement("button");
        b.hidden = true; b.dataset.go = saved.r;
        body.append(b); b.click(); b.remove();
      } catch {}
    }, 1500);
  }
  // «Нет связи с Wave» right after a restart / wake-up is usually a race: retry by itself with a backoff
  let tries = 0, retryTimer = 0;
  const autoRetry = (now) => {
    const btn = document.getElementById("soc-retry");
    if (!btn) { tries = 0; return; }
    if (retryTimer) return;
    if (!now && tries >= 5) return;
    const delay = now ? 300 : Math.min(8000, 1000 * 2 ** tries);
    retryTimer = setTimeout(() => { retryTimer = 0; tries++; document.getElementById("soc-retry")?.click(); }, delay);
  };
  new MutationObserver(() => autoRetry(false)).observe(body, { childList: true, subtree: true });
  addEventListener("online", () => { tries = 0; autoRetry(true); });
  document.addEventListener("visibilitychange", () => { if (!document.hidden) { tries = 0; autoRetry(true); } });
})();
