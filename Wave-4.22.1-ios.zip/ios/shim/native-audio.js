/* Wave 4.22.0 (iOS): <audio> backed by the native Swift player (WavePlayer.swift).
   The page keeps real <audio> DOM nodes (ids, querySelector, document listeners work as before), but every
   media property / method of them is redirected to AVPlayer through webkit.messageHandlers.waveAudio.
   WebKit itself never gets a src, so it never owns the sound, the audio session or the lock-screen card.
   Injected by WaveViewController at document start (source of WavePlayerShim.swift; regenerate with
   ios/shim/build-shim.sh after editing). */
(function () {
  "use strict";
  if (window.__waveNA) return;
  var H = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.waveAudio;
  if (!H) return;
  var post = function (m) { try { H.postMessage(m); } catch (e) {} };
  var SID = Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4);
  var seq = 0;
  var map = Object.create(null);
  var EP = Element.prototype;
  var oSet = EP.setAttribute, oRem = EP.removeAttribute, oGet = EP.getAttribute, oHas = EP.hasAttribute;
  var oRemove = EP.remove;
  var now = function () { return performance.now(); };
  var MEDIA_ERR = { 1: "MEDIA_ERR_ABORTED", 2: "MEDIA_ERR_NETWORK", 3: "MEDIA_ERR_DECODE", 4: "MEDIA_ERR_SRC_NOT_SUPPORTED" };

  function ranges(arr) {
    arr = Array.isArray(arr) ? arr : [];
    var chk = function (i) { if (i < 0 || i >= arr.length) throw new DOMException("Index out of range", "IndexSizeError"); };
    return {
      length: arr.length,
      start: function (i) { chk(i); return arr[i][0]; },
      end: function (i) { chk(i); return arr[i][1]; },
    };
  }
  function absUrl(v) {
    if (!v) return "";
    try { return new URL(String(v), location.href).href; } catch (e) { return String(v); }
  }
  function fire(el, type) {
    try { el.dispatchEvent(new Event(type)); } catch (e) { console.warn("[wave-na] " + type, e); }
  }
  function later(el, type) { setTimeout(function () { fire(el, type); }, 0); }

  function install(el) {
    if (!el || el.__na) return el;
    var st = {
      id: SID + "-" + ++seq, src: "", created: false,
      t: 0, stamp: now(), d: NaN, paused: true, ended: false, playing: false, seeking: false,
      rs: 0, ns: 0, buf: [], seekable: [], err: null, sk: 0,
      vol: 1, muted: false, rate: 1, drate: 1, pp: true, loop: false, preload: "auto", autoplay: false,
      sentVol: -1,
    };
    el.__na = st;
    map[st.id] = el;
    var send = function (op, m) { m = m || {}; m.op = op; m.id = st.id; post(m); };
    var eff = function () { return st.muted ? 0 : Math.max(0, Math.min(1, st.vol)); };
    var cur = function () {
      if (st.playing && !st.paused && !st.seeking) {
        var t = st.t + ((now() - st.stamp) / 1000) * st.rate;
        return isFinite(st.d) ? Math.min(t, st.d) : t;
      }
      return st.t;
    };
    var reset = function () {
      var had = st.created || st.rs > 0;
      st.t = 0; st.stamp = now(); st.d = NaN; st.ended = false; st.playing = false; st.seeking = false;
      st.rs = 0; st.buf = []; st.seekable = []; st.err = null;
      if (!st.paused) { st.paused = true; later(el, "pause"); }
      if (had) later(el, "emptied");
    };
    var load = function () {
      reset();
      if (!st.src) {
        if (st.created) send("release");
        st.created = false;
        st.ns = 3;
        return;
      }
      st.created = true;
      st.ns = 2;
      st.sentVol = eff();
      send("load", { url: st.src, vol: st.sentVol, rate: st.rate, pp: st.pp, loop: st.loop, sid: SID });
      later(el, "loadstart");
    };
    var setSrc = function (v) { st.src = absUrl(v); load(); };
    var def = function (name, get, set) {
      Object.defineProperty(el, name, { configurable: true, enumerable: true, get: get, set: set || function () {} });
    };

    def("src", function () { return st.src; }, setSrc);
    def("currentSrc", function () { return st.created ? st.src : ""; });
    def("currentTime", cur, function (v) {
      v = Number(v);
      if (!isFinite(v)) return;
      v = Math.max(0, v);
      st.t = v; st.stamp = now(); st.ended = false; st.sk++;
      if (!st.created) return;
      st.seeking = true;
      send("seek", { t: v, sk: st.sk });
      later(el, "seeking");
    });
    def("duration", function () { return st.d; });
    def("paused", function () { return st.paused; });
    def("ended", function () { return st.ended; });
    def("seeking", function () { return st.seeking; });
    def("readyState", function () { return st.rs; });
    def("networkState", function () { return st.ns; });
    def("error", function () { return st.err; });
    def("buffered", function () { return ranges(st.buf); });
    def("seekable", function () { return ranges(st.seekable); });
    def("played", function () { return ranges([]); });
    def("volume", function () { return st.vol; }, function (v) {
      v = Number(v);
      if (!isFinite(v)) return;
      if (v < 0 || v > 1) throw new DOMException("volume out of range", "IndexSizeError");
      if (v === st.vol) return;
      st.vol = v;
      var e = eff();
      if (st.created && Math.abs(e - st.sentVol) > 0.002) { st.sentVol = e; send("vol", { v: e }); }
      later(el, "volumechange");
    });
    def("muted", function () { return st.muted; }, function (v) {
      v = !!v;
      if (v === st.muted) return;
      st.muted = v;
      if (st.created) { st.sentVol = eff(); send("vol", { v: st.sentVol }); }
      later(el, "volumechange");
    });
    def("playbackRate", function () { return st.rate; }, function (v) {
      v = Number(v);
      if (!isFinite(v) || v <= 0) return;
      if (v === st.rate) return;
      st.t = cur(); st.stamp = now();
      st.rate = v;
      if (st.created) send("rate", { v: v });
      later(el, "ratechange");
    });
    def("defaultPlaybackRate", function () { return st.drate; }, function (v) { v = Number(v); if (isFinite(v) && v > 0) st.drate = v; });
    var ppGet = function () { return st.pp; }, ppSet = function (v) {
      v = !!v;
      if (v === st.pp) return;
      st.pp = v;
      if (st.created) send("pitch", { v: v });
    };
    def("preservesPitch", ppGet, ppSet);
    def("webkitPreservesPitch", ppGet, ppSet);
    def("loop", function () { return st.loop; }, function (v) { st.loop = !!v; if (st.created) send("loop", { v: st.loop }); });
    def("preload", function () { return st.preload; }, function (v) { st.preload = String(v); });
    def("autoplay", function () { return st.autoplay; }, function (v) { st.autoplay = !!v; });
    def("crossOrigin", function () { return oGet.call(el, "crossorigin"); }, function (v) {
      if (v == null) oRem.call(el, "crossorigin"); else oSet.call(el, "crossorigin", String(v));
    });

    el.play = function () {
      if (!st.src) return Promise.reject(new DOMException("No source", "NotSupportedError"));
      if (!st.created) load();
      if (st.ended) { st.t = 0; st.stamp = now(); st.ended = false; }
      if (st.paused) {
        st.paused = false;
        st.stamp = now();
        later(el, "play");
        if (st.rs < 3) later(el, "waiting");
      }
      send("play");
      return Promise.resolve();
    };
    el.pause = function () {
      if (st.paused) return;
      st.t = cur(); st.stamp = now();
      st.paused = true; st.playing = false;
      if (st.created) send("pause");
      later(el, "pause");
    };
    el.load = load;
    el.fastSeek = function (t) { el.currentTime = t; };
    el.canPlayType = function (type) {
      type = String(type || "").toLowerCase();
      if (/mpegurl/.test(type)) return "maybe";
      if (/webm|ogg|opus|vorbis/.test(type)) return ""; // 4.22.1: AVPlayer has no WebM / Ogg decoder
      if (/webm|ogg|opus|vorbis/.test(type)) return ""; // 4.22.1: AVPlayer has no WebM / Ogg decoder
      if (/^audio\/(mp4|aac|mpeg|mp3|x-m4a|m4a|wav|x-wav|flac|x-flac|x-caf)/.test(type)) return "probably";
      if (/^audio\//.test(type)) return "maybe";
      return "";
    };
    el.setAttribute = function (n, v) {
      var k = String(n).toLowerCase();
      if (k === "src") return setSrc(v);
      if (k === "loop") el.loop = true;
      return oSet.call(el, n, v);
    };
    el.removeAttribute = function (n) {
      var k = String(n).toLowerCase();
      if (k === "src") { st.src = ""; return; }
      if (k === "loop") el.loop = false;
      return oRem.call(el, n);
    };
    el.getAttribute = function (n) {
      if (String(n).toLowerCase() === "src") return st.src || null;
      return oGet.call(el, n);
    };
    el.hasAttribute = function (n) {
      if (String(n).toLowerCase() === "src") return !!st.src;
      return oHas.call(el, n);
    };
    el.remove = function () {
      oRemove.call(el);
      // a removed, silent deck must not keep a native player alive
      if (st.paused && st.created) { send("release"); st.created = false; }
    };
    el.__naEvent = function (ev) {
      var s = ev.s || {};
      var type = ev.e;
      var fresh = (s.sk == null || s.sk >= st.sk) || type === "seeked" || type === "loadedmetadata";
      if (typeof s.t === "number" && fresh) { st.t = s.t; st.stamp = now(); }
      if (typeof s.d === "number") st.d = s.d < 0 ? Infinity : s.d;
      else if (s.d === null && type === "durationchange") st.d = NaN;
      if (typeof s.rs === "number") st.rs = s.rs;
      if (Array.isArray(s.buf)) st.buf = s.buf;
      if (Array.isArray(s.sk2)) st.seekable = s.sk2;
      switch (type) {
        case "play": // started natively (lock screen, interruption ended)
          if (!st.paused) return;
          st.paused = false; st.ended = false;
          break;
        case "pause": // paused natively (lock screen, headphones, call) or the end of the track
          if (st.paused) return;
          st.paused = true; st.playing = false;
          break;
        case "playing":
          if (st.paused) return;
          st.playing = true;
          break;
        case "waiting":
          st.playing = false;
          break;
        case "seeked":
          st.seeking = false;
          break;
        case "ended":
          st.ended = true; st.playing = false; st.paused = true;
          break;
        case "error":
          st.err = { code: s.code || 4, message: s.msg || "", MEDIA_ERR_ABORTED: 1, MEDIA_ERR_NETWORK: 2, MEDIA_ERR_DECODE: 3, MEDIA_ERR_SRC_NOT_SUPPORTED: 4 };
          st.playing = false; st.ns = 3;
          console.warn("[wave-na] error", MEDIA_ERR[st.err.code], st.err.message);
          break;
        case "canplaythrough":
          st.ns = 1;
          break;
        case "adopted": // the native player of an earlier page / of a background hand-off continues
          st.created = true;
          if (s.playing && st.paused) { st.paused = false; st.playing = true; fire(el, "play"); fire(el, "playing"); }
          return;
      }
      fire(el, type);
    };
    if (oHas.call(el, "src")) { var a = oGet.call(el, "src"); oRem.call(el, "src"); setSrc(a); }
    return el;
  }

  // every <audio> of the page becomes native
  var oCreate = Document.prototype.createElement;
  Document.prototype.createElement = function (tag) {
    var el = oCreate.apply(this, arguments);
    if (String(tag).toLowerCase() === "audio") install(el);
    return el;
  };
  var NativeAudio = function Audio(src) {
    var el = oCreate.call(document, "audio");
    install(el);
    el.preload = "auto";
    if (src !== undefined) el.src = src;
    return el;
  };
  NativeAudio.prototype = HTMLAudioElement.prototype;
  window.Audio = NativeAudio;
  // the static <audio id="audio"> of index.html
  var adopt = function (el) {
    if (!el || el.tagName !== "AUDIO") return;
    oRem.call(el, "crossorigin");
    install(el);
  };
  new MutationObserver(function (recs) {
    for (var i = 0; i < recs.length; i++) {
      var r = recs[i];
      if (r.type === "attributes") { if (r.target.__na && r.target.id === "audio") post({ op: "active", id: r.target.__na.id }); continue; }
      for (var j = 0; j < r.addedNodes.length; j++) {
        var n = r.addedNodes[j];
        if (n.nodeType !== 1) continue;
        if (n.tagName === "AUDIO") adopt(n);
        else if (n.querySelectorAll) n.querySelectorAll("audio").forEach(adopt);
      }
    }
  }).observe(document, { childList: true, subtree: true, attributes: true, attributeFilter: ["id"] });

  // Web Audio cannot reach a native player: never build the graph for these elements
  var AC = window.AudioContext || window.webkitAudioContext;
  if (AC && AC.prototype.createMediaElementSource) {
    var oMes = AC.prototype.createMediaElementSource;
    AC.prototype.createMediaElementSource = function (el) {
      if (el && el.__na) throw new DOMException("native audio", "NotSupportedError");
      return oMes.apply(this, arguments);
    };
  }

  var lastHint = "";
  var activeSent = "";
  function pxCover(u) {
    if (!u) return "";
    try {
      var key = (window.WaveAndroid && window.WaveAndroid.key()) || "";
      return location.origin + "/px/" + key + "/?u=" + encodeURIComponent(u);
    } catch (e) { return ""; }
  }
  function tick() {
    try {
      // the active deck (id="audio") drives the lock screen
      var a = document.getElementById("audio");
      if (a && a.__na && a.__na.id !== activeSent) { activeSent = a.__na.id; post({ op: "active", id: activeSent }); }
      // the next track resolved ahead: the native side may start it alone when the page sleeps in the background
      /* global XF, S */
      var p = typeof XF !== "undefined" ? XF.pre : null;
      var t = p && p.s && typeof S !== "undefined" && p.queue === S.queue ? S.queue.find(function (x) { return x && x.id === p.id; }) : null;
      var ok = t && p.s.url && Date.now() - p.at < 170e3;
      var sig = ok ? p.id + "|" + p.s.url : "";
      if (sig !== lastHint) {
        lastHint = sig;
        if (ok) post({ op: "hint", url: absUrl(p.s.url), title: t.title || "", artist: t.artist || "", cover: pxCover(t.cover || ""), duration: Number(t.duration) || 0, ttl: Math.max(5, (170e3 - (Date.now() - p.at)) / 1000) });
        else post({ op: "hint", url: "" });
      }
    } catch (e) {}
  }

  function afterLoad() {
    try { /* global AX */ if (typeof AX !== "undefined") AX.failed = true; } catch (e) {} // no Web Audio graph: volume / fades go to the native player
    try { if (window.Hls) window.Hls.isSupported = function () { return false; }; } catch (e) {} // HLS is played by AVPlayer itself
    window.__waveKick = function () {}; // there is no AudioContext to wake any more
    document.documentElement.classList.add("wave-native-audio");
    setInterval(tick, 1000);
    tick();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", afterLoad, { once: true });
  else afterLoad();

  window.__waveNA = {
    sid: SID,
    adopt: adopt,
    // native -> page: [{id, e, s}]
    ev: function (list) {
      for (var i = 0; i < list.length; i++) {
        var x = list[i], el = map[x.id];
        if (el && el.__naEvent) el.__naEvent(x);
      }
    },
    // the native side lost / dropped a player
    gone: function (id) { var el = map[id]; if (el && el.__na) { el.__na.created = false; } },
  };
  post({ op: "hello", sid: SID });
})();
