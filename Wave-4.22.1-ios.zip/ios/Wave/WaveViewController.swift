import UIKit
import WebKit
import AVFoundation
import SafariServices

/// avoids the retain cycle WKUserContentController -> handler
private final class WeakHandler: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?
    init(_ t: WKScriptMessageHandler) { target = t }
    func userContentController(_ c: WKUserContentController, didReceive m: WKScriptMessage) {
        target?.userContentController(c, didReceive: m)
    }
}

/// the interface of Wave (ui/) in a WKWebView, served by the Rust core on 127.0.0.1.
/// window.WaveAndroid is emulated so bridge.js / mobile.js work unchanged.
final class WaveViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
    private var webView: WKWebView!
    private var auth: [String: AuthViewController] = [:]
    private var loaded = false
    private var recovering = false
    private var inBackground = false
    /// 4.22.0: the sound is played natively (WavePlayer.swift); the page only drives it
    private let player = WavePlayer()

    private var base: String { "http://127.0.0.1:\(AppDelegate.port)" }

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        let cfg = WKWebViewConfiguration()
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []
        cfg.allowsAirPlayForMediaPlayback = true
        cfg.websiteDataStore = .default()
        let ucc = WKUserContentController()
        ucc.add(WeakHandler(self), name: "wave")
        ucc.add(WeakHandler(self), name: "waveAudio")
        ucc.addUserScript(WKUserScript(source: shim(), injectionTime: .atDocumentStart, forMainFrameOnly: true))
        // 4.22.0: every <audio> of the page becomes a proxy of a native AVPlayer
        ucc.addUserScript(WKUserScript(source: WavePlayerShim.source, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        cfg.userContentController = ucc

        webView = WKWebView(frame: view.bounds, configuration: cfg)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.backgroundColor = .black
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.bounces = false
        webView.allowsBackForwardNavigationGestures = false
        webView.navigationDelegate = self
        webView.uiDelegate = self
        if #available(iOS 16.4, *) { webView.isInspectable = true }
        view.addSubview(webView)

        player.sendJS = { [weak self] js in self?.run(js) }
        player.onRemote = { [weak self] a, arg in self?.remote(a, arg) }
        player.onWake = { [weak self] in self?.health { ok in if !ok { self?.revive() } } }
        let nc = NotificationCenter.default
        nc.addObserver(self, selector: #selector(didEnterBackground), name: UIApplication.didEnterBackgroundNotification, object: nil)
        nc.addObserver(self, selector: #selector(willEnterForeground), name: UIApplication.willEnterForegroundNotification, object: nil)
        nc.addObserver(self, selector: #selector(didBecomeActive), name: UIApplication.didBecomeActiveNotification, object: nil)

        // 4.21.7: right-edge swipe (right to left) closes the full player
        let edge = UIScreenEdgePanGestureRecognizer(target: self, action: #selector(edgePan(_:)))
        edge.edges = .right
        edge.delegate = self
        webView.addGestureRecognizer(edge)

        waitForServer(attempt: 0)
    }

    @objc private func edgePan(_ g: UIScreenEdgePanGestureRecognizer) {
        let dx = Double(g.translation(in: view).x)
        switch g.state {
        case .began:
            let y = g.location(in: view).y, h = view.bounds.height
            if y > h * 0.15 && y < h * 0.9 { run("window.__waveEdge&&__waveEdge('begin')") }
        case .changed: run("window.__waveEdge&&__waveEdge('move',\(dx))")
        case .ended: run("window.__waveEdge&&__waveEdge('end',\(dx),\(Double(g.velocity(in: view).x)))")
        case .cancelled, .failed: run("window.__waveEdge&&__waveEdge('cancel')")
        default: break
        }
    }

    // MARK: start

    private func waitForServer(attempt: Int) {
        guard let url = URL(string: base + "/health") else { return }
        var req = URLRequest(url: url)
        req.timeoutInterval = 1
        URLSession.shared.dataTask(with: req) { [weak self] _, resp, _ in
            DispatchQueue.main.async {
                guard let self = self else { return }
                if (resp as? HTTPURLResponse)?.statusCode == 200 || attempt > 150 {
                    self.loadUI()
                } else {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { self.waitForServer(attempt: attempt + 1) }
                }
            }
        }.resume()
    }

    private func loadUI() {
        guard !loaded, let url = URL(string: base + "/ui/index.html?k=" + AppDelegate.key + (recovering ? "&recover=1" : "")) else { return }
        loaded = true
        recovering = false
        webView.load(URLRequest(url: url))
    }

    private func shim() -> String {
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? ""
        return """
        (function(){
          if (window.WaveAndroid) return;
          var post = function(m){ try { window.webkit.messageHandlers.wave.postMessage(m); } catch(e){} };
          var saved = null; try { saved = localStorage.getItem("wave.insets"); } catch(e){}
          window.__waveInsets = window.__waveInsets || \(js(initialInsets())) || saved || "0,0,0";
          try { document.documentElement.style.setProperty("--m-safe-top", (Number(String(window.__waveInsets).split(",")[0])||0) + "px"); } catch(e){}
          window.WaveAndroid = {
            key: function(){ return \(js(AppDelegate.key)); },
            version: function(){ return \(js(version)); },
            safeInsets: function(){ return window.__waveInsets; },
            media: function(j){ post({t:"media", v:String(j||"")}); },
            copy: function(s){ post({t:"copy", v:String(s||"")}); },
            openUrl: function(u){ post({t:"open", v:String(u||"")}); },
            authWindow: function(id,u,w){ post({t:"auth", id:String(id), url:String(u||""), watch:String(w||"")}); },
            authClose: function(id){ post({t:"authClose", id:String(id)}); }
          };
          document.addEventListener("DOMContentLoaded", function(){ document.documentElement.classList.add("wave-ios"); });
        })();
        """
    }

    // MARK: safe area

    // 4.21.7: real insets already in the first frame (the collapse arrow no longer jumps from y=0)
    private func initialInsets() -> String {
        let i = view.window?.safeAreaInsets ?? UIApplication.shared.windows.first?.safeAreaInsets ?? .zero
        if i.top <= 0 { return "" }
        return "\(Int(i.top)),\(Int(i.left)),\(Int(i.right))"
    }

    override func viewSafeAreaInsetsDidChange() {
        super.viewSafeAreaInsetsDidChange()
        pushInsets()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        pushInsets()
    }

    private func pushInsets() {
        let i = view.safeAreaInsets
        let v = "\(Int(i.top)),\(Int(i.left)),\(Int(i.right))"
        run("window.__waveInsets=\(js(v));try{localStorage.setItem('wave.insets',\(js(v)))}catch(e){};try{dispatchEvent(new Event('resize'))}catch(e){}")
    }

    // MARK: JS -> native

    func userContentController(_ c: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "waveAudio" { player.handle(message.body); return }
        guard let d = message.body as? [String: Any], let t = d["t"] as? String else { return }
        switch t {
        case "media": player.updateMeta(d["v"] as? String ?? "")
        case "copy": UIPasteboard.general.string = d["v"] as? String ?? ""
        case "open": openURL(d["v"] as? String ?? "")
        case "auth": openAuth(id: d["id"] as? String ?? "", url: d["url"] as? String ?? "")
        case "revive": revive()
        case "authClose":
            if let id = d["id"] as? String, let a = auth.removeValue(forKey: id) { a.closeFromCore() }
        default: break
        }
    }

    private func openURL(_ s: String) {
        guard let url = URL(string: s), let scheme = url.scheme?.lowercased() else { return }
        // Spotify answers to http://127.0.0.1:43821 — the app must stay in the foreground, so an in-app Safari
        if (scheme == "http" || scheme == "https"), url.host?.contains("spotify.com") == true {
            let sf = SFSafariViewController(url: url)
            topController().present(sf, animated: true)
            return
        }
        UIApplication.shared.open(url)
    }

    private func openAuth(id: String, url: String) {
        guard !id.isEmpty, let u = URL(string: url) else { return }
        auth[id]?.closeFromCore()
        let a = AuthViewController(id: id, url: u)
        a.onNav = { [weak self] nav in
            self?.run("window.waveAuthNav&&waveAuthNav(\(js(id)),\(js(nav)))")
        }
        a.onClose = { [weak self] in
            self?.auth.removeValue(forKey: id)
            self?.run("window.waveAuthNav&&waveAuthNav(\(js(id)),'')")
        }
        auth[id] = a
        let nav = UINavigationController(rootViewController: a)
        nav.modalPresentationStyle = .pageSheet
        topController().present(nav, animated: true)
    }

    private func topController() -> UIViewController {
        var c: UIViewController = self
        while let p = c.presentedViewController { c = p }
        return c
    }

    // 4.21.8: the local core stopped answering (iOS kills sockets of a suspended app) -> «Нет связи с Wave / Load failed».
    // Check /health; when dead start the core again, wait for it and reload the page on the same screen.
    private var reviving = false
    private func health(_ done: @escaping (Bool) -> Void) {
        guard let url = URL(string: base + "/health") else { return done(false) }
        var req = URLRequest(url: url)
        req.timeoutInterval = 1.5
        URLSession.shared.dataTask(with: req) { _, resp, _ in
            let ok = (resp as? HTTPURLResponse)?.statusCode == 200
            DispatchQueue.main.async { done(ok) }
        }.resume()
    }
    private func revive() {
        guard !reviving else { return }
        reviving = true
        health { [weak self] ok in
            guard let self = self else { return }
            if ok { self.reviving = false; self.run("window.__waveRevived&&__waveRevived()"); return }
            (UIApplication.shared.delegate as? AppDelegate)?.startCore()
            self.waitAlive(attempt: 0)
        }
    }
    private func waitAlive(attempt: Int) {
        health { [weak self] ok in
            guard let self = self else { return }
            if ok {
                self.reviving = false
                self.loaded = false
                self.recovering = true
                self.loadUI()
            } else if attempt < 40 {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { self.waitAlive(attempt: attempt + 1) }
            } else { self.reviving = false }
        }
    }

    private func remote(_ a: String, _ arg: Int = 0) {
        run("window.waveRemote&&waveRemote(\(js(a)),\(arg))")
    }

    // MARK: background

    @objc private func didEnterBackground() {
        inBackground = true
        run("window.waveVisible&&waveVisible(false)")
    }

    @objc private func willEnterForeground() {
        run("window.waveVisible&&waveVisible(true)")
    }

    @objc private func didBecomeActive() {
        guard inBackground else { return }
        inBackground = false
        // 4.21.8: the core may have lost its socket while suspended
        health { [weak self] ok in if !ok { self?.revive() } }
    }

    // MARK: WKWebView

    // 4.21.7: iOS killed the WebContent process (memory pressure). A bare reload() raced the local server and the social
    // session («Нет связи с Wave»); now wait for /health, reload with recover=1 so the UI returns to the last screen.
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        // 4.22.0: the sound is not in the WebContent process any more — the track keeps playing and the restarted
        // page adopts the native player
        player.pageGone()
        loaded = false
        recovering = true
        waitForServer(attempt: 0)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { return decisionHandler(.allow) }
        let isLocal = url.host == "127.0.0.1" || url.host == "localhost"
        let scheme = url.scheme?.lowercased() ?? ""
        if navigationAction.targetFrame?.isMainFrame == true && !isLocal && scheme != "about" && scheme != "blob" && scheme != "data" {
            openURL(url.absoluteString)
            return decisionHandler(.cancel)
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let u = navigationAction.request.url?.absoluteString { openURL(u) }
        return nil
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        topController().present(a, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Отмена", style: .cancel) { _ in completionHandler(false) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        topController().present(a, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        let a = UIAlertController(title: nil, message: prompt, preferredStyle: .alert)
        a.addTextField { $0.text = defaultText }
        a.addAction(UIAlertAction(title: "Отмена", style: .cancel) { _ in completionHandler(nil) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(a.textFields?.first?.text) })
        topController().present(a, animated: true)
    }

    // MARK: helpers

    private func run(_ script: String) {
        guard loaded else { return }
        webView.evaluateJavaScript(script, completionHandler: nil)
    }
}

/// a JS string literal
func js(_ s: String) -> String {
    guard let d = try? JSONSerialization.data(withJSONObject: [s]),
          let t = String(data: d, encoding: .utf8) else { return "\"\"" }
    return String(t.dropFirst().dropLast())
}

extension WaveViewController: UIGestureRecognizerDelegate {
    func gestureRecognizer(_ g: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith o: UIGestureRecognizer) -> Bool { true }
}
