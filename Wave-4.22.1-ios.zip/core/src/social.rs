//! 4.20.1: «Друзья и комнаты» — the same Wave account service as the PC version (social.cjs of Wave Desktop 4.17.17):
//! Supabase auth by nick + password, public profiles, friends, cloud profile cards and «Слушать вместе» rooms.
//!
//! The interface never sees the tokens: they live here, encrypted on disk with the vault key (like the Yandex sign-in).
//! The PC version listens to the room over a WebSocket and falls back to polling; on the phone the room is polled
//! every 2 s and the invitations every 5 s (no extra native dependency, the same data either way).
//! Events for the interface: social-session / social-room / social-invites / social-notice / social-connection.

use crate::app::{app, blog, emit};
use crate::js::{now_ms, J, E, R};
use crate::re;
use serde_json::{json, Value};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{LazyLock, Mutex};
use std::time::Duration;

const BASE: &str = "https://jbdgqjthkkjccyxhnibt.supabase.co";
// the public (publishable) key of the PC version; access is enforced by row-level security on the server
const KEY: &str = "sb_publishable_xks3p4MJFrnp7ToWbAkhaQ_-Acgn6I2";
const PROFILE_FIELDS: &str = "id,username,display_name,bio,color,is_public,avatar,banner,created_at";
const MAX_DOCUMENT_BYTES: usize = 20 * 1024 * 1024;

#[derive(Default)]
struct State {
    session: Option<Value>,
    profile: Option<Value>,
    room: Option<String>,
    snapshot: Option<Value>,
    invite_cache: String,
    last_publish: f64,
    loaded: bool,
}
static ST: LazyLock<Mutex<State>> = LazyLock::new(|| Mutex::new(State::default()));
/// changes on sign-in / sign-out: background loops of an old account stop
static EPOCH: AtomicU64 = AtomicU64::new(0);
/// changes when the room changes: the room loop of an old room stops
static ROOM_EPOCH: AtomicU64 = AtomicU64::new(0);
static INVITE_LOOP: AtomicU64 = AtomicU64::new(u64::MAX);
static AUTH_BUSY: Mutex<bool> = Mutex::new(false);
static REFRESH: tokio::sync::Mutex<()> = tokio::sync::Mutex::const_new(());

fn ev(t: &str, v: Value) {
    emit(json!({ "type": format!("social-{}", t), "value": v }));
}
fn uuid_ok(s: &str) -> bool {
    re!(r"(?i)^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$").is_match(s)
}

/* ---------- the session on disk (encrypted) ---------- */
fn file() -> std::path::PathBuf {
    app().data.join("social-session.enc")
}
fn save_session(s: &Option<Value>) {
    match s {
        None => {
            let _ = std::fs::remove_file(file());
        }
        Some(v) => {
            if let Some(b) = crate::vault::encrypt(&app().data, &v.to_string()) {
                let tmp = app().data.join("social-session.enc.tmp");
                if std::fs::write(&tmp, b).is_ok() {
                    let _ = std::fs::rename(&tmp, file());
                }
            }
        }
    }
}
fn load_session() {
    let mut st = ST.lock().unwrap();
    if st.loaded {
        return;
    }
    st.loaded = true;
    if let Ok(b) = std::fs::read(file()) {
        if let Some(s) = crate::vault::decrypt(&app().data, &b).and_then(|t| serde_json::from_str::<Value>(&t).ok()) {
            if s.g("access_token").truthy() && s.g("refresh_token").truthy() && s.g("user").g("id").truthy() {
                st.session = Some(s);
                return;
            }
        }
        let _ = std::fs::remove_file(file());
    }
}
fn session() -> Option<Value> {
    load_session();
    ST.lock().unwrap().session.clone()
}
fn me() -> String {
    session().map(|s| s.g("user").g("id").s()).unwrap_or_default()
}
fn accept(s: &Value) {
    let sess = json!({
        "access_token": s.g("access_token"),
        "refresh_token": s.g("refresh_token"),
        "expires_at": now_ms() + s.g("expires_in").as_f64().unwrap_or(3600.0) * 1000.0,
        "user": { "id": s.g("user").g("id") },
    });
    save_session(&Some(sess.clone()));
    ST.lock().unwrap().session = Some(sess);
}

/* ---------- requests ---------- */
struct Req<'a> {
    method: &'a str,
    body: Option<Value>,
    auth: bool,
    prefer: Option<&'a str>,
}
fn post(body: Value) -> Req<'static> {
    Req { method: "POST", body: Some(body), auth: true, prefer: None }
}
fn getr() -> Req<'static> {
    Req { method: "GET", body: None, auth: true, prefer: None }
}
async fn request(endpoint: &str, r: Req<'_>) -> R<Value> {
    request_once(endpoint, &r, true).await
}
fn http_err(msg: impl Into<String>, status: u16) -> E {
    let mut e = E::new(msg);
    e.status = Some(status);
    e
}
async fn request_once(endpoint: &str, r: &Req<'_>, retry: bool) -> R<Value> {
    let mut token = String::new();
    if r.auth {
        let s = session().ok_or_else(|| E::new("Войдите в аккаунт Wave"))?;
        if s.g("expires_at").n() < now_ms() + 60000.0 {
            refresh().await?;
        }
        token = session().map(|s| s.g("access_token").s()).unwrap_or_default();
    }
    let method = reqwest::Method::from_bytes(r.method.as_bytes()).unwrap_or(reqwest::Method::POST);
    let mut rq = crate::http::NOREDIRECT
        .request(method, format!("{}{}", BASE, endpoint))
        .header("apikey", KEY)
        .header("Content-Type", "application/json")
        .timeout(Duration::from_secs(12));
    if r.auth {
        rq = rq.header("Authorization", format!("Bearer {}", token));
    }
    if let Some(p) = r.prefer {
        rq = rq.header("Prefer", p);
    }
    if let Some(b) = &r.body {
        rq = rq.body(b.to_string());
    }
    let res = rq.send().await.map_err(|_| E::new("Нет связи с сервером Wave. Проверьте интернет."))?;
    let status = res.status().as_u16();
    let text = res.text().await.unwrap_or_default();
    let data: Value = serde_json::from_str(&text).unwrap_or(Value::Null);
    if status == 401 && r.auth && retry {
        refresh().await?;
        return Box::pin(request_once(endpoint, r, false)).await;
    }
    if !(200..300).contains(&status) {
        let m = [data.g("error"), data.g("message"), data.g("msg"), data.g("error_description")]
            .iter()
            .map(|v| v.s())
            .find(|s| !s.is_empty())
            .unwrap_or_else(|| "Сервис Wave временно недоступен".into());
        return Err(http_err(m.chars().take(300).collect::<String>(), status));
    }
    Ok(data)
}
async fn refresh() -> R<()> {
    let _g = REFRESH.lock().await;
    let s = session().ok_or_else(|| E::new("Войдите в Wave"))?;
    // another call has just refreshed it
    if s.g("expires_at").n() > now_ms() + 60000.0 {
        return Ok(());
    }
    let rev = EPOCH.load(Ordering::SeqCst);
    let r = Req { method: "POST", body: Some(json!({ "refresh_token": s.g("refresh_token") })), auth: false, prefer: None };
    match Box::pin(request_once("/auth/v1/token?grant_type=refresh_token", &r, false)).await {
        Ok(n) => {
            if rev != EPOCH.load(Ordering::SeqCst) {
                return Err(E::new("Сеанс изменён"));
            }
            accept(&n);
            Ok(())
        }
        Err(e) => {
            if rev == EPOCH.load(Ordering::SeqCst) && matches!(e.status, Some(400) | Some(401)) {
                sign_out_local();
                ev("session", status_json());
            }
            Err(e)
        }
    }
}
async fn rpc(name: &str, body: Value) -> R<Value> {
    request(&format!("/rest/v1/rpc/{}", name), post(body)).await
}

/* ---------- state ---------- */
fn status_json() -> Value {
    let st = ST.lock().unwrap();
    json!({
        "user": st.profile.clone().unwrap_or(Value::Null),
        "loggedIn": st.session.is_some(),
        "persistent": true,
        "room": st.snapshot.clone().unwrap_or(Value::Null),
        "connected": st.room.is_some() && st.snapshot.is_some(),
    })
}
fn sign_out_local() {
    EPOCH.fetch_add(1, Ordering::SeqCst);
    {
        let mut st = ST.lock().unwrap();
        st.session = None;
        st.profile = None;
        st.invite_cache.clear();
    }
    save_session(&None);
    stop_room();
    ev("invites", json!([]));
}
async fn load_profile() -> R<Value> {
    let id = me();
    if id.is_empty() {
        return Ok(status_json());
    }
    let list = request(&format!("/rest/v1/wave_profiles?id=eq.{}&select={}", id, PROFILE_FIELDS), getr()).await?;
    let p = list.as_array().and_then(|a| a.first()).cloned();
    let has = p.is_some();
    ST.lock().unwrap().profile = p;
    if has {
        start_invites();
    }
    Ok(status_json())
}

/* ---------- invitations: polled every 5 s while signed in ---------- */
async fn poll_invites() -> R<Value> {
    let rev = EPOCH.load(Ordering::SeqCst);
    let data = rpc("wave_room_invites", json!({})).await?;
    if rev != EPOCH.load(Ordering::SeqCst) {
        return Ok(json!([]));
    }
    let list = if data.is_array() { data } else { json!([]) };
    let key = list.to_string();
    let changed = {
        let mut st = ST.lock().unwrap();
        let c = st.invite_cache != key;
        st.invite_cache = key;
        c
    };
    if changed {
        ev("invites", list.clone());
    }
    Ok(list)
}
fn start_invites() {
    let rev = EPOCH.load(Ordering::SeqCst);
    if INVITE_LOOP.swap(rev, Ordering::SeqCst) == rev {
        return;
    }
    tokio::spawn(async move {
        loop {
            if EPOCH.load(Ordering::SeqCst) != rev || session().is_none() {
                break;
            }
            let _ = poll_invites().await;
            tokio::time::sleep(Duration::from_secs(5)).await;
        }
    });
}

/* ---------- rooms: the snapshot is polled every 2 s while inside ---------- */
fn stop_room() {
    ROOM_EPOCH.fetch_add(1, Ordering::SeqCst);
    let was = {
        let mut st = ST.lock().unwrap();
        st.snapshot = None;
        st.room.take()
    };
    if was.is_some() {
        ev("room", Value::Null);
        ev("connection", json!(false));
    }
}
async fn pull() -> R<Value> {
    let Some(id) = ST.lock().unwrap().room.clone() else { return Ok(Value::Null) };
    let rev = EPOCH.load(Ordering::SeqCst);
    let start = now_ms();
    match rpc("wave_room_snapshot", json!({ "room": id })).await {
        Ok(mut d) => {
            if ST.lock().unwrap().room.as_deref() != Some(&id) || rev != EPOCH.load(Ordering::SeqCst) {
                return Ok(Value::Null);
            }
            let end = now_ms();
            crate::js::set(&mut d, "received_at", json!(end));
            let offset = d.g("server_ms").n() - (start + end) / 2.0;
            crate::js::set(&mut d, "clock_offset", json!(offset));
            let changed = {
                let mut st = ST.lock().unwrap();
                // the receive time changes every poll; only a real change goes to the interface
                let strip = |v: &Value| {
                    let mut x = v.clone();
                    if let Some(o) = x.as_object_mut() {
                        o.remove("received_at");
                        o.remove("clock_offset");
                        o.remove("server_ms");
                    }
                    x
                };
                let c = st.snapshot.as_ref().map(strip) != Some(strip(&d));
                let first = st.snapshot.is_none();
                st.snapshot = Some(d.clone());
                if first {
                    ev("connection", json!(true));
                }
                c
            };
            if changed {
                ev("room", d.clone());
            }
            Ok(d)
        }
        Err(e) => {
            if ST.lock().unwrap().room.as_deref() == Some(&id) {
                if re!(r"(?i)закрыта|отозван|недоступна").is_match(&e.msg) {
                    stop_room();
                    ev("notice", json!("Комната закрыта или доступ отозван"));
                } else {
                    ev("notice", json!(e.msg));
                }
            }
            Err(e)
        }
    }
}
async fn enter(id_v: Value) -> R<Value> {
    let id = id_v.sv();
    if !uuid_ok(&id) {
        return Err(E::new("Сервер не вернул комнату"));
    }
    stop_room();
    let rev = ROOM_EPOCH.fetch_add(1, Ordering::SeqCst) + 1;
    ST.lock().unwrap().room = Some(id.clone());
    let snap = pull().await?;
    tokio::spawn(async move {
        let mut fails = 0u32;
        loop {
            tokio::time::sleep(Duration::from_millis(if fails > 2 { 6000 } else { 2000 })).await;
            if ROOM_EPOCH.load(Ordering::SeqCst) != rev || ST.lock().unwrap().room.as_deref() != Some(&id) {
                break;
            }
            match pull().await {
                Ok(_) => fails = 0,
                Err(_) => {
                    fails += 1;
                    if fails == 3 {
                        ev("connection", json!(false));
                    }
                }
            }
        }
    });
    Ok(snap)
}
async fn leave() -> R<Value> {
    let id = ST.lock().unwrap().room.clone();
    stop_room();
    if let Some(id) = id {
        if session().is_some() {
            rpc("wave_leave_room", json!({ "room": id })).await?;
        }
    }
    Ok(json!({ "ok": true }))
}

/* ---------- what may be sent about a track / a profile ---------- */
fn image(v: &Value, inline: bool) -> R<Value> {
    let Some(s) = v.as_str() else { return Ok(Value::Null) };
    if inline && s.starts_with("data:image/") {
        let ok = re!(r"^data:image/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$").is_match(s);
        if !ok {
            return Ok(Value::Null);
        }
        let live = s.starts_with("data:image/gif") || s.starts_with("data:image/webp");
        let limit = if live { 8_390_000 } else { 2_800_000 };
        if s.len() > limit {
            return Err(E::new(if live { "Живая картинка профиля должна быть до 6 МБ" } else { "Статичное изображение больше 2 МБ. Выберите изображение меньшего размера." }));
        }
        return Ok(json!(s));
    }
    let Ok(u) = url::Url::parse(s) else { return Ok(Value::Null) };
    if u.scheme() != "https" || !u.username().is_empty() || u.password().is_some() || u.query().is_some() || u.fragment().is_some() || s.len() > 1600 {
        return Ok(Value::Null);
    }
    let host = u.host_str().unwrap_or("");
    if !re!(r"(^|\.)(avatars\.yandex\.net|avatars\.mds\.yandex\.net|sndcdn\.com|scdn\.co|spotifycdn\.com|spotifycdn\.net|audius\.co|audiuscontent\.xyz|ytimg\.com|googleusercontent\.com|mzstatic\.com)$").is_match(host) {
        return Ok(Value::Null);
    }
    Ok(json!(u.as_str()))
}
fn room_image(v: &Value) -> Value {
    let Some(s) = v.as_str() else { return Value::Null };
    let Ok(mut u) = url::Url::parse(s) else { return Value::Null };
    u.set_query(None);
    u.set_fragment(None);
    image(&json!(u.as_str()), false).unwrap_or(Value::Null)
}
fn source_prefix(src: &str) -> Option<&'static str> {
    Some(match src {
        "yandex" => "ym:",
        "spotify" => "sp:",
        "soundcloud" => "sc:",
        "audius" => "au:",
        "youtube" => "yt:",
        _ => return None,
    })
}
fn share_track(t: &Value) -> R<Value> {
    if t.is_null() {
        return Ok(Value::Null);
    }
    let id = t.g("id").s();
    let ok = source_prefix(&t.g("source").s()).map(|p| id.starts_with(p)).unwrap_or(false)
        && re!(r"^(ym:|sp:|sc:|au:|yt:)[a-zA-Z0-9_:-]{1,176}$").is_match(&id);
    if !ok {
        return Err(E::new("Локальные файлы и ссылки не передаются в комнату"));
    }
    let cover = if t.g("coverOriginal").truthy() { t.g("coverOriginal") } else { t.g("cover") };
    Ok(json!({
        "id": id, "source": t.g("source"), "cover": room_image(cover),
        "title": t.g("title").s().chars().take(200).collect::<String>().if_empty("Трек"),
        "artist": t.g("artist").s().chars().take(200).collect::<String>(),
        "duration": t.g("duration").n().clamp(0.0, 86400.0),
    }))
}
trait IfEmpty {
    fn if_empty(self, d: &str) -> String;
}
impl IfEmpty for String {
    fn if_empty(self, d: &str) -> String {
        if self.is_empty() { d.to_string() } else { self }
    }
}
fn doc_item(t: &Value, track: bool) -> R<Option<Value>> {
    if !t.is_object() {
        return Ok(None);
    }
    let id: String = t.g("id").s().chars().take(180).collect();
    if track && !re!(r"^(ym|sp|sc|au|yt):[A-Za-z0-9_:-]{1,176}$").is_match(&id) {
        return Ok(None);
    }
    let id_ok = re!(r"^(sc|scp|scu|au|sp|spp|ym|yma|ymp|yar|yt):[A-Za-z0-9_:-]{1,176}$").is_match(&id);
    let src = t.g("source").s();
    let source = if ["yandex", "spotify", "soundcloud", "audius", "youtube"].contains(&src.as_str()) {
        json!(src)
    } else {
        match id.split(':').next().unwrap_or("") {
            "ym" => json!("yandex"),
            "sp" => json!("spotify"),
            "sc" => json!("soundcloud"),
            "au" => json!("audius"),
            "yt" => json!("youtube"),
            _ => Value::Null,
        }
    };
    let s = |k: &str, n: usize| t.g(k).s().chars().take(n).collect::<String>();
    let title = if t.g("title").truthy() { s("title", 200) } else { s("name", 200) };
    Ok(Some(json!({
        "id": if id_ok { json!(id) } else { Value::Null }, "source": source, "title": title, "name": s("name", 200),
        "artist": s("artist", 200), "cover": image(t.g("cover"), true)?, "coverOriginal": image(t.g("coverOriginal"), false)?,
        "duration": t.g("duration").n().clamp(0.0, 86400.0), "count": t.g("count").n().clamp(0.0, 1e7),
        "artists": [], "streamable": true,
    })))
}
/// the cloud profile card (profile-document.cjs of the PC version): an explicit list of fields, never the raw object
fn clean_document(v: &Value) -> R<Value> {
    if !v.is_object() || v.g("version").as_i64() != Some(1) {
        return Err(E::new("Неверная версия облачного профиля"));
    }
    let c = v.g("counts");
    let l = v.g("bannerLayout");
    let num = |x: &Value, a: f64, b: f64, d: f64| x.as_f64().map(|n| n.clamp(a, b)).unwrap_or(d);
    let mut show = serde_json::Map::new();
    for k in ["artist", "track", "album"] {
        if let Some(t) = doc_item(v.g("showcase").g(k), false)? {
            show.insert(k.into(), t);
        }
    }
    let tracks = |k: &str| -> R<Vec<Value>> {
        let mut out = Vec::new();
        for t in v.g(k).arr().iter().take(24) {
            if let Some(x) = doc_item(t, true)? {
                out.push(x);
            }
        }
        Ok(out)
    };
    if v.g("playlists").arr().len() > 2000 {
        return Err(E::new("В облачном профиле поддерживается до 2000 плейлистов"));
    }
    let count = |k: &str| if c.g(k).is_null() { Value::Null } else { json!(num(c.g(k), 0.0, 1e8, 0.0).round() as i64) };
    let mut pls = Vec::new();
    if !c.g("playlists").is_null() {
        for t in v.g("playlists").arr() {
            if let Some(x) = doc_item(t, false)? {
                pls.push(x);
            }
        }
    }
    let r = json!({
        "version": 1, "nick": v.g("nick").s().chars().take(48).collect::<String>(),
        "avatar": image(v.g("avatar"), true)?, "banner": image(v.g("banner"), true)?,
        "bannerLayout": { "height": num(l.g("height"), 140.0, 600.0, 300.0), "x": num(l.g("x"), 0.0, 100.0, 50.0), "y": num(l.g("y"), 0.0, 100.0, 50.0), "zoom": num(l.g("zoom"), 100.0, 400.0, 100.0) },
        "showcase": Value::Object(show),
        "counts": { "likes": count("likes"), "playlists": count("playlists"), "history": count("history") },
        "likes": if c.g("likes").is_null() { json!([]) } else { json!(tracks("likes")?) },
        "playlists": pls,
        "history": if c.g("history").is_null() { json!([]) } else { json!(tracks("history")?) },
    });
    if r.to_string().len() > MAX_DOCUMENT_BYTES - 131072 {
        return Err(E::new("Облачный профиль больше 20 МБ. Уменьшите GIF или изображения плейлистов."));
    }
    Ok(r)
}

/* ---------- the command ---------- */
fn host_only(what: &str) -> R<String> {
    let st = ST.lock().unwrap();
    let room = st.room.clone().ok_or_else(|| E::new(what))?;
    let host = st.snapshot.as_ref().map(|s| s.g("room").g("host_id").s()).unwrap_or_default();
    drop(st);
    if host != me() {
        return Err(E::new(what));
    }
    Ok(room)
}
fn in_room() -> R<String> {
    ST.lock().unwrap().room.clone().ok_or_else(|| E::new("Сначала войдите в комнату"))
}
pub async fn dispatch(d: &Value) -> R<Value> {
    let op = d.g("op").s();
    let limit = if op == "profile-document-save" { MAX_DOCUMENT_BYTES + 131072 } else { 6000 };
    if op.is_empty() || d.to_string().len() > limit {
        return Err(E::new("Неверный запрос"));
    }
    match op.as_str() {
        "status" => {
            if session().is_some() {
                load_profile().await
            } else {
                Ok(status_json())
            }
        }
        "auth" => {
            {
                let mut b = AUTH_BUSY.lock().unwrap();
                if *b {
                    return Err(E::new("Дождитесь завершения входа"));
                }
                *b = true;
            }
            let res = auth(d).await;
            *AUTH_BUSY.lock().unwrap() = false;
            res
        }
        "logout" => {
            let token = session().map(|s| s.g("access_token").s());
            let _ = leave().await;
            sign_out_local();
            if let Some(t) = token {
                tokio::spawn(async move {
                    let _ = crate::http::NOREDIRECT
                        .post(format!("{}/auth/v1/logout", BASE))
                        .header("apikey", KEY)
                        .header("Authorization", format!("Bearer {}", t))
                        .timeout(Duration::from_secs(8))
                        .send()
                        .await;
                });
            }
            Ok(status_json())
        }
        _ => {
            if session().is_none() {
                return Err(E::new("Войдите в аккаунт Wave"));
            }
            signed(&op, d).await
        }
    }
}
async fn auth(d: &Value) -> R<Value> {
    let action = d.g("action").s();
    if !["login", "register", "recover"].contains(&action.as_str()) {
        return Err(E::new("Неверное действие"));
    }
    let nick = d.g("username").s().trim().to_lowercase();
    let password = d.g("password").s();
    if !re!(r"^[a-z0-9_]{3,24}$").is_match(&nick) || password.chars().count() < 12 || password.chars().count() > 128 {
        return Err(E::new("Ник: 3–24 латинских символа, цифры или _. Пароль: от 12 символов."));
    }
    if session().is_some() {
        let _ = leave().await;
    }
    let rev = EPOCH.load(Ordering::SeqCst);
    let mut body = json!({ "action": action, "username": nick, "password": password });
    if action == "recover" {
        crate::js::set(&mut body, "recovery_code", json!(d.g("recovery_code").s()));
    }
    let r = Req { method: "POST", body: Some(body), auth: false, prefer: None };
    let s = request("/functions/v1/wave-accounts", r).await?;
    if rev != EPOCH.load(Ordering::SeqCst) {
        return Err(E::new("Вход отменён"));
    }
    EPOCH.fetch_add(1, Ordering::SeqCst);
    accept(&s);
    let mut out = load_profile().await?;
    if s.g("recovery_code").truthy() {
        crate::js::set(&mut out, "recovery_code", s.g("recovery_code").clone());
    }
    Ok(out)
}
async fn signed(op: &str, d: &Value) -> R<Value> {
    let uid = me();
    match op {
        "profile-save" => {
            let name = d.g("display_name").s().trim().to_string();
            let bio = d.g("bio").s().trim().to_string();
            let color = if d.g("color").is_null() { "violet".to_string() } else { d.g("color").s() };
            if name.is_empty() || name.chars().count() > 48 || bio.chars().count() > 280 || !["violet", "blue", "rose", "green", "amber"].contains(&color.as_str()) || !d.g("is_public").is_boolean() {
                return Err(E::new("Проверьте поля профиля"));
            }
            let body = json!({ "display_name": name, "bio": bio, "color": color, "is_public": d.g("is_public") });
            request(&format!("/rest/v1/wave_profiles?id=eq.{}", uid), Req { method: "PATCH", body: Some(body), auth: true, prefer: None }).await?;
            load_profile().await
        }
        "search" => {
            let q = d.g("q").s().trim().to_lowercase();
            if !re!(r"^[a-z0-9_]{2,24}$").is_match(&q) {
                return Err(E::new("Введите от 2 латинских символов ника"));
            }
            request(&format!("/rest/v1/wave_profiles?is_public=eq.true&username=like.{}*&select={}&order=username&limit=25", q, PROFILE_FIELDS), getr()).await
        }
        "profile-avatar" => {
            let id = d.g("id").s();
            if !uuid_ok(&id) {
                return Err(E::new("Неверный профиль"));
            }
            let rows = request(&format!("/rest/v1/wave_profile_documents?user_id=eq.{}&select=avatar:document->avatar", id), getr()).await?;
            Ok(image(rows.get(0).unwrap_or(&Value::Null).g("avatar"), true).unwrap_or(Value::Null))
        }
        "profile" => {
            let id = d.g("id").s();
            if !uuid_ok(&id) {
                return Err(E::new("Неверный профиль"));
            }
            let list = request(&format!("/rest/v1/wave_profiles?id=eq.{}&select={}", id, PROFILE_FIELDS), getr()).await?;
            let Some(mut p) = list.as_array().and_then(|a| a.first()).cloned() else { return Ok(Value::Null) };
            match request(&format!("/rest/v1/wave_profile_documents?user_id=eq.{}&select=document,updated_at", id), getr()).await {
                Ok(docs) => {
                    let first = docs.get(0).cloned().unwrap_or(Value::Null);
                    let doc = first.g("document");
                    let clean = if doc.truthy() { clean_document(doc).unwrap_or(Value::Null) } else { Value::Null };
                    crate::js::set(&mut p, "document", clean);
                    crate::js::set(&mut p, "documentUpdatedAt", first.g("updated_at").clone());
                }
                Err(e) if matches!(e.status, Some(400) | Some(404)) => {
                    crate::js::set(&mut p, "document", Value::Null);
                    crate::js::set(&mut p, "documentUnavailable", json!(true));
                }
                Err(e) => return Err(e),
            }
            Ok(p)
        }
        "profile-document-save" => {
            let document = clean_document(d.g("document"))?;
            let r = Req { method: "POST", body: Some(json!({ "user_id": uid, "document": document })), auth: true, prefer: Some("resolution=merge-duplicates") };
            match request("/rest/v1/wave_profile_documents?on_conflict=user_id", r).await {
                Ok(_) => Ok(json!({ "ok": true })),
                Err(e) if matches!(e.status, Some(400) | Some(404)) => Err(E::new("Облачные профили ещё не настроены на сервере.")),
                Err(e) => Err(e),
            }
        }
        "profile-document-delete" => {
            match request(&format!("/rest/v1/wave_profile_documents?user_id=eq.{}", uid), Req { method: "DELETE", body: None, auth: true, prefer: None }).await {
                Ok(_) => Ok(json!({ "ok": true })),
                Err(e) if matches!(e.status, Some(400) | Some(404)) => Ok(json!({ "ok": true })),
                Err(e) => Err(e),
            }
        }
        "friends" => rpc("wave_social_list", json!({})).await,
        "friend-action" => {
            let target = d.g("target").s();
            let action = d.g("action").s();
            if !uuid_ok(&target) || !["request", "accept", "remove", "block", "unblock"].contains(&action.as_str()) {
                return Err(E::new("Неверное действие"));
            }
            rpc("wave_friend_action", json!({ "target": target, "action": action })).await?;
            rpc("wave_social_list", json!({})).await
        }
        "room-create" => {
            let vis = if d.g("visibility").is_null() { "friends".to_string() } else { d.g("visibility").s() };
            if !["friends", "public"].contains(&vis.as_str()) {
                return Err(E::new("Выберите доступ к комнате"));
            }
            let title: String = d.g("title").s().trim().chars().take(64).collect::<String>().if_empty("Слушаем вместе");
            let id = rpc("wave_create_room_v2", json!({ "room_title": title, "room_visibility": vis })).await?;
            enter(id).await
        }
        "room-directory" => {
            let offset = d.g("offset").as_i64().unwrap_or(0);
            let scope = if d.g("scope").is_null() { "all".to_string() } else { d.g("scope").s() };
            if !(0..=10000).contains(&offset) || !["all", "public", "friends"].contains(&scope.as_str()) {
                return Err(E::new("Неверная страница комнат"));
            }
            rpc("wave_room_directory", json!({ "page_offset": offset, "scope": scope })).await
        }
        "room-enter" => {
            let id = d.g("id").s();
            if !uuid_ok(&id) {
                return Err(E::new("Неверная комната"));
            }
            let r = rpc("wave_enter_listed_room", json!({ "room": id })).await?;
            enter(r).await
        }
        "room-invite" => {
            let target = d.g("target").s();
            let room = in_room()?;
            if !uuid_ok(&target) {
                return Err(E::new("Сначала войдите в комнату и выберите друга"));
            }
            Ok(json!({ "id": rpc("wave_room_invite", json!({ "room": room, "target": target })).await? }))
        }
        "room-invites" => poll_invites().await,
        "room-invite-respond" => {
            let id = d.g("id").s();
            let decision = d.g("decision").s();
            if !uuid_ok(&id) || !["accept", "decline"].contains(&decision.as_str()) {
                return Err(E::new("Неверный ответ на приглашение"));
            }
            let room = rpc("wave_room_invite_respond", json!({ "invitation": id, "decision": decision })).await?;
            let res = if decision == "accept" { enter(room).await? } else { json!({ "ok": true }) };
            ST.lock().unwrap().invite_cache.clear();
            let _ = poll_invites().await;
            Ok(res)
        }
        "room-join" => {
            let code = d.g("code").s().trim().to_string();
            if !uuid_ok(&code) {
                return Err(E::new("Вставьте полный код комнаты"));
            }
            let r = rpc("wave_join_room", json!({ "code": code })).await?;
            enter(r).await
        }
        "room-leave" => leave().await,
        "room-snapshot" => pull().await,
        "room-propose" => {
            let room = in_room()?;
            let kind = d.g("kind").s();
            if !["track", "skip", "pause"].contains(&kind.as_str()) {
                return Err(E::new("Неверное предложение"));
            }
            let song = if kind == "track" { share_track(d.g("track"))? } else { Value::Null };
            let id = rpc("wave_room_propose", json!({ "room": room, "kind": kind, "song": song })).await?;
            let _ = pull().await;
            Ok(json!({ "id": id }))
        }
        "room-respond" => {
            let room = in_room()?;
            let id = d.g("id").s();
            let decision = d.g("decision").s();
            if !uuid_ok(&id) || !["approve", "reject", "cancel", "applied", "failed"].contains(&decision.as_str()) {
                return Err(E::new("Неверное решение"));
            }
            let r = rpc("wave_room_respond", json!({ "room": room, "request": id, "decision": decision })).await?;
            let _ = pull().await;
            Ok(r)
        }
        "room-kick" => {
            let room = host_only("Исключать участников может только ведущий")?;
            let target = d.g("target").s();
            if !uuid_ok(&target) || target == uid {
                return Err(E::new("Исключать участников может только ведущий"));
            }
            rpc("wave_room_kick", json!({ "room": room, "target": target })).await?;
            pull().await
        }
        "room-take-next" => {
            let room = host_only("Очередью управляет только ведущий")?;
            let r = rpc("wave_room_take_next", json!({ "room": room })).await?;
            let _ = pull().await;
            Ok(r)
        }
        "room-publish" => {
            let room = host_only("Управлять может только ведущий")?;
            {
                let mut st = ST.lock().unwrap();
                if now_ms() - st.last_publish < 200.0 {
                    return Ok(json!({ "throttled": true }));
                }
                st.last_publish = now_ms();
            }
            let song = share_track(d.g("track"))?;
            let speed = if d.g("playback_rate").is_null() { 1.0 } else { d.g("playback_rate").n() };
            if !speed.is_finite() || !(0.5..=2.0).contains(&speed) {
                return Err(E::new("Скорость должна быть от 0,5 до 2"));
            }
            let pos = d.g("position_ms").n();
            let pos: i64 = if pos.is_finite() { pos.clamp(0.0, 86_400_000.0).round() as i64 } else { 0 };
            let args = json!({ "room": room, "song": song, "pos": pos, "is_playing": d.g("playing").truthy() });
            let mut v2 = args.clone();
            crate::js::set(&mut v2, "speed", json!(speed));
            crate::js::set(&mut v2, "keep_pitch", json!(d.g("preserve_pitch") != &Value::Bool(false)));
            match rpc("wave_publish_room_v2", v2).await {
                Ok(r) => Ok(r),
                Err(e) if matches!(e.status, Some(400) | Some(404)) && re!(r"wave_publish_room_v2|PGRST202|schema cache").is_match(&e.msg) => {
                    if speed != 1.0 || d.g("preserve_pitch") == &Value::Bool(false) {
                        return Err(E::new("Для общей скорости нужна серверная миграция 006"));
                    }
                    rpc("wave_publish_room", args).await
                }
                Err(e) => Err(e),
            }
        }
        _ => {
            blog(&format!("social: unknown op {}", op));
            Err(E::new("Неизвестная команда Wave"))
        }
    }
}
