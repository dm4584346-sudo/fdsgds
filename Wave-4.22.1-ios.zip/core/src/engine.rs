//! The music logic of main.cjs: streams and versions, «Лучшее качество», the merged search, «Моя волна», artist
//! cards / bios / banners, import by link, background matching of playlists, own files, likes sync with Yandex.

use crate::app::{app, blog, emit, enabled, note, p, setting, shared, Job, Jobs};
use crate::cfg::mood_genres;
use crate::js::{jn, now_ms, shuffle, slice, spread, J, E, R};
use crate::providers::matcher::{self, CandOpts, Prov};
use crate::providers::{audius, censorship, extras, soundcloud, spotify, yandex, ymfile, youtube};
use crate::re;
use crate::security::clean_track;
use futures_util::future::join_all;
use serde_json::{json, Map, Value};
use std::collections::{HashMap, HashSet};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, LazyLock, Mutex, MutexGuard};
use std::time::Duration;

pub fn lib() -> MutexGuard<'static, Value> {
    app().library.lock()
}
pub fn lib_save() {
    app().library.save()
}
pub fn st() -> MutexGuard<'static, Value> {
    app().settings.lock()
}
pub fn st_save() {
    app().settings.save()
}
fn id_of(t: &Value) -> String {
    t.g("id").sv()
}
/// `{ ...s, k: v, … }`
pub fn with(s: &Value, extra: Value) -> Value {
    spread(s, &extra)
}
fn obj_mut<'a>(v: &'a mut Value, k: &str) -> &'a mut Map<String, Value> {
    if !v.g(k).is_object() {
        crate::js::set(v, k, json!({}));
    }
    v.get_mut(k).unwrap().as_object_mut().unwrap()
}
pub fn arr_mut<'a>(v: &'a mut Value, k: &str) -> &'a mut Vec<Value> {
    if !v.g(k).is_array() {
        crate::js::set(v, k, json!([]));
    }
    v.get_mut(k).unwrap().as_array_mut().unwrap()
}
fn starts(id: &str, prefixes: &[&str]) -> bool {
    prefixes.iter().any(|p| id.starts_with(p))
}

/* ---------- sources ---------- */
pub fn full_sources() -> Vec<Prov> {
    let mut v = vec![];
    if enabled("soundcloud") {
        v.push(Prov::SoundCloud);
    }
    if enabled("audius") {
        v.push(Prov::Audius);
    }
    v
}
fn providers_for(src: &str) -> Vec<Prov> {
    if src == "audius" && enabled("audius") {
        return vec![Prov::Audius];
    }
    if src == "soundcloud" && enabled("soundcloud") {
        return vec![Prov::SoundCloud];
    }
    full_sources()
}

/* ---------- streams ---------- */
pub async fn stream_of(t: &Value) -> R<Value> {
    let id = id_of(t);
    if id.starts_with("au:") {
        return audius::stream(&id).await;
    }
    if id.starts_with("yt:") {
        if setting("ytFallback") == Value::Bool(false) {
            return Err(E::new("YouTube Music выключен в настройках"));
        }
        return youtube::stream(&id).await;
    }
    if id.starts_with("ym:") {
        if setting("ymStream") == Value::Bool(false) {
            return Err(E::new("Звук Яндекс Музыки выключен в настройках"));
        }
        return ym_stream(&id).await;
    }
    soundcloud::stream(&id).await
}

/// the Yandex stream in the quality of the settings; an encrypted lossless file goes through wave-media://ym/<id>
pub async fn ym_stream(id: &str) -> R<Value> {
    let q = setting("ymQuality");
    let quality = if q.truthy() { q.s() } else { "lossless".into() };
    let mut s = yandex::stream(id, &quality).await?;
    if s.g("lossErr").truthy() {
        blog(&format!("yandex lossless {}: {}", id, s.g("lossErr").s()));
    }
    let o = s.as_object_mut().unwrap();
    o.shift_remove("lossErr");
    if let Some(enc) = o.shift_remove("enc") {
        let url = ymfile::register(o.get("url").map(|u| u.s()).unwrap_or_default(), enc.g("key").s(), enc.g("mime").s(), Some((id.to_string(), quality)));
        o.insert("url".into(), json!(url));
    }
    Ok(s)
}

fn ym_first(wave: bool) -> bool {
    let s = st();
    s.g("ymStream") != &Value::Bool(false)
        && yandex::has_token()
        && (s.g("ymPrefer").as_str() == Some("ym") || (wave && s.g("ymWaveDirect") == &Value::Bool(true)))
}

pub fn remember_match(id: &str, m: &Value) -> R<()> {
    let c = clean_track(m)?;
    {
        let mut l = lib();
        let mm = obj_mut(&mut l, "matches");
        mm.insert(id.to_string(), c);
        if mm.len() > 6000 {
            if let Some(k) = mm.keys().next().cloned() {
                mm.shift_remove(&k);
            }
        }
    }
    lib_save();
    Ok(())
}

fn cached_match(id: &str) -> Value {
    lib().g("matches").g(id).clone()
}

/// the first candidate that really plays: cached match → ranked search results (skips DRM / 404 / previews)
pub async fn playable_match(t: &Value, providers: &[Prov], uncensored: bool) -> Option<Value> {
    let want = if uncensored { censorship::original_query(t) } else { t.clone() };
    let tid = id_of(t);
    let cached = cached_match(&tid);
    let cid = cached.g("id").s();
    let good = cached.truthy()
        && cid != tid
        && !starts(&cid, &["yt:", "ym:"])
        && (!uncensored || (starts(&cid, &["sc:", "au:"]) && !censorship::marked_clean(&cached)))
        && matcher::score(&want, &cached) >= 5.0;
    if good && (!uncensored || censorship::marked_explicit(&cached)) {
        if let Ok(s) = stream_of(&cached).await {
            if !s.g("preview").truthy() {
                return Some(with(&s, json!({ "via": cached, "matched": true })));
            }
        }
        if !uncensored {
            if let Some(m) = lib().get_mut("matches").and_then(|m| m.as_object_mut()) {
                m.shift_remove(&tid);
            }
        }
    }
    let found = matcher::candidates(&want, providers, CandOpts { uncensored, ..Default::default() }).await.unwrap_or_default();
    let mut list = found;
    if good && uncensored && !list.iter().any(|x| x.g("id").s() == cid) {
        list.push(cached.clone());
    }
    for c in list.iter().take(6) {
        if let Ok(s) = stream_of(c).await {
            if s.g("preview").truthy() {
                continue;
            }
            if remember_match(&tid, c).is_err() {
                continue;
            }
            return Some(with(&s, json!({ "via": c, "matched": true })));
        }
    }
    None
}

/* ---------- «Лучшее качество» ---------- */
static UP_JOBS: LazyLock<Jobs> = LazyLock::new(Jobs::new);
const HQ_RETRY: f64 = 3.0 * 86400e3;

fn upgrade_for(t: &Value) -> Job {
    let tid = id_of(t);
    let c = lib().g("upgrades").g(&tid).clone();
    if c.truthy() && (c.g("t").truthy() || now_ms() - c.g("at").n() < HQ_RETRY) {
        let v = if c.g("t").truthy() { c.g("t").clone() } else { Value::Null };
        return shared(async move { Ok(v) });
    }
    let t = t.clone();
    UP_JOBS.run(&tid.clone(), move || async move {
        let mut provs = vec![];
        if enabled("audius") {
            provs.push(Prov::Audius);
        }
        if enabled("soundcloud") {
            provs.push(Prov::SoundCloud);
        }
        let m = match matcher::upgrade(&t, &provs).await {
            Ok(m) => m,
            Err(_) => return Ok(Value::Null),
        };
        let entry = match m.as_ref().and_then(|m| clean_track(m).ok()) {
            Some(c) => json!({ "at": jn(now_ms()), "t": c }),
            None => json!({ "at": jn(now_ms()) }),
        };
        let r = entry.g("t").clone();
        {
            let mut l = lib();
            let u = obj_mut(&mut l, "upgrades");
            u.insert(tid.clone(), entry);
            if u.len() > 3000 {
                if let Some(k) = u.keys().next().cloned() {
                    u.shift_remove(&k);
                }
            }
        }
        lib_save();
        Ok(r)
    })
}

async fn upgrade_stream(t: &Value, s: &Value, prefetch: bool, uncensored: bool) -> Option<Value> {
    let kb = s.path(&["q", "kbps"]).n();
    if setting("hq") == Value::Bool(false)
        || !s.truthy()
        || s.g("preview").truthy()
        || s.g("local").truthy()
        || !(kb != 0.0 && !kb.is_nan() && kb < 128.0)
    {
        return None;
    }
    let job = upgrade_for(t);
    let c = if prefetch {
        job.await.unwrap_or(Value::Null)
    } else {
        tokio::time::timeout(Duration::from_millis(2500), job).await.ok().and_then(|r| r.ok()).unwrap_or(Value::Null)
    };
    if !c.truthy() || (uncensored && censorship::marked_clean(&c)) {
        return None;
    }
    match stream_of(&c).await {
        Ok(s2) => {
            if s2.g("preview").truthy() || !(s2.path(&["q", "kbps"]).n() >= 128.0) {
                return None;
            }
            Some(with(
                &s2,
                json!({ "via": t, "hq": { "id": c.g("id"), "source": c.g("source"), "title": c.g("title"), "artist": c.g("artist"), "link": c.g("link") } }),
            ))
        }
        Err(_) => {
            if let Some(u) = lib().get_mut("upgrades").and_then(|u| u.as_object_mut()) {
                u.shift_remove(&id_of(t));
            }
            None
        }
    }
}

/* ---------- more sources: YouTube Music → the Yandex stream of the account ---------- */
async fn extra_stream(t: &Value, uncensored: bool, no_yandex: bool) -> Option<Value> {
    let want = if uncensored { censorship::original_query(t) } else { t.clone() };
    let tid = id_of(t);
    let errs: Mutex<Vec<String>> = Mutex::new(vec![]);
    let cached = cached_match(&tid);
    let cid = cached.g("id").s();
    if cached.truthy()
        && starts(&cid, &["yt:", "ym:"])
        && cid != tid
        && (!no_yandex || !cid.starts_with("ym:"))
        && (!uncensored || (!cid.starts_with("ym:") && !censorship::marked_clean(&cached)))
        && matcher::score(&want, &cached) >= 5.0
    {
        if let Ok(s) = stream_of(&cached).await {
            if !s.g("preview").truthy() {
                return Some(with(&s, json!({ "via": cached, "matched": true })));
            }
        }
    }
    let yt = || async {
        if setting("ytFallback") == Value::Bool(false) {
            return None;
        }
        if cid.starts_with("yt:") && cid != tid && (!uncensored || !censorship::marked_clean(&cached)) && matcher::score(&want, &cached) >= 5.0 {
            if let Ok(s) = stream_of(&cached).await {
                return Some(with(&s, json!({ "via": cached, "matched": true })));
            }
        }
        let list = match matcher::candidates(&want, &[Prov::YouTube], CandOpts { min: 6.0, limit: 10, uncensored }).await {
            Ok(l) => l,
            Err(e) => {
                errs.lock().unwrap().push(e.msg);
                vec![]
            }
        };
        for c in list.iter().take(3) {
            match youtube::stream(&id_of(c)).await {
                Ok(s) => {
                    let _ = remember_match(&tid, c);
                    return Some(with(&s, json!({ "via": c, "matched": true })));
                }
                Err(e) => {
                    let stop = re!(r"(?i)не бот|bot|LOGIN_REQUIRED|PO-токен").is_match(&e.msg);
                    errs.lock().unwrap().push(e.msg);
                    if stop {
                        break;
                    }
                }
            }
        }
        None
    };
    let ym = || async {
        if no_yandex || setting("ymStream") == Value::Bool(false) || !yandex::has_token() {
            return None;
        }
        if tid.starts_with("ym:") {
            return match ym_stream(&tid).await {
                Ok(s) => Some(with(&s, json!({ "via": t, "yandex": true }))),
                Err(e) => {
                    errs.lock().unwrap().push(e.msg);
                    None
                }
            };
        }
        let list = matcher::candidates(&want, &[Prov::Yandex], CandOpts { min: 6.0, limit: 10, uncensored }).await.unwrap_or_default();
        for c in list.iter().take(2) {
            match ym_stream(&id_of(c)).await {
                Ok(s) => {
                    let _ = remember_match(&tid, c);
                    return Some(with(&s, json!({ "via": c, "matched": true })));
                }
                Err(e) => {
                    let pv = e.preview;
                    errs.lock().unwrap().push(e.msg);
                    if pv {
                        break;
                    }
                }
            }
        }
        None
    };
    let ym_first = !uncensored && setting("ymPrefer").as_str() == Some("ym");
    let r = if ym_first {
        match ym().await {
            Some(r) => Some(r),
            None => yt().await,
        }
    } else {
        match yt().await {
            Some(r) => Some(r),
            None => ym().await,
        }
    };
    if r.is_some() {
        return r;
    }
    let errs = errs.into_inner().unwrap();
    if !errs.is_empty() {
        let u: Vec<String> = crate::js::uniq_strings(errs).into_iter().take(3).collect();
        blog(&format!("extra sources for {}: {}", tid, u.join(" | ")));
    }
    None
}

pub async fn resolve_stream(t: &Value, prefer: Option<&str>, prefetch: bool, wave: bool) -> R<Value> {
    let id = id_of(t);
    if wave && censorship::marked_clean(t) {
        let picked = lib().g("picked").g(&id).clone();
        let pid = picked.g("id").s();
        if picked.truthy() && pid != id && starts(&pid, &["sc:", "au:"]) && !censorship::marked_clean(&picked) {
            if let Ok(s) = stream_of(&picked).await {
                return Ok(with(&s, json!({ "via": picked, "matched": true })));
            }
        }
        if let Some(a) = playable_match(t, &full_sources(), true).await {
            return Ok(a);
        }
        if let Some(e) = extra_stream(t, true, true).await {
            return Ok(e);
        }
        return Err(E::new("Версия помечена как цензурированная, а замена не найдена"));
    }
    if id.starts_with("lf:") {
        let f = lib().g("files").g(&id).clone();
        if !f.truthy() || !p("media").join(f.g("file").s()).exists() {
            return Err(E::new("Файл не найден — возможно, он был удалён"));
        }
        return Ok(json!({ "url": format!("wave-media://media/{}", f.g("file").s()), "type": "file", "preview": false, "via": t, "local": true }));
    }
    // 4.20.1: a track saved in the app's memory starts from the file — without internet and without a link
    if let Some(s) = crate::offline::lookup(t) {
        return Ok(s);
    }
    let picked = lib().g("picked").g(&id).clone();
    let pid = picked.g("id").s();
    if picked.truthy()
        && (pid != id || id.starts_with("ym:"))
        && starts(&pid, &["sc:", "au:", "ym:", "yt:"])
        && (!wave || !censorship::marked_clean(&picked))
    {
        match stream_of(&picked).await {
            Ok(s) => {
                let mut extra = json!({ "via": picked, "matched": pid != id });
                if pid.starts_with("ym:") {
                    crate::js::set(&mut extra, "yandex", json!(true));
                }
                return Ok(with(&s, extra));
            }
            Err(e) => blog(&format!("picked {}: {}", pid, e.msg)),
        }
    }
    let auto_match = setting("autoMatch").truthy();
    let original = lib().g("original").g(&id).truthy();
    if id.starts_with("sc:") {
        let s = match soundcloud::stream(&id).await {
            Ok(s) => s,
            Err(e) => {
                if !(e.drm || e.msg.contains("DRM")) || !auto_match {
                    return Err(e);
                }
                let mut provs = vec![];
                if enabled("audius") {
                    provs.push(Prov::Audius);
                }
                provs.push(Prov::SoundCloud);
                if let Some(a) = playable_match(t, &provs, wave).await {
                    return Ok(with(&a, json!({ "drm": true })));
                }
                if let Some(x) = extra_stream(t, wave, false).await {
                    return Ok(with(&x, json!({ "drm": true })));
                }
                let mut tail = String::new();
                if setting("ytFallback") != Value::Bool(false) {
                    tail.push_str(", YouTube Music");
                }
                if yandex::has_token() && setting("ymStream") != Value::Bool(false) {
                    tail.push_str(", Яндекс Музыке");
                }
                return Err(E::new(format!("{}, а другой полной версии не нашлось (искал на Audius, SoundCloud{})", e.msg, tail)));
            }
        };
        if s.g("preview").truthy() && auto_match && !original {
            let a = playable_match(t, &[Prov::Audius, Prov::SoundCloud], wave).await;
            return Ok(a.unwrap_or_else(|| with(&s, json!({ "via": t }))));
        }
        if !original {
            if let Some(up) = upgrade_stream(t, &s, prefetch, wave).await {
                return Ok(up);
            }
        }
        return Ok(with(&s, json!({ "via": t })));
    }
    if id.starts_with("au:") {
        return Ok(with(&audius::stream(&id).await?, json!({ "via": t })));
    }
    if id.starts_with("yt:") {
        if let Some(a) = playable_match(t, &full_sources(), false).await {
            return Ok(a);
        }
        if let Some(a) = extra_stream(t, false, false).await {
            return Ok(a);
        }
        return Ok(with(&stream_of(t).await?, json!({ "via": t })));
    }
    if id.starts_with("ym:") && t.g("pod").truthy() {
        if !yandex::has_token() {
            return Err(E::new("Подкасты и книги играют из Яндекс Музыки — войдите в Яндекс (Настройки → Подключения)"));
        }
        return Ok(with(&ym_stream(&id).await?, json!({ "via": t, "yandex": true })));
    }
    if id.starts_with("sp:") || id.starts_with("ym:") {
        if id.starts_with("ym:") && !wave && ym_first(wave) && !lib().g("picked").g(&id).truthy() {
            match ym_stream(&id).await {
                Ok(s) => return Ok(with(&s, json!({ "via": t, "yandex": true }))),
                Err(e) => blog(&format!("yandex first {}: {}", id, e.msg)),
            }
        }
        let mut alt = playable_match(t, &providers_for(prefer.unwrap_or("")), wave).await;
        if alt.is_none() && prefer.is_some() {
            alt = playable_match(t, &full_sources(), wave).await;
        }
        if alt.is_none() {
            alt = extra_stream(t, wave, false).await;
        }
        let Some(alt) = alt else {
            return Err(E::new(format!(
                "Не нашёл полную версию этого трека на SoundCloud/Audius{}",
                if setting("ytFallback") != Value::Bool(false) { "/YouTube Music" } else { "" }
            )));
        };
        let via = alt.g("via").clone();
        if via.g("id").s().starts_with("sc:") {
            if let Some(up) = upgrade_stream(&via, &alt, prefetch, wave).await {
                return Ok(with(&up, json!({ "via": via, "matched": true })));
            }
        }
        return Ok(alt);
    }
    Err(E::new("Неизвестный источник"))
}

pub async fn find_match(t: &Value, providers: &[Prov]) -> R<Option<Value>> {
    let tid = id_of(t);
    let cached = cached_match(&tid);
    if cached.truthy() && matcher::score(t, &cached) >= 5.0 {
        return Ok(Some(cached));
    }
    if cached.truthy() {
        if let Some(m) = lib().get_mut("matches").and_then(|m| m.as_object_mut()) {
            m.shift_remove(&tid);
        }
    }
    let m = matcher::find(t, providers).await?;
    if let Some(m) = &m {
        remember_match(&tid, m)?;
    }
    Ok(m)
}

/* ---------- search ---------- */
pub async fn search(q: &str, source: &str) -> R<Value> {
    let all = source.is_empty() || source == "all";
    let want = |k: &str| (all || source == k) && enabled(k);
    let (w_ym, w_sc, w_au, w_yt) = (want("yandex"), want("soundcloud"), want("audius"), want("youtube"));
    let w_sp = want("spotify") && spotify::connected();
    let (ym, sc, au, yt, sp, sc_users, sc_lists, videos) = tokio::join!(
        async { if w_ym { yandex::search_all(q).await } else { Ok(Value::Null) } },
        async { if w_sc { soundcloud::search(q, 30).await } else { Ok(vec![]) } },
        async { if w_au { audius::search(q, 15).await } else { Ok(vec![]) } },
        async { if w_yt { youtube::search(q, 12, false).await } else { Ok(vec![]) } },
        async { if w_sp { spotify::search(q).await } else { Ok(vec![]) } },
        async { if w_sc { soundcloud::search_users(q, 8).await } else { Ok(vec![]) } },
        async { if w_sc { soundcloud::search_playlists(q, 10).await } else { Ok(vec![]) } },
        async { if w_yt { youtube::search(q, 16, true).await } else { Ok(vec![]) } },
    );
    let mut errors = vec![];
    let mut got = Map::new();
    match ym {
        Ok(v) => {
            got.insert("ym".into(), v);
        }
        Err(e) => {
            got.insert("ym".into(), Value::Null);
            if !re!(r"451|регион").is_match(&e.msg) {
                errors.push(format!("Яндекс Музыка: {}", slice(&e.msg, 120)));
            }
        }
    }
    for (k, name, r) in [
        ("sc", Some("SoundCloud"), sc),
        ("au", Some("Audius"), au),
        ("yt", Some("YouTube Music"), yt),
        ("sp", Some("Spotify"), sp),
        ("scUsers", None, sc_users),
        ("scLists", None, sc_lists),
        ("videos", None, videos),
    ] {
        match r {
            Ok(v) => {
                got.insert(k.into(), Value::Array(v));
            }
            Err(e) => {
                got.insert(k.into(), json!([]));
                if let Some(n) = name {
                    errors.push(format!("{}: {}", n, slice(&e.msg, 120)));
                }
            }
        }
    }
    let mut r = extras::merge_search(q, &Value::Object(got));
    crate::js::set(&mut r, "errors", json!(errors));
    Ok(r)
}

/* ---------- landings ---------- */
static YM_PAGES: LazyLock<Mutex<HashMap<String, (f64, Job)>>> = LazyLock::new(|| Mutex::new(HashMap::new()));
pub async fn ym_landing(id: &str, force: bool) -> R<Value> {
    let job = {
        let mut m = YM_PAGES.lock().unwrap();
        match m.get(id) {
            Some((at, j)) if !force && now_ms() - at < 600e3 => j.clone(),
            _ => {
                let i = id.to_string();
                let j = shared(async move { yandex::landing_page(&i).await });
                m.insert(id.to_string(), (now_ms(), j.clone()));
                j
            }
        }
    };
    let r = job.await;
    if r.is_err() {
        YM_PAGES.lock().unwrap().remove(id);
    }
    r
}

static LANDING: Mutex<Option<Job>> = Mutex::new(None);
pub async fn search_landing(force: bool) -> R<Value> {
    let job = {
        let mut l = LANDING.lock().unwrap();
        if l.is_none() || force {
            *l = Some(shared(async {
                let ym = yandex::landing().await.unwrap_or_else(|e| json!({ "chart": [], "releases": [], "playlists": [], "errors": [e.msg] }));
                let mut out = spread(&ym, &json!({ "source": { "chart": "yandex", "releases": "yandex", "playlists": "yandex" }, "at": jn(now_ms()) }));
                let sc = enabled("soundcloud");
                if out.g("chart").arr().is_empty() && sc {
                    let c = soundcloud::charts("all-music", 50).await.unwrap_or_default();
                    crate::js::set(&mut out, "chart", json!(c));
                    out["source"]["chart"] = json!("soundcloud");
                }
                if (out.g("playlists").arr().is_empty() || out.g("releases").arr().is_empty()) && sc {
                    let sel = soundcloud::selections().await.unwrap_or_default();
                    let pls: Vec<Value> = sel.iter().flat_map(|x| x.g("items").arr().to_vec()).collect();
                    if out.g("playlists").arr().is_empty() {
                        crate::js::set(&mut out, "playlists", json!(pls.iter().take(16).cloned().collect::<Vec<_>>()));
                        out["source"]["playlists"] = json!("soundcloud");
                    }
                    if out.g("releases").arr().is_empty() {
                        let mid: Vec<Value> = pls.iter().skip(16).take(16).cloned().collect();
                        let r = if !mid.is_empty() { mid } else { pls.iter().take(12).cloned().collect() };
                        crate::js::set(&mut out, "releases", json!(r));
                        out["source"]["releases"] = json!("soundcloud");
                    }
                }
                Ok(out)
            }));
        }
        l.clone().unwrap()
    };
    let r = job.await;
    if r.is_err() {
        *LANDING.lock().unwrap() = None;
    }
    r
}

/* ---------- «Моя волна» ---------- */
async fn seed_track(seed: &Value) -> R<Value> {
    if !seed.truthy() {
        return Ok(Value::Null);
    }
    let id = id_of(seed);
    if id.starts_with("sc:") {
        return Ok(seed.clone());
    }
    let m = cached_match(&id);
    if m.g("id").s().starts_with("sc:") {
        return Ok(m);
    }
    if !enabled("soundcloud") {
        return Ok(Value::Null);
    }
    let a = seed.g("artist").s();
    let q = slice(&format!("{} {}", a.split(',').next().unwrap_or(""), seed.g("title").s()), 150);
    Ok(soundcloud::search(&q, 5).await?.into_iter().next().unwrap_or(Value::Null))
}

static YM_SERVED: Mutex<Vec<Value>> = Mutex::new(Vec::new());

async fn yandex_wave(mood: &str, diversity: &str, seed: &Value, station: Option<&str>) -> R<Vec<Value>> {
    let (bad, recent, likes, dislike_keys) = {
        let l = lib();
        (
            l.g("dislikes").arr().iter().map(|x| x.sv()).collect::<HashSet<_>>(),
            l.g("history").arr().iter().take(100).cloned().collect::<Vec<_>>(),
            l.g("likes").arr().to_vec(),
            l.g("dislikeKeys").arr().iter().map(|x| x.sv()).collect::<HashSet<_>>(),
        )
    };
    let served = YM_SERVED.lock().unwrap().clone();
    let mut ids: HashSet<String> = recent.iter().chain(served.iter()).map(id_of).collect();
    ids.extend(bad.iter().cloned());
    let mut keys: HashSet<String> = recent.iter().chain(served.iter()).map(extras::song_key).collect();
    keys.extend(dislike_keys.iter().cloned());
    let ym_recent: Vec<String> = recent.iter().map(id_of).filter(|i| i.starts_with("ym:")).collect();
    let fav = diversity == "favorite";
    let liked_ids: HashSet<String> = likes.iter().map(id_of).collect();
    let liked_keys: HashSet<String> = likes.iter().map(extras::song_key).collect();
    let is_liked = |t: &Value| liked_ids.contains(&id_of(t)) || liked_keys.contains(&extras::song_key(t));
    let mut list: Vec<Value> = vec![];
    let mut raw: Vec<Value> = vec![];
    let enough = |list: &Vec<Value>| (if fav { list.len() } else { list.iter().filter(|t| !is_liked(t)).count() }) >= 3;
    let mut i = 0;
    while i < (if fav { 3 } else { 4 }) && !enough(&list) {
        let got = yandex::rotor(mood, diversity, seed, station, &ym_recent).await?;
        if got.is_empty() {
            break;
        }
        raw.extend(got.iter().cloned());
        let mut k2 = keys.clone();
        k2.extend(list.iter().map(extras::song_key));
        list.extend(extras::fresh_only(&got, &ids, &k2));
        for t in &got {
            ids.insert(id_of(t));
        }
        i += 1;
    }
    if !fav {
        list = extras::fewer_liked(list, &liked_ids, &liked_keys);
    }
    if list.is_empty() {
        list = extras::uniq_tracks(&raw)
            .into_iter()
            .filter(|t| !bad.contains(&id_of(t)) && !dislike_keys.contains(&extras::song_key(t)))
            .collect();
    }
    {
        let mut s = YM_SERVED.lock().unwrap();
        let mut n = list.clone();
        n.extend(s.drain(..));
        n.truncate(150);
        *s = n;
    }
    for t in list.iter().take(3) {
        let t = t.clone();
        tokio::spawn(async move {
            let _ = find_match(&t, &full_sources()).await;
        });
    }
    list.truncate(30);
    Ok(list)
}

pub fn top_artists(n: usize) -> Vec<Value> {
    let l = lib();
    let mut v: Vec<Value> = match l.g("artistTime") {
        Value::Object(m) => m.values().filter(|a| a.truthy() && a.g("sec").n() > 0.0).cloned().collect(),
        _ => vec![],
    };
    v.sort_by(|a, b| b.g("sec").n().partial_cmp(&a.g("sec").n()).unwrap_or(std::cmp::Ordering::Equal));
    v.truncate(n);
    v
}

async fn spotify_seeds() -> R<Vec<Value>> {
    let mut list = spotify::top().await.unwrap_or_default();
    if list.len() < 3 {
        list.extend(spotify::recent_liked().await?);
    }
    shuffle(&mut list);
    let mut out = vec![];
    for t in list.iter().take(4) {
        if let Ok(s) = seed_track(t).await {
            if s.truthy() {
                out.push(s);
            }
        }
    }
    Ok(out)
}

async fn taste_wave() -> Vec<Value> {
    if !enabled("soundcloud") && !enabled("audius") {
        return vec![];
    }
    let (likes, history, matches, dislikes, dkeys) = {
        let l = lib();
        (
            l.g("likes").arr().to_vec(),
            l.g("history").arr().to_vec(),
            l.g("matches").clone(),
            l.g("dislikes").arr().iter().map(|x| x.sv()).collect::<HashSet<_>>(),
            l.g("dislikeKeys").arr().iter().map(|x| x.sv()).collect::<HashSet<_>>(),
        )
    };
    let mut seen: HashSet<String> = history.iter().take(40).map(id_of).collect();
    seen.extend(dislikes.iter().cloned());
    let likes: Vec<Value> = likes.into_iter().filter(|t| t.truthy() && t.g("id").truthy()).collect();
    let sc_likes: Vec<Value> = likes
        .iter()
        .map(|t| if id_of(t).starts_with("sc:") { t.clone() } else { matches.g(&id_of(t)).clone() })
        .filter(|t| t.g("id").s().starts_with("sc:"))
        .collect();
    let artists: Vec<String> = top_artists(12).iter().map(|a| a.g("name").s()).collect();
    let mut jobs: Vec<futures_util::future::BoxFuture<'static, R<Vec<Value>>>> = vec![];
    use futures_util::FutureExt;
    if enabled("soundcloud") {
        let mut s: Vec<Value> = sc_likes.iter().take(80).cloned().collect();
        shuffle(&mut s);
        for x in s.into_iter().take(4) {
            jobs.push(async move { soundcloud::related(&id_of(&x), 20).await }.boxed());
        }
        let mut a = artists.clone();
        shuffle(&mut a);
        for x in a.into_iter().take(3) {
            jobs.push(async move { soundcloud::search(&x, 12).await }.boxed());
        }
    }
    let r = join_all(jobs).await;
    let mut kt = likes.clone();
    kt.extend(history.iter().cloned());
    let known = extras::known_set(&kt, &artists.iter().map(|a| json!(a)).collect::<Vec<_>>());
    let mut fresh: Vec<Value> = r.into_iter().filter_map(|x| x.ok()).flatten().collect();
    shuffle(&mut fresh);
    let fresh: Vec<Value> = fresh
        .into_iter()
        .filter(|t| {
            t.truthy()
                && !t.g("preview").truthy()
                && t.g("streamable").truthy()
                && t.g("duration").n() > 60.0
                && t.g("q").as_str() != Some("drm")
                && !seen.contains(&id_of(t))
                && !dkeys.contains(&extras::song_key(t))
                && extras::relevant(t, &known)
        })
        .collect();
    let mut fav: Vec<Value> = likes.iter().filter(|t| !seen.contains(&id_of(t))).cloned().collect();
    shuffle(&mut fav);
    fav.truncate(6);
    let mut fav: std::collections::VecDeque<Value> = fav.into();
    let mut out: Vec<Value> = vec![];
    let mut ids = HashSet::new();
    for t in fresh {
        if out.len() >= 30 {
            break;
        }
        let last = out.last().map(|x| x.g("artist").s().to_lowercase()).unwrap_or_default();
        if t.g("artist").sv().to_lowercase() == last {
            continue;
        }
        if ids.insert(id_of(&t)) {
            out.push(t);
        }
        if out.len() % 5 == 4 {
            if let Some(f) = fav.pop_front() {
                if ids.insert(id_of(&f)) {
                    out.push(f);
                }
            }
        }
    }
    out
}

fn st_genre(tag: &str) -> Option<&'static str> {
    Some(match tag {
        "rusrap" => "russian rap",
        "foreignrap" | "rap" => "rap",
        "rusrock" => "russian rock",
        "ruspop" => "russian pop",
        "estrada" => "pop",
        "electronics" => "electronic",
        "dnb" => "drum & bass",
        "rnb" => "r&b",
        "local-indie" => "indie",
        "lounge" => "chill",
        "soundtrack" => "soundtrack",
        "hardrock" => "hard rock",
        "allrock" => "rock",
        "alternative" => "alternative",
        "folk" => "folk",
        "jazz" => "jazz",
        "classical" => "classical",
        "phonk" => "phonk",
        _ => return None,
    })
}
fn st_mood(tag: &str) -> Option<&'static str> {
    Some(match tag {
        "energetic" => "energetic",
        "happy" | "fun" | "cheerful" | "cool" => "fun",
        "sad" => "sad",
        "calm" | "dreamy" | "romantic" | "beautiful" => "calm",
        "aggressive" => "rock",
        _ => return None,
    })
}
fn st_activity(tag: &str) -> Option<&'static str> {
    Some(match tag {
        "workout" | "run" => "energetic",
        "wake-up" => "wakeup",
        "fall-asleep" | "sleep" => "sleep",
        "work-background" | "study" => "calm",
        "road-trip" | "driving" => "rock",
        "party" => "fun",
        _ => return None,
    })
}
fn st_epoch(tag: &str) -> Option<&'static str> {
    Some(match tag {
        "seventies" => "70s",
        "eighties" => "80s",
        "nineties" => "90s",
        "zeroes" => "2000s",
        "the-greatest-hits" => "classic hits",
        _ => return None,
    })
}
/// (genre, mood)
fn station_one(s: &str) -> Option<(Option<String>, Option<String>)> {
    let m = re!(r"^(genre|micro-genre|mood|activity|epoch):([A-Za-z0-9_\-.]{1,60})$").captures(s)?;
    let tag = m[2].to_lowercase();
    let words = re!(r"[-_.]+").replace_all(&tag, " ").trim().to_string();
    match &m[1] {
        "genre" | "micro-genre" => Some((Some(st_genre(&tag).map(String::from).unwrap_or(words)), None)),
        "mood" => Some(match st_mood(&tag) {
            Some(x) => (None, Some(x.into())),
            None => (Some(words), None),
        }),
        "activity" => st_activity(&tag).map(|x| (None, Some(x.to_string()))),
        _ => Some((Some(st_epoch(&tag).map(String::from).unwrap_or(words)), None)),
    }
}
fn station_wave(st: &str) -> Option<(Option<String>, Option<String>)> {
    let list: Vec<_> = st.split(',').take(8).filter_map(|x| station_one(x.trim())).collect();
    list.iter().find(|x| x.0.is_some()).cloned().or_else(|| list.first().cloned())
}

fn familiar_wave() -> Vec<Value> {
    let (likes, history, dis, dkeys) = {
        let l = lib();
        (
            l.g("likes").arr().to_vec(),
            l.g("history").arr().to_vec(),
            l.g("dislikes").arr().iter().map(|x| x.sv()).collect::<HashSet<_>>(),
            l.g("dislikeKeys").arr().iter().map(|x| x.sv()).collect::<HashSet<_>>(),
        )
    };
    let keep = |t: &&Value| {
        t.truthy()
            && t.g("id").truthy()
            && !dis.contains(&id_of(t))
            && !dkeys.contains(&extras::song_key(t))
            && !t.g("preview").truthy()
            && t.g("streamable") != &Value::Bool(false)
    };
    let likes = extras::uniq_tracks(&likes.iter().filter(keep).cloned().collect::<Vec<_>>());
    let played = extras::uniq_tracks(&history.iter().filter(keep).cloned().collect::<Vec<_>>());
    let recent: HashSet<String> = played.iter().take(50).map(id_of).collect();
    let fresh: Vec<Value> = likes.iter().filter(|t| !recent.contains(&id_of(t))).cloned().collect();
    let mut pick = if !fresh.is_empty() { fresh } else if !likes.is_empty() { likes } else { played };
    shuffle(&mut pick);
    pick.truncate(30);
    pick
}
fn familiar_fallback(reason: &str) -> R<Vec<Value>> {
    let list = familiar_wave();
    if list.is_empty() {
        return Err(E::new("Не удалось получить рекомендации. Войдите в Яндекс или добавьте треки в «Мне нравится»."));
    }
    note(&format!("{} — пока играют знакомые треки из вашей коллекции", reason));
    Ok(list)
}

async fn starter_wave() -> Vec<Value> {
    let (recent, bad, bad_keys) = {
        let l = lib();
        (
            l.g("history").arr().iter().take(60).map(id_of).collect::<HashSet<_>>(),
            l.g("dislikes").arr().iter().map(|x| x.sv()).collect::<HashSet<_>>(),
            l.g("dislikeKeys").arr().iter().map(|x| x.sv()).collect::<HashSet<_>>(),
        )
    };
    let filter = |list: &[Value], skip_recent: bool| -> Vec<Value> {
        let mut ids = HashSet::new();
        let mut keys = HashSet::new();
        list.iter()
            .filter(|t| {
                if !t.g("id").truthy()
                    || !t.g("title").truthy()
                    || t.g("preview").truthy()
                    || !t.g("streamable").truthy()
                    || !(t.g("duration").n() > 60.0)
                    || t.g("q").as_str() == Some("drm")
                    || censorship::marked_clean(t)
                    || bad.contains(&id_of(t))
                    || (skip_recent && recent.contains(&id_of(t)))
                {
                    return false;
                }
                let key = extras::song_key(t);
                if bad_keys.contains(&key) || ids.contains(&id_of(t)) || (!key.is_empty() && keys.contains(&key)) {
                    return false;
                }
                ids.insert(id_of(t));
                if !key.is_empty() {
                    keys.insert(key);
                }
                true
            })
            .cloned()
            .collect()
    };
    let mut pool = vec![];
    if enabled("soundcloud") {
        match soundcloud::charts("all-music", 80).await {
            Ok(p) => pool = p,
            Err(e) => blog(&format!("starter SoundCloud chart unavailable: {}", e.msg)),
        }
    }
    let mut playable = filter(&pool, true);
    if playable.is_empty() && enabled("audius") {
        match audius::trending().await {
            Ok(t) => playable = filter(&t, true),
            Err(e) => blog(&format!("starter Audius chart unavailable: {}", e.msg)),
        }
    }
    if playable.is_empty() {
        playable = filter(&pool, false);
    }
    let mut popular: Vec<Value> = playable.iter().filter(|t| t.g("plays").n() >= extras::PLAY_FLOOR).cloned().collect();
    let mut other: Vec<Value> = playable
        .iter()
        .filter(|t| { let p = t.g("plays").n(); p < extras::PLAY_FLOOR || !p.is_finite() })
        .cloned()
        .collect();
    shuffle(&mut popular);
    shuffle(&mut other);
    popular.extend(other);
    popular.truncate(30);
    if !popular.is_empty() {
        note("Пока у вас мало прослушиваний: включаю стартовую подборку. Лайки помогут настроить рекомендации");
    }
    popular
}

pub struct WaveOpt {
    pub mood: Option<String>,
    pub seed: Value,
    pub station: Option<String>,
    pub genre: Option<String>,
    pub diversity: Option<String>,
}

pub async fn wave(opt: WaveOpt) -> R<Vec<Value>> {
    let st_ = opt.station.as_deref().and_then(station_wave);
    let sw = setting("wave");
    let mood = match &opt.mood {
        Some(m) if crate::cfg::MOODS.contains(&m.as_str()) => m.clone(),
        _ => match &st_ {
            Some((_, Some(m))) if opt.genre.is_none() => m.clone(),
            _ => sw.g("mood").s(),
        },
    };
    let diversity = match &opt.diversity {
        Some(d) if ["default", "favorite", "discover", "popular"].contains(&d.as_str()) => d.clone(),
        _ => sw.g("diversity").s(),
    };
    let genre = opt.genre.clone().or_else(|| st_.as_ref().and_then(|x| x.0.clone()));
    let picked = opt.station.is_some() || genre.is_some();
    let src = setting("waveSource").s();
    let has_seed = opt.seed.truthy();
    let _ = mood_genres(&mood);
    if let Some(station) = &opt.station {
        if yandex::has_token() {
            match yandex_wave(&mood, &diversity, &Value::Null, Some(station)).await {
                Ok(l) if !l.is_empty() => return Ok(l),
                Ok(_) => {}
                Err(e) => blog(&format!("wave station unavailable: {}", e.msg)),
            }
        }
        return familiar_fallback("Подбор станции недоступен");
    }
    if (src == "yandex" || (src == "wave" && !has_seed && !picked)) && !picked {
        if yandex::has_token() {
            match yandex_wave(&mood, &diversity, &opt.seed, None).await {
                Ok(l) if !l.is_empty() => return Ok(l),
                Ok(_) => {}
                Err(e) => blog(&format!("personal Yandex wave unavailable: {}", e.msg)),
            }
            return familiar_fallback("Рекомендации Яндекса сейчас недоступны");
        }
        if src == "yandex" {
            return familiar_fallback("Вход в Яндекс не выполнен");
        }
    }
    if src == "likes" && !has_seed && !picked {
        let list = taste_wave().await;
        if list.len() >= 5 {
            return Ok(list);
        }
        return familiar_fallback("Недостаточно подходящих рекомендаций по вкусам");
    }
    let mut sp_seeds: Option<Vec<Value>> = None;
    if src == "spotify" && !has_seed {
        if !spotify::connected() {
            return familiar_fallback("Spotify не подключён");
        }
        sp_seeds = match spotify_seeds().await {
            Ok(s) if !s.is_empty() => Some(s),
            Ok(_) => None,
            Err(e) => {
                blog(&format!("Spotify recommendations unavailable: {}", e.msg));
                None
            }
        };
    }
    let (likes, history, matches, dislikes, dkeys) = {
        let l = lib();
        (
            l.g("likes").arr().to_vec(),
            l.g("history").arr().to_vec(),
            l.g("matches").clone(),
            l.g("dislikes").arr().iter().map(|x| x.sv()).collect::<HashSet<_>>(),
            l.g("dislikeKeys").arr().iter().map(|x| x.sv()).collect::<HashSet<_>>(),
        )
    };
    let mut seen: HashSet<String> = history.iter().take(60).map(id_of).collect();
    seen.extend(dislikes.iter().cloned());
    use futures_util::FutureExt;
    let mut jobs: Vec<futures_util::future::BoxFuture<'static, R<Vec<Value>>>> = vec![];
    if has_seed {
        if let Ok(s) = seed_track(&opt.seed).await {
            if s.truthy() {
                jobs.push(async move { soundcloud::related(&id_of(&s), 40).await }.boxed());
            }
        }
    }
    let seeds: Vec<Value> = match &sp_seeds {
        Some(s) => s.clone(),
        None => likes
            .iter()
            .chain(history.iter())
            .map(|t| if id_of(t).starts_with("sc:") { t.clone() } else { matches.g(&id_of(t)).clone() })
            .filter(|t| t.truthy() && id_of(t).starts_with("sc:"))
            .collect(),
    };
    if !has_seed && diversity != "discover" && !seeds.is_empty() && enabled("soundcloud") {
        // new Set() over objects keeps every element: no dedupe here
        let mut s: Vec<Value> = seeds.iter().take(40).cloned().collect();
        shuffle(&mut s);
        for x in s.into_iter().take(3) {
            jobs.push(async move { soundcloud::related(&id_of(&x), 25).await }.boxed());
        }
    }
    if diversity == "favorite" && !likes.is_empty() {
        let mut l = likes.clone();
        shuffle(&mut l);
        l.truncate(8);
        jobs.push(async move { Ok(l) }.boxed());
    }
    if enabled("soundcloud") && !has_seed {
        if let Some(g) = genre.clone() {
            jobs.push(async move { soundcloud::by_tag(&g, 40).await }.boxed());
        }
    }
    let r = join_all(jobs).await;
    let mut kt: Vec<Value> = likes.clone();
    kt.extend(history.iter().cloned());
    if has_seed {
        kt.push(opt.seed.clone());
    }
    if let Some(s) = &sp_seeds {
        kt.extend(s.iter().cloned());
    }
    let known = extras::known_set(&kt, &top_artists(40));
    let mut all: Vec<Value> = r.into_iter().filter_map(|x| x.ok()).flatten().collect();
    shuffle(&mut all);
    let mut out = vec![];
    let mut ids = HashSet::new();
    for t in all {
        if t.truthy()
            && !ids.contains(&id_of(&t))
            && !seen.contains(&id_of(&t))
            && !dkeys.contains(&extras::song_key(&t))
            && !t.g("preview").truthy()
            && t.g("streamable").truthy()
            && t.g("duration").n() > 60.0
            && extras::relevant(&t, &known)
        {
            ids.insert(id_of(&t));
            out.push(t);
        }
    }
    if src == "wave" && !has_seed && !picked && out.len() < 3 && likes.len() < 3 && history.len() < 20 {
        let starter = starter_wave().await;
        let mut c = out.clone();
        c.extend(starter);
        let combined = extras::uniq_tracks(&c);
        if !combined.is_empty() {
            return Ok(combined.into_iter().take(30).collect());
        }
    }
    if out.is_empty() {
        if familiar_wave().is_empty() && src == "wave" && !has_seed && !picked {
            return Err(E::new("Не удалось загрузить музыку. Проверьте интернет и включите SoundCloud или Audius в настройках."));
        }
        return familiar_fallback("Не нашлось подходящих рекомендаций");
    }
    out.truncate(30);
    Ok(out)
}

static WHEEL: Mutex<Option<(bool, Job)>> = Mutex::new(None);
pub fn reset_wheel() {
    *WHEEL.lock().unwrap() = None;
}
pub async fn wave_wheel() -> Value {
    let tok = yandex::has_token();
    if !tok && !enabled("yandex") {
        return json!({ "items": [], "source": "own" });
    }
    let job = {
        let mut w = WHEEL.lock().unwrap();
        match &*w {
            Some((t, j)) if *t == tok => j.clone(),
            _ => {
                let j = shared(async move {
                    let items = match yandex::wheel().await {
                        Ok(items) if items.iter().any(|x| x.g("station").truthy() || x.g("album").truthy()) => Ok(items),
                        Ok(_) => {
                            if tok {
                                yandex::wave_wheel().await
                            } else {
                                Ok(vec![])
                            }
                        }
                        Err(e) => {
                            if tok {
                                yandex::wave_wheel().await
                            } else {
                                Err(e)
                            }
                        }
                    };
                    match items {
                        Ok(items) => {
                            let src = if items.iter().any(|x| x.g("station").truthy() || x.g("album").truthy()) { "yandex" } else { "own" };
                            Ok(json!({ "items": items, "source": src }))
                        }
                        Err(e) => {
                            reset_wheel();
                            Ok(json!({ "items": [], "source": "own", "error": slice(&e.msg, 200) }))
                        }
                    }
                });
                *w = Some((tok, j.clone()));
                j
            }
        }
    };
    job.await.unwrap_or(json!({ "items": [], "source": "own" }))
}

/* ---------- artist cards: avatars, bios, banners, extras ---------- */
pub fn best_user(list: &[Value], name: &str) -> Value {
    let n = extras::norm_name(name);
    let ex: Vec<Value> = list.iter().filter(|u| extras::norm_name(&u.g("name").s()) == n).cloned().collect();
    let mut pool = if !ex.is_empty() { ex } else { list.iter().take(1).cloned().collect() };
    pool.sort_by(|a, b| b.g("followers").n().partial_cmp(&a.g("followers").n()).unwrap_or(std::cmp::Ordering::Equal));
    pool.into_iter().next().unwrap_or(Value::Null)
}

pub fn track_release(tracks: &Value) -> Value {
    let mut l: Vec<Value> = tracks
        .arr()
        .iter()
        .filter(|x| x.truthy() && re!(r"^\d{4}-\d{2}-\d{2}$").is_match(&x.g("released").s()))
        .cloned()
        .collect();
    l.sort_by(|a, b| b.g("released").s().cmp(&a.g("released").s()));
    match l.first() {
        Some(t) => json!({
            "id": t.g("id"), "title": t.g("title"), "owner": t.g("artist"), "artists": t.g("artists"),
            "cover": t.g("cover"), "date": t.g("released"), "kind": "Трек", "track": t, "source": t.g("source"),
        }),
        None => Value::Null,
    }
}

struct FileCache {
    name: &'static str,
    data: Mutex<Option<Map<String, Value>>>,
    max: usize,
    pending: AtomicBool,
}
impl FileCache {
    const fn new(name: &'static str, max: usize) -> FileCache {
        FileCache { name, data: Mutex::new(None), max, pending: AtomicBool::new(false) }
    }
    fn get(&self, k: &str) -> Value {
        self.load();
        self.data.lock().unwrap().as_ref().and_then(|m| m.get(k).cloned()).unwrap_or(Value::Null)
    }
    fn load(&self) {
        let mut d = self.data.lock().unwrap();
        if d.is_none() {
            let m = std::fs::read_to_string(p(self.name))
                .ok()
                .and_then(|t| serde_json::from_str::<Value>(&t).ok())
                .and_then(|v| v.as_object().cloned())
                .unwrap_or_default();
            *d = Some(m);
        }
    }
    fn set(&'static self, k: &str, v: Value) {
        self.load();
        if let Some(m) = self.data.lock().unwrap().as_mut() {
            m.insert(k.to_string(), v);
        }
        if self.pending.swap(true, Ordering::SeqCst) {
            return;
        }
        tokio::spawn(async move {
            tokio::time::sleep(Duration::from_millis(1500)).await;
            self.pending.store(false, Ordering::SeqCst);
            let json = {
                let mut d = self.data.lock().unwrap();
                let m = d.get_or_insert_with(Map::new);
                while m.len() > self.max {
                    let Some(k) = m.keys().next().cloned() else { break };
                    m.shift_remove(&k);
                }
                Value::Object(m.clone()).to_string()
            };
            let _ = tokio::fs::write(p(self.name), json).await;
        });
    }
}
static AVATARS: FileCache = FileCache::new("avatars.json", 3000);
static BANNERS: FileCache = FileCache::new("banners.json", 2000);
static BIOS: FileCache = FileCache::new("bios.json", 800);
static AV_JOBS: LazyLock<Jobs> = LazyLock::new(Jobs::new);
static BN_JOBS: LazyLock<Jobs> = LazyLock::new(Jobs::new);
static BIO_JOBS: LazyLock<Jobs> = LazyLock::new(Jobs::new);

async fn card_artist_run(name: String, id: String) -> Value {
    let mut r = Value::Null;
    let res = if id.starts_with("sc:") && enabled("soundcloud") {
        soundcloud::user_brief(&id).await
    } else if id.starts_with("au:") && enabled("audius") {
        audius::user(&id).await
    } else if id.starts_with("yar:") && enabled("yandex") {
        yandex::artist_brief(&id).await
    } else {
        Ok(Value::Null)
    };
    match res {
        Ok(v) => r = v,
        Err(e) => blog(&format!("artist avatar {}: {}", id, e.msg)),
    }
    if !r.truthy() && !name.is_empty() {
        if enabled("yandex") {
            r = yandex::find_artist(&name).await.unwrap_or(Value::Null);
        }
        if !r.truthy() && enabled("soundcloud") {
            r = best_user(&soundcloud::search_users(&name, 8).await.unwrap_or_default(), &name);
        }
        if !r.truthy() && enabled("audius") {
            r = best_user(&audius::search_users(&name, 5).await.unwrap_or_default(), &name);
        }
    }
    if !r.truthy() {
        return Value::Null;
    }
    let av = r.g("avatar").s();
    let avatar = if av.starts_with("https://") && !av.contains("default_avatar") { json!(av) } else { Value::Null };
    let rid = if r.g("id").truthy() { r.g("id").clone() } else if !id.is_empty() { json!(id) } else { Value::Null };
    json!({ "id": rid, "name": if r.g("name").truthy() { r.g("name").clone() } else { json!(name) }, "avatar": avatar })
}

pub async fn card_artist(name: &Value, id: &Value) -> Value {
    let name = slice(name.s().trim(), 100);
    let id = id.s();
    let id = if re!(r"^((sc|yar):\d{1,15}|au:[A-Za-z0-9]{1,24})$").is_match(&id) { id } else { String::new() };
    if name.is_empty() && id.is_empty() {
        return Value::Null;
    }
    let key = if !id.is_empty() { id.clone() } else { format!("n:{}", extras::norm_name(&name)) };
    let c = AVATARS.get(&key);
    if c.truthy() && now_ms() - c.g("at").n() < 7.0 * 864e5 {
        return c.g("a").clone();
    }
    let k2 = key.clone();
    let job = AV_JOBS.run(&key, move || async move {
        let a = card_artist_run(name, id).await;
        AVATARS.set(&k2, json!({ "at": jn(now_ms()), "a": a }));
        Ok(a)
    });
    job.await.unwrap_or(Value::Null)
}

async fn sc_banner(name: &str) -> Option<String> {
    if !enabled("soundcloud") {
        return None;
    }
    let n = extras::norm_name(name);
    let mut list: Vec<Value> = soundcloud::search_users(name, 8)
        .await
        .unwrap_or_default()
        .into_iter()
        .filter(|u| extras::norm_name(&u.g("name").s()) == n && u.g("followers").n() >= 1000.0 && u.g("banner").s().starts_with("https://"))
        .collect();
    list.sort_by(|a, b| b.g("followers").n().partial_cmp(&a.g("followers").n()).unwrap_or(std::cmp::Ordering::Equal));
    list.first().map(|u| u.g("banner").s())
}

/// the Spotify header picture needs a hidden browser window, which the phone does not have: like the Node build,
/// the Spotify lookup «fails» (retried in 6 hours) and the SoundCloud banner is used instead
async fn banner_of(src: &'static str, name: &str) -> Value {
    const BN_TTL: f64 = 30.0 * 864e5;
    const BN_MISS: f64 = 3.0 * 864e5;
    let key = format!("{}|{}", src, extras::norm_name(name));
    let c = BANNERS.get(&key);
    if c.truthy() && now_ms() - c.g("at").n() < if c.g("u").truthy() { BN_TTL } else { BN_MISS } {
        return c.g("u").clone();
    }
    let name = name.to_string();
    let k2 = key.clone();
    BN_JOBS
        .run(&key, move || async move {
            let (url, fail) = if src == "spotify" { (None, true) } else { (sc_banner(&name).await, false) };
            let at = if fail { now_ms() - BN_MISS + 6.0 * 3600e3 } else { now_ms() };
            let u = url.map(Value::String).unwrap_or(Value::Null);
            BANNERS.set(&k2, json!({ "at": jn(at), "u": u }));
            Ok(u)
        })
        .await
        .unwrap_or(Value::Null)
}

pub async fn artist_banner(name: &Value, source: &str) -> Value {
    let name = slice(name.s().trim(), 100);
    if name.is_empty() {
        return Value::Null;
    }
    let order: [&'static str; 2] = if source == "soundcloud" { ["soundcloud", "spotify"] } else { ["spotify", "soundcloud"] };
    for src in order {
        let u = banner_of(src, &name).await;
        if u.truthy() {
            return json!({ "url": u, "source": src });
        }
    }
    Value::Null
}

pub async fn artist_bio(name: &str, id: &str) -> Value {
    let k = extras::name_key(name);
    if k.is_empty() {
        return json!("");
    }
    let c = BIOS.get(&k);
    if c.truthy() && now_ms() - c.g("at").n() < if c.g("text").truthy() { 30.0 * 864e5 } else { 3.0 * 864e5 } {
        return c.g("text").clone();
    }
    let (name, id, k2) = (name.to_string(), id.to_string(), k.clone());
    BIO_JOBS
        .run(&k, move || async move {
            let mut text = String::new();
            if enabled("yandex") {
                let yid = if id.starts_with("yar:") { id.clone() } else { String::new() };
                text = yandex::artist_bio(&yid, &name).await.unwrap_or_default();
            }
            if text.is_empty() {
                text = extras::wiki_bio(&name, &app().version).await.unwrap_or_default();
            }
            BIOS.set(&k2, json!({ "text": text, "at": jn(now_ms()) }));
            Ok(json!(text))
        })
        .await
        .unwrap_or(json!(""))
}

static EXTRA: LazyLock<Mutex<(HashMap<String, (f64, Job)>, Vec<String>)>> = LazyLock::new(|| Mutex::new((HashMap::new(), vec![])));
pub async fn artist_extra(name: &str, want_similar: bool) -> R<Value> {
    let k = format!("{}{}", extras::name_key(name), if want_similar { "|s" } else { "" });
    let job = {
        let mut c = EXTRA.lock().unwrap();
        match c.0.get(&k) {
            Some((at, j)) if now_ms() - at < 3600e3 => j.clone(),
            _ => {
                let n = name.to_string();
                let j = shared(async move {
                    let (clips, similar) = tokio::join!(
                        async { if enabled("youtube") { youtube::clips(&n, 12).await.unwrap_or_default() } else { vec![] } },
                        async { if want_similar { extras::deezer_similar(&n, 16).await.unwrap_or_default() } else { vec![] } }
                    );
                    Ok(json!({ "clips": clips, "similar": similar }))
                });
                if !c.0.contains_key(&k) {
                    c.1.push(k.clone());
                }
                c.0.insert(k.clone(), (now_ms(), j.clone()));
                if c.0.len() > 40 {
                    let first = c.1.remove(0);
                    c.0.remove(&first);
                }
                j
            }
        }
    };
    job.await
}

/* ---------- import by link ---------- */
async fn expand_short(url: &str) -> String {
    if !re!(r"^https://(spotify\.link|on\.soundcloud\.com)/").is_match(url) {
        return url.to_string();
    }
    match crate::http::text(url, crate::http::Opts::new().timeout(15000)).await {
        Ok((_, final_url, _)) if !final_url.is_empty() => final_url,
        _ => url.to_string(),
    }
}
pub fn link_kind(url: &str) -> Option<&'static str> {
    let u = url::Url::parse(url).ok()?;
    let h = u.host_str()?;
    if re!(r"(^|\.)soundcloud\.com$").is_match(h) {
        return Some("soundcloud");
    }
    if re!(r"^music\.yandex\.").is_match(h) {
        return Some("yandex");
    }
    if re!(r"(^|\.)spotify\.(com|link)$").is_match(h) {
        return Some("spotify");
    }
    None
}
pub async fn load_link(raw: &str) -> R<Value> {
    let url = expand_short(raw.trim()).await;
    match link_kind(&url) {
        Some("soundcloud") => Ok(with(&soundcloud::resolve(&url).await?, json!({ "kind": "soundcloud" }))),
        Some("yandex") => Ok(with(&yandex::load(&url).await?, json!({ "kind": "yandex" }))),
        Some("spotify") => {
            let p = spotify::parse_url(&url);
            if let Some((ty, id)) = &p {
                if ty == "playlist" && spotify::connected() {
                    if let Ok(tracks) = spotify::playlist(&format!("spp:{}", id)).await {
                        if !tracks.is_empty() {
                            let e = spotify::embed(&url).await.ok();
                            let title = e.as_ref().map(|e| e.g("title").clone()).filter(|t| t.truthy()).unwrap_or(json!("Spotify"));
                            let cover = e.as_ref().map(|e| e.g("cover").clone()).filter(|t| t.truthy()).unwrap_or(Value::Null);
                            return Ok(json!({ "title": title, "cover": cover, "tracks": tracks, "kind": "spotify" }));
                        }
                    }
                }
            }
            let mut e = spotify::embed(&url).await?;
            if e.g("type").as_str() == Some("playlist") && e.g("tracks").arr().len() >= 100 && !spotify::connected() {
                crate::js::set(&mut e, "note", json!("Spotify без входа отдаёт только первые 100 треков. Подключите Spotify в настройках для полного импорта."));
            }
            Ok(with(&e, json!({ "kind": "spotify" })))
        }
        _ => Err(E::new("Поддерживаются ссылки SoundCloud, Яндекс Музыки и Spotify")),
    }
}

/* ---------- background matching of playlists ---------- */
fn is_matchable(t: &Value) -> bool {
    starts(&id_of(t), &["sp:", "ym:"])
}
struct MatchJob {
    cancel: Arc<AtomicBool>,
    done: futures_util::future::Shared<futures_util::future::BoxFuture<'static, ()>>,
}
static MATCH_JOBS: LazyLock<Mutex<HashMap<String, MatchJob>>> = LazyLock::new(|| Mutex::new(HashMap::new()));
fn running(pid: &str) -> bool {
    MATCH_JOBS.lock().unwrap().contains_key(pid)
}
fn playlist_by_id(l: &Value, pid: &str) -> Value {
    l.g("playlists").arr().iter().find(|x| x.g("id").s() == pid).cloned().unwrap_or(Value::Null)
}
pub fn match_stats(p: &Value) -> Value {
    let l = lib();
    let m: Vec<&Value> = p.g("tracks").arr().iter().filter(|t| is_matchable(t)).collect();
    if m.is_empty() {
        return Value::Null;
    }
    let pid = p.g("id").s();
    let r = running(&pid);
    json!({
        "total": m.len(),
        "found": m.iter().filter(|t| l.g("matches").g(&id_of(t)).truthy()).count(),
        "running": r,
        "stopped": p.g("matchStopped").truthy() && !r,
    })
}
fn match_snapshot(pid: &str, extra: Value) -> Value {
    let l = lib();
    let p = playlist_by_id(&l, pid);
    let all: Vec<&Value> = p.g("tracks").arr().iter().filter(|t| is_matchable(t)).collect();
    let r = running(pid);
    let base = json!({
        "type": "match", "id": pid, "total": all.len(),
        "found": all.iter().filter(|t| l.g("matches").g(&id_of(t)).truthy()).count(),
        "running": r, "stopped": p.g("matchStopped").truthy() && !r,
    });
    spread(&base, &extra)
}
fn set_playlist_field(pid: &str, k: &str, v: Value) {
    let mut l = lib();
    if let Some(p) = arr_mut(&mut l, "playlists").iter_mut().find(|x| x.g("id").s() == pid) {
        crate::js::set(p, k, v);
    }
}

pub fn match_playlist(pid: &str) {
    if running(pid) {
        return;
    }
    let (todo, src) = {
        let l = lib();
        let p = playlist_by_id(&l, pid);
        if !p.truthy() {
            return;
        }
        let todo: Vec<Value> =
            p.g("tracks").arr().iter().filter(|t| is_matchable(t) && !l.g("matches").g(&id_of(t)).truthy()).cloned().collect();
        (todo, p.g("matchSource").s())
    };
    set_playlist_field(pid, "matchStopped", json!(false));
    if todo.is_empty() {
        return;
    }
    let cancel = Arc::new(AtomicBool::new(false));
    let total = todo.len();
    let state = Arc::new(Mutex::new((0usize, 0usize, 0f64, 0usize))); // next index, done, last send, since save
    let todo = Arc::new(todo);
    let pid_s = pid.to_string();
    let send = {
        let pid = pid_s.clone();
        let state = state.clone();
        move |force: bool| {
            let done = {
                let mut s = state.lock().unwrap();
                let now = now_ms();
                if !force && now - s.2 < 800.0 {
                    return;
                }
                s.2 = now;
                s.1
            };
            emit(match_snapshot(&pid, json!({ "done": done, "todo": total })));
        }
    };
    let worker = {
        let (cancel, state, todo, pid, send) = (cancel.clone(), state.clone(), todo.clone(), pid_s.clone(), send.clone());
        let provs = providers_for(&src);
        move || {
            let (cancel, state, todo, pid, send, provs) = (cancel.clone(), state.clone(), todo.clone(), pid.clone(), send.clone(), provs.clone());
            async move {
                loop {
                    if cancel.load(Ordering::SeqCst) {
                        break;
                    }
                    let i = {
                        let mut s = state.lock().unwrap();
                        if s.0 >= todo.len() {
                            break;
                        }
                        s.0 += 1;
                        s.0 - 1
                    };
                    let t = &todo[i];
                    if let Ok(Some(m)) = find_match(t, &provs).await {
                        if !t.g("cover").truthy() && m.g("cover").truthy() {
                            let mut l = lib();
                            if let Some(p) = arr_mut(&mut l, "playlists").iter_mut().find(|x| x.g("id").s() == pid) {
                                if let Some(tr) = arr_mut(p, "tracks").iter_mut().find(|x| id_of(x) == id_of(t)) {
                                    crate::js::set(tr, "cover", m.g("cover").clone());
                                }
                            }
                        }
                    }
                    let save = {
                        let mut s = state.lock().unwrap();
                        s.1 += 1;
                        s.3 += 1;
                        if s.3 >= 25 {
                            s.3 = 0;
                            true
                        } else {
                            false
                        }
                    };
                    if save {
                        lib_save();
                    }
                    send(false);
                    tokio::time::sleep(Duration::from_millis(50)).await;
                }
            }
        }
    };
    use futures_util::FutureExt;
    let (c2, pid2, send2) = (cancel.clone(), pid_s.clone(), send.clone());
    let done = async move {
        tokio::join!(worker(), worker());
        MATCH_JOBS.lock().unwrap().remove(&pid2);
        set_playlist_field(&pid2, "matchStopped", json!(c2.load(Ordering::SeqCst)));
        lib_save();
        send2(true);
    }
    .boxed()
    .shared();
    MATCH_JOBS.lock().unwrap().insert(pid_s.clone(), MatchJob { cancel, done: done.clone() });
    tokio::spawn(done);
    send(true);
}

static MATCH_CHAIN: LazyLock<tokio::sync::Mutex<()>> = LazyLock::new(|| tokio::sync::Mutex::new(()));
pub fn match_sequential(pids: Vec<String>) {
    tokio::spawn(async move {
        let _g = MATCH_CHAIN.lock().await;
        for id in pids {
            match_playlist(&id);
            let d = MATCH_JOBS.lock().unwrap().get(&id).map(|j| j.done.clone());
            if let Some(d) = d {
                d.await;
            }
        }
    });
}
pub fn stop_match(pid: &str) {
    set_playlist_field(pid, "matchStopped", json!(true));
    if let Some(j) = MATCH_JOBS.lock().unwrap().get(pid) {
        j.cancel.store(true, Ordering::SeqCst);
    }
    lib_save();
}
pub async fn cancel_match_and_wait(pid: &str) {
    let d = MATCH_JOBS.lock().unwrap().get(pid).map(|j| {
        j.cancel.store(true, Ordering::SeqCst);
        j.done.clone()
    });
    if let Some(d) = d {
        d.await;
    }
}

/* ---------- own files ---------- */
pub const AUDIO_EXT: [&str; 13] = ["mp3", "wav", "flac", "ogg", "oga", "opus", "m4a", "aac", "mp4", "webm", "wma", "aif", "aiff"];
pub fn media_name_ok(n: &str) -> bool {
    re!(r"^[a-f0-9-]{36}\.(mp3|wav|flac|ogg|oga|opus|m4a|aac|mp4|webm|wma|aif|aiff|jpg|png)$").is_match(n)
}
pub fn mime_of(ext: &str) -> &'static str {
    match ext {
        "mp3" => "audio/mpeg",
        "wav" => "audio/wav",
        "flac" => "audio/flac",
        "ogg" | "oga" | "opus" => "audio/ogg",
        "m4a" | "mp4" => "audio/mp4",
        "aac" => "audio/aac",
        "webm" => "audio/webm",
        "wma" => "audio/x-ms-wma",
        "aif" | "aiff" => "audio/aiff",
        "jpg" => "image/jpeg",
        "png" => "image/png",
        _ => "application/octet-stream",
    }
}

/// delete uploaded files that are no longer in any playlist or in «Мне нравится» (call with the library locked)
pub fn gc_media(l: &mut Value) {
    let mut used = HashSet::new();
    for p in l.g("playlists").arr() {
        for t in p.g("tracks").arr() {
            if id_of(t).starts_with("lf:") {
                used.insert(id_of(t));
            }
        }
    }
    for t in l.g("likes").arr() {
        if id_of(t).starts_with("lf:") {
            used.insert(id_of(t));
        }
    }
    let files = obj_mut(l, "files");
    let gone: Vec<String> = files.keys().filter(|k| !used.contains(*k)).cloned().collect();
    for id in gone {
        if let Some(f) = files.shift_remove(&id) {
            for n in [f.g("file").s(), f.g("cover").s()] {
                if !n.is_empty() && media_name_ok(&n) {
                    let path = p("media").join(n);
                    tokio::spawn(async move {
                        let _ = tokio::fs::remove_file(path).await;
                    });
                }
            }
        }
    }
    let files = l.g("files").clone();
    let h: Vec<Value> =
        l.g("history").arr().iter().filter(|t| !id_of(t).starts_with("lf:") || files.g(&id_of(t)).truthy()).cloned().collect();
    crate::js::set(l, "history", Value::Array(h));
}
pub async fn sweep_media() -> usize {
    let keep: HashSet<String> = {
        let l = lib();
        match l.g("files") {
            Value::Object(m) => m.values().flat_map(|f| [f.g("file").s(), f.g("cover").s()]).filter(|n| !n.is_empty()).collect(),
            _ => HashSet::new(),
        }
    };
    let Ok(mut rd) = tokio::fs::read_dir(p("media")).await else { return 0 };
    let mut n = 0;
    while let Ok(Some(e)) = rd.next_entry().await {
        let name = e.file_name().to_string_lossy().into_owned();
        if media_name_ok(&name) && !keep.contains(&name) {
            let _ = tokio::fs::remove_file(e.path()).await;
            n += 1;
        }
    }
    n
}

pub fn take_pending() -> Vec<std::path::PathBuf> {
    std::mem::take(&mut *app().pending_files.lock().unwrap())
}

pub async fn upload_files(pid: &str) -> R<Value> {
    let files = take_pending();
    if files.is_empty() {
        return Ok(json!({ "added": 0, "tracks": [], "errors": [] }));
    }
    let media = p("media");
    let _ = tokio::fs::create_dir_all(&media).await;
    let mut added: Vec<Value> = vec![];
    let mut urls = Map::new();
    let mut errors: Vec<String> = vec![];
    for file in files.iter().take(300) {
        let base = file.file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_default();
        let r: R<(Value, String)> = async {
            let ext = file.extension().map(|s| s.to_string_lossy().to_lowercase()).unwrap_or_default();
            if !AUDIO_EXT.contains(&ext.as_str()) {
                return Err(E::new("этот формат не поддерживается"));
            }
            let md = tokio::fs::metadata(file).await.map_err(|e| E::new(e.to_string()))?;
            if !md.is_file() {
                return Err(E::new("это не файл"));
            }
            if md.len() > 1024 * 1024 * 1024 {
                return Err(E::new("файл больше 1 ГБ"));
            }
            let f2 = file.clone();
            let meta = tokio::task::spawn_blocking(move || crate::providers::tags::read(&f2)).await.map_err(|e| E::new(e.to_string()))?;
            let uuid = uuid::Uuid::new_v4().to_string();
            let name = format!("{}.{}", uuid, ext);
            tokio::fs::copy(file, media.join(&name)).await.map_err(|e| E::new(e.to_string()))?;
            let mut cover_name = Value::Null;
            if let Some((mime, data)) = &meta.cover {
                if !data.is_empty() {
                    let cn = format!("{}{}", uuid, if mime.to_lowercase().contains("png") { ".png" } else { ".jpg" });
                    tokio::fs::write(media.join(&cn), data).await.map_err(|e| E::new(e.to_string()))?;
                    cover_name = json!(cn);
                }
            }
            let id = format!("lf:{}", uuid);
            {
                let mut l = lib();
                obj_mut(&mut l, "files").insert(
                    id.clone(),
                    json!({ "file": name, "cover": cover_name, "name": slice(&base, 200), "size": md.len(), "added": jn(now_ms()) }),
                );
            }
            let t = clean_track(&json!({
                "id": id, "source": "local",
                "title": slice(if meta.title.is_empty() { &base } else { &meta.title }, 300),
                "artist": slice(if meta.artist.is_empty() { "Неизвестный исполнитель" } else { &meta.artist }, 300),
                "artists": [], "album": meta.album, "duration": 0,
                "cover": if cover_name.truthy() { json!(format!("wave-media://media/{}", cover_name.s())) } else { Value::Null },
                "preview": false, "streamable": true,
            }))?;
            Ok((t, name))
        }
        .await;
        match r {
            Ok((t, name)) => {
                {
                    let mut l = lib();
                    if let Some(p) = arr_mut(&mut l, "playlists").iter_mut().find(|x| x.g("id").s() == pid) {
                        arr_mut(p, "tracks").push(t.clone());
                    }
                }
                urls.insert(id_of(&t), json!(format!("wave-media://media/{}", name)));
                added.push(t);
            }
            Err(e) => errors.push(format!("{}: {}", base, e.msg)),
        }
    }
    lib_save();
    let count = playlist_by_id(&lib(), pid).g("tracks").arr().len();
    Ok(json!({ "added": added.len(), "tracks": added, "urls": urls, "errors": errors, "count": count }))
}

pub fn rank_concerts(data: Value) -> Value {
    let mut names: Vec<String> = vec![];
    let mut seen = HashSet::new();
    for t in lib().g("likes").arr() {
        let list: Vec<String> = if !t.g("artists").arr().is_empty() {
            t.g("artists").arr().iter().map(|x| x.g("name").s()).collect()
        } else {
            re!(r",\s*").split(&t.g("artist").s()).map(String::from).collect()
        };
        for a in list {
            let n = extras::norm_name(&a);
            if n.chars().count() >= 3 && seen.insert(n.clone()) {
                names.push(n);
            }
        }
    }
    if names.is_empty() {
        return data;
    }
    names.truncate(600);
    let mut events: Vec<Value> = data
        .g("events")
        .arr()
        .iter()
        .map(|e| {
            let nt = format!(" {} ", extras::norm_name(&e.g("title").s()));
            if names.iter().any(|n| nt.contains(&format!(" {} ", n))) {
                with(e, json!({ "forYou": true }))
            } else {
                e.clone()
            }
        })
        .collect();
    events.sort_by_key(|e| if e.g("forYou").truthy() { 0 } else { 1 });
    let fy = events.iter().filter(|e| e.g("forYou").truthy()).count();
    with(&data, json!({ "events": events, "forYou": fy }))
}

pub fn playlist_summaries() -> Value {
    let l = lib();
    json!(l
        .g("playlists")
        .arr()
        .iter()
        .map(|p| {
            let mut o = p.as_object().cloned().unwrap_or_default();
            o.shift_remove("tracks");
            let cover = if p.g("cover").truthy() {
                p.g("cover").clone()
            } else if p.g("tracks").at(0).g("cover").truthy() {
                p.g("tracks").at(0).g("cover").clone()
            } else {
                Value::Null
            };
            o.insert("count".into(), json!(p.g("tracks").arr().len()));
            o.insert("cover".into(), cover);
            Value::Object(o)
        })
        .collect::<Vec<_>>())
}

/// a picture picked with the Android picker (the interface already made a JPEG of it)
pub fn pick_image_data() -> R<Value> {
    let files = take_pending();
    let Some(file) = files.first() else { return Ok(Value::Null) };
    let md = std::fs::metadata(file).map_err(|e| E::new(e.to_string()))?;
    if md.len() > 25 * 1024 * 1024 {
        return Err(E::new("Файл больше 25 МБ"));
    }
    use base64::Engine;
    let buf = std::fs::read(file).map_err(|e| E::new(e.to_string()))?;
    let b64 = base64::engine::general_purpose::STANDARD.encode(&buf);
    // 4.20.3: live (animated) pictures keep their own format: GIF, animated WebP, APNG
    let live = if buf.starts_with(b"GIF8") {
        "gif"
    } else if buf.len() > 12 && &buf[0..4] == b"RIFF" && &buf[8..12] == b"WEBP" {
        "webp"
    } else if buf.starts_with(b"\x89PNG") {
        "png"
    } else {
        ""
    };
    if !live.is_empty() && md.len() < 6 * 1024 * 1024 {
        return Ok(json!(format!("data:image/{};base64,{}", live, b64)));
    }
    if buf.is_empty() {
        return Err(E::new("Не удалось прочитать изображение (подходят PNG, JPG и GIF)"));
    }
    Ok(json!(format!("data:image/jpeg;base64,{}", b64)))
}

/* ---------- history / listening time ---------- */
pub fn push_history(t: &Value) -> R<()> {
    let c = clean_track(t)?;
    let id = id_of(&c);
    {
        let mut l = lib();
        let h = arr_mut(&mut l, "history");
        h.retain(|x| id_of(x) != id);
        h.insert(0, c);
        h.truncate(200);
    }
    lib_save();
    Ok(())
}
fn artist_key(name: &str) -> String {
    slice(&extras::norm_words(name), 80)
}
pub fn add_listen(t: &Value, sec: f64) {
    let list: Vec<Value> = if !t.g("artists").arr().is_empty() {
        t.g("artists").arr().to_vec()
    } else {
        re!(r"\s*,\s*").split(&t.g("artist").s()).map(|n| json!({ "name": n })).collect()
    };
    let list: Vec<Value> = list.into_iter().filter(|a| a.truthy() && !artist_key(&a.g("name").s()).is_empty()).take(4).collect();
    {
        let mut l = lib();
        let a = obj_mut(&mut l, "artistTime");
        for x in &list {
            let k = artist_key(&x.g("name").s());
            let e = a.entry(k).or_insert_with(|| json!({ "name": slice(&x.g("name").sv(), 150), "id": null, "sec": 0 }));
            let s = crate::js::round(e.g("sec").n() + sec);
            crate::js::set(e, "sec", jn(s));
            crate::js::set(e, "at", jn(now_ms()));
            if !e.g("id").truthy() && x.g("id").truthy() {
                crate::js::set(e, "id", x.g("id").clone());
            }
            if t.g("cover").truthy() && !e.g("cover").truthy() {
                crate::js::set(e, "cover", t.g("cover").clone());
            }
        }
        if a.len() > 2500 {
            let mut keys: Vec<(String, f64)> = a.iter().map(|(k, v)| (k.clone(), v.g("sec").n())).collect();
            keys.sort_by(|x, y| x.1.partial_cmp(&y.1).unwrap_or(std::cmp::Ordering::Equal));
            let n = keys.len() - 2000;
            for (k, _) in keys.into_iter().take(n) {
                a.shift_remove(&k);
            }
        }
    }
    lib_save();
}

/* ---------- Yandex «Мне нравится» → Wave likes, continuously ---------- */
static YM_SYNC: LazyLock<Jobs> = LazyLock::new(Jobs::new);

fn ym_likes_state(l: &mut Value) -> Value {
    let y = if l.g("ymLikes").is_object() { l.g("ymLikes").clone() } else { json!({}) };
    let strs = |v: &Value| -> Vec<Value> { v.arr().iter().filter(|x| x.is_string()).take(50000).cloned().collect() };
    let mut s = y.clone();
    crate::js::set(&mut s, "rev", if y.g("rev").as_f64().map(|x| x.is_finite()).unwrap_or(false) { y.g("rev").clone() } else { Value::Null });
    crate::js::set(&mut s, "seen", if y.g("seen").is_array() { json!(strs(y.g("seen"))) } else { Value::Null });
    crate::js::set(&mut s, "added", json!(strs(y.g("added"))));
    crate::js::set(&mut s, "at", if y.g("at").as_f64().map(|x| x.is_finite()).unwrap_or(false) { y.g("at").clone() } else { json!(0) });
    crate::js::set(&mut s, "order", json!(if y.g("order").as_f64() == Some(2.0) { 2 } else { 0 }));
    crate::js::set(l, "ymLikes", s.clone());
    s
}

async fn ym_likes_sync_run(force: bool) -> R<Value> {
    if !yandex::has_token() || setting("ymLikesSync") == Value::Bool(false) {
        return Ok(Value::Null);
    }
    let st0 = ym_likes_state(&mut lib());
    let (rev, ids) = yandex::liked_ids().await?;
    {
        let mut l = lib();
        l["ymLikes"]["at"] = jn(now_ms());
    }
    let rev_v = rev.map(jn).unwrap_or(Value::Null);
    if !force && st0.g("seen").is_array() && rev.is_some() && st0.g("rev").as_f64() == rev {
        return Ok(json!({ "added": 0, "removed": 0 }));
    }
    let now: HashSet<String> = ids.iter().cloned().collect();
    let seen: HashSet<String> = st0.g("seen").arr().iter().map(|x| x.sv()).collect();
    let have: HashSet<String> = lib().g("likes").arr().iter().map(id_of).collect();
    let fresh: Vec<String> = crate::js::uniq_strings(ids.iter().cloned())
        .into_iter()
        .filter(|id| !seen.contains(id) && !have.contains(&format!("ym:{}", id)))
        .collect();
    let mut add: Vec<Value> = vec![];
    if !fresh.is_empty() {
        let got = yandex::tracks_by_ids(&fresh.into_iter().take(10000).collect::<Vec<_>>()).await?;
        let likes = lib().g("likes").arr().to_vec();
        let mut hv: HashSet<String> = likes.iter().map(id_of).collect();
        for raw in got {
            if let Ok(t) = clean_track(&raw) {
                if hv.insert(id_of(&t)) {
                    add.push(t);
                }
            }
        }
    }
    let ord: HashMap<String, usize> = ids.iter().enumerate().map(|(i, id)| (format!("ym:{}", id), i)).collect();
    add.sort_by_key(|t| ord.get(&id_of(t)).cloned().unwrap_or(1_000_000_000));
    let mut added_set: Vec<String> = st0.g("added").arr().iter().map(|x| x.sv()).collect();
    let removed: Vec<String> = if st0.g("seen").is_array() {
        added_set.iter().filter(|id| !now.contains(*id) && seen.contains(*id)).cloned().collect()
    } else {
        vec![]
    };
    {
        let mut l = lib();
        if !removed.is_empty() {
            let rm: HashSet<String> = removed.iter().map(|id| format!("ym:{}", id)).collect();
            arr_mut(&mut l, "likes").retain(|t| !rm.contains(&id_of(t)));
            added_set.retain(|id| !removed.contains(id));
        }
        if !add.is_empty() {
            let mut n = add.clone();
            n.extend(l.g("likes").arr().iter().cloned());
            crate::js::set(&mut l, "likes", Value::Array(n));
            for t in &add {
                let s = id_of(t).trim_start_matches("ym:").to_string();
                if !added_set.contains(&s) {
                    added_set.push(s);
                }
            }
        }
        let st = &mut l["ymLikes"];
        crate::js::set(st, "seen", json!(ids.iter().take(50000).collect::<Vec<_>>()));
        crate::js::set(st, "rev", rev_v);
        crate::js::set(st, "added", json!(added_set.into_iter().filter(|id| now.contains(id)).take(50000).collect::<Vec<_>>()));
    }
    for t in add.iter().take(3) {
        let t = t.clone();
        tokio::spawn(async move {
            let _ = find_match(&t, &full_sources()).await;
        });
    }
    lib_save();
    if !add.is_empty() || !removed.is_empty() {
        emit(json!({ "type": "likes-sync", "added": add.len(), "removed": removed.len(), "first": seen.is_empty() }));
    }
    blog(&format!("ym likes sync: +{} -{}", add.len(), removed.len()));
    Ok(json!({ "added": add.len(), "removed": removed.len() }))
}

pub async fn ym_likes_sync(force: bool) -> R<Value> {
    YM_SYNC.run("sync", move || ym_likes_sync_run(force)).await
}
pub fn ym_likes_sync_later(ms: u64) {
    tokio::spawn(async move {
        tokio::time::sleep(Duration::from_millis(ms)).await;
        if let Err(e) = ym_likes_sync(false).await {
            blog(&format!("ym likes sync: {}", e.msg));
        }
    });
}
pub fn ym_likes_schedule() {
    ym_likes_sync_later(20000);
    tokio::spawn(async {
        let mut iv = tokio::time::interval(Duration::from_secs(180));
        iv.tick().await;
        loop {
            iv.tick().await;
            if let Err(e) = ym_likes_sync(false).await {
                blog(&format!("ym likes sync: {}", e.msg));
            }
        }
    });
}
pub fn ym_seen_add(ids: &[String]) {
    let mut l = lib();
    let st = ym_likes_state(&mut l);
    let mut seen: Vec<String> = st.g("seen").arr().iter().map(|x| x.sv()).collect();
    seen.extend(ids.iter().cloned());
    let seen: Vec<String> = crate::js::uniq_strings(seen).into_iter().take(50000).collect();
    l["ymLikes"]["seen"] = json!(seen);
}

/* ---------- tokens of the accounts ---------- */
pub fn save_ym_token(t: Option<&str>) {
    yandex::set_token(t);
    reset_wheel();
    let f = p("yandex-token.bin");
    match t {
        None => {
            let _ = std::fs::remove_file(f);
        }
        Some(t) => {
            if let Some(b) = crate::vault::encrypt(&app().data, t) {
                let _ = std::fs::write(f, b);
            }
        }
    }
}
pub fn load_ym_token() {
    if let Ok(b) = std::fs::read(p("yandex-token.bin")) {
        if let Some(t) = crate::vault::decrypt(&app().data, &b) {
            yandex::set_token(Some(&t));
        }
    }
}
