//! Concerts from Yandex Afisha: the public selection page, the event list read from the embedded Apollo state.

use crate::http::{Opts, NOREDIRECT, UA};
use crate::js::{jn, now_ms, round, slice, J, E, R};
use crate::re;
use serde_json::{json, Map, Value};
use std::collections::{HashMap, HashSet};
use std::sync::{LazyLock, Mutex};

const BASE: &str = "https://afisha.yandex.ru";
pub const CITIES: [(&str, &str); 37] = [
    ("moscow", "Москва"),
    ("saint-petersburg", "Санкт-Петербург"),
    ("novosibirsk", "Новосибирск"),
    ("yekaterinburg", "Екатеринбург"),
    ("kazan", "Казань"),
    ("nizhny-novgorod", "Нижний Новгород"),
    ("chelyabinsk", "Челябинск"),
    ("samara", "Самара"),
    ("togliatti", "Тольятти"),
    ("ufa", "Уфа"),
    ("rostov-na-donu", "Ростов-на-Дону"),
    ("krasnodar", "Краснодар"),
    ("sochi", "Сочи"),
    ("omsk", "Омск"),
    ("krasnoyarsk", "Красноярск"),
    ("voronezh", "Воронеж"),
    ("perm", "Пермь"),
    ("volgograd", "Волгоград"),
    ("saratov", "Саратов"),
    ("tyumen", "Тюмень"),
    ("izhevsk", "Ижевск"),
    ("barnaul", "Барнаул"),
    ("ulyanovsk", "Ульяновск"),
    ("irkutsk", "Иркутск"),
    ("khabarovsk", "Хабаровск"),
    ("yaroslavl", "Ярославль"),
    ("vladivostok", "Владивосток"),
    ("tomsk", "Томск"),
    ("orenburg", "Оренбург"),
    ("kemerovo", "Кемерово"),
    ("ryazan", "Рязань"),
    ("penza", "Пенза"),
    ("lipetsk", "Липецк"),
    ("kaliningrad", "Калининград"),
    ("tula", "Тула"),
    ("kirov", "Киров"),
    ("cheboksary", "Чебоксары"),
];

pub fn valid_city(c: &Value) -> String {
    match c.as_str() {
        Some(s) if re!(r"^[a-z][a-z0-9-]{1,40}$").is_match(s) => s.to_string(),
        _ => String::new(),
    }
}

async fn fetch_page(url: &str) -> R<String> {
    let (st, final_url, html) = crate::http::text(
        url,
        Opts::new()
            .h("User-Agent", UA)
            .h("Accept", "text/html,application/xhtml+xml")
            .h("Accept-Language", "ru-RU,ru;q=0.9")
            .timeout(20000),
    )
    .await?;
    let head = slice(&html, 20000);
    if re!(r"(?i)showcaptcha|smartcaptcha|captcha\.yandex").is_match(&final_url) || re!(r"(?i)<form[^>]+captcha").is_match(&head) {
        let mut e = E::new("Афиша попросила подтвердить, что вы не робот. Откройте afisha.yandex.ru в браузере");
        e.captcha = true;
        return Err(e);
    }
    if !(200..300).contains(&st) {
        return Err(E::new(format!("Афиша ответила HTTP {}", st)).status(st));
    }
    Ok(html)
}

async fn detect_city() -> String {
    let r = crate::http::fetch(
        &NOREDIRECT,
        &format!("{}/", BASE),
        &Opts::new().h("User-Agent", UA).h("Accept-Language", "ru-RU,ru;q=0.9").timeout(10000),
    )
    .await;
    if let Ok(r) = r {
        let loc = r.headers().get("location").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
        if let Some(m) = re!(r"^(?:https://afisha\.yandex\.[a-z]+)?/([a-z][a-z0-9-]+)/?$").captures(&loc) {
            if re!(r"^[a-z][a-z0-9-]{1,40}$").is_match(&m[1]) {
                return m[1].to_string();
            }
        }
    }
    "moscow".into()
}

fn script_json(html: &str, name: &str) -> Value {
    let key = format!("window['{}'] = ", name);
    let Some(i) = html.find(&key) else { return Value::Null };
    let Some(end) = html[i..].find("</script>").map(|e| e + i) else { return Value::Null };
    let mut s = html[i + key.len()..end].trim();
    if let Some(x) = s.strip_suffix(';') {
        s = x;
    }
    serde_json::from_str(s).unwrap_or(Value::Null)
}

fn pick_img(img: &Value, sizes: &[&str]) -> Value {
    if !img.is_object() {
        return Value::Null;
    }
    for s in sizes {
        let v = img.g(&format!("image({{\"size\":\"{}\"}})", s));
        let u = v.g("url").s();
        if u.starts_with("https://") {
            return json!(u);
        }
    }
    Value::Null
}

fn deref<'a>(state: &'a Value, v: &'a Value) -> &'a Value {
    if v.g("__ref").truthy() {
        state.g(&v.g("__ref").s())
    } else {
        v
    }
}

fn map_event(state: &Value, act: &Value) -> Option<Value> {
    let ev = deref(state, act.g("event"));
    if !ev.truthy() || !ev.g("title").truthy() || !ev.g("url").truthy() {
        return None;
    }
    let si = act.g("scheduleInfo");
    let tickets: Vec<&Value> = ev.g("tickets").arr().iter().map(|t| deref(state, t)).filter(|t| t.truthy()).collect();
    let mut mins: Vec<f64> = tickets.iter().map(|t| t.path(&["price", "min"]).as_f64().unwrap_or(f64::NAN)).collect();
    mins.extend(si.g("prices").arr().iter().map(|p| p.g("value").as_f64().unwrap_or(f64::NAN)));
    let mins: Vec<f64> = mins.into_iter().filter(|v| v.is_finite() && *v > 0.0).collect();
    let when = [si.path(&["regularity", "singleShowtime"]), si.g("dates").at(0), si.g("dateStarted")]
        .into_iter()
        .find(|v| v.truthy())
        .cloned()
        .unwrap_or(Value::Null);
    let promo = ev.g("promoImage({\"type\":\"preview_new_desktop\"})");
    let place = if si.path(&["onlyPlace", "__ref"]).truthy() { state.g(&si.path(&["onlyPlace", "__ref"]).s()) } else { &crate::js::NULL };
    let rub = ev.g("rubric({\"codeNotIn\":[\"other\"]})").at(0).g("name");
    let kind = if rub.truthy() {
        rub.clone()
    } else if ev.path(&["type", "name"]).truthy() {
        ev.path(&["type", "name"]).clone()
    } else {
        json!("Концерт")
    };
    let image = {
        let p = pick_img(promo, &["s760x440_crop", "s380x220_crop"]);
        if p.truthy() {
            p
        } else {
            pick_img(ev.g("image"), &["s760x440_crop", "s760x380_crop", "s380x220_crop", "s270x135_crop", "origin"])
        }
    };
    let id = if ev.g("id").truthy() { ev.g("id").sv() } else { ev.g("url").sv() };
    let pp = si.g("placePreview");
    Some(json!({
        "id": id,
        "title": slice(&ev.g("title").sv(), 200),
        "url": format!("{}{}", BASE, re!(r"^https?://[^/]+").replacen(&ev.g("url").sv(), 1, "")),
        "kind": kind,
        "rating": ev.g("contentRating").as_str().unwrap_or(""),
        "argument": ev.g("argument").as_str().map(|s| slice(s, 200)).unwrap_or_default(),
        "date": if when.is_string() { when } else { Value::Null },
        "dates": si.g("dates").arr().iter().take(20).cloned().collect::<Vec<_>>(),
        "dateText": si.g("preview({\"short\":false})").g("text").s(),
        "place": if pp.truthy() { pp.clone() } else { json!(place.g("title").s()) },
        "address": place.g("address").s(),
        "price": if mins.is_empty() { Value::Null } else { jn(round(mins.iter().cloned().fold(f64::INFINITY, f64::min) / 100.0)) },
        "image": image,
        "poster": pick_img(ev.g("image"), &["s480x600_crop", "s240x300_crop"]),
        "color": if ev.path(&["image", "bgColor"]).truthy() { ev.path(&["image", "bgColor"]).clone() } else { Value::Null },
        "soldOut": !tickets.is_empty() && tickets.iter().all(|t| t.g("saleStatus").truthy() && t.g("saleStatus").as_str() != Some("available")),
    }))
}

fn parse_events(html: &str) -> R<(String, Vec<Value>)> {
    let state = script_json(html, "__APOLLO_STATE__");
    if !state.is_object() {
        return Err(E::new("Афиша изменила формат страницы — не удалось прочитать события"));
    }
    let mut acts: Vec<Value> = vec![];
    let mut seen = HashSet::new();
    fn walk(o: &Value, depth: u32, acts: &mut Vec<Value>, seen: &mut HashSet<String>) {
        if (!o.is_object() && !o.is_array()) || depth > 12 {
            return;
        }
        if let Value::Array(a) = o {
            for x in a {
                walk(x, depth + 1, acts, seen);
            }
            return;
        }
        if o.g("__typename").as_str() == Some("ActualEvent") && o.g("event").truthy() {
            let r = if o.path(&["event", "__ref"]).truthy() { o.path(&["event", "__ref"]).sv() } else { o.path(&["event", "id"]).sv() };
            if seen.insert(r) {
                acts.push(o.clone());
            }
            return;
        }
        if let Value::Object(m) = o {
            for v in m.values() {
                walk(v, depth + 1, acts, seen);
            }
        }
    }
    walk(state.g("ROOT_QUERY"), 0, &mut acts, &mut seen);
    if let Value::Object(m) = &state {
        for (k, v) in m {
            if k != "ROOT_QUERY" {
                walk(v, 0, &mut acts, &mut seen);
            }
        }
    }
    let api = script_json(html, "__apiParams");
    Ok((api.path(&["city", "name"]).s(), acts.iter().filter_map(|a| map_event(&state, a)).collect()))
}

static CACHE: LazyLock<Mutex<HashMap<String, (f64, Value)>>> = LazyLock::new(|| Mutex::new(HashMap::new()));

pub async fn concerts(city: &str) -> R<Value> {
    let mut slug = valid_city(&json!(city));
    if slug.is_empty() {
        slug = detect_city().await;
    }
    if let Some((at, d)) = CACHE.lock().unwrap().get(&slug) {
        if now_ms() - at < 30.0 * 60.0 * 1000.0 {
            return Ok(d.clone());
        }
    }
    let sel = format!("{}/{}/selections/all-events-concert", BASE, slug);
    let (p1, p2) = tokio::join!(fetch_page(&sel), async { fetch_page(&format!("{}?page=2", sel)).await });
    let (city_name, a) = parse_events(&p1?)?;
    let b = p2.ok().and_then(|h| parse_events(&h).ok()).map(|x| x.1).unwrap_or_default();
    let mut ids = HashSet::new();
    let events: Vec<Value> = a.into_iter().chain(b).filter(|e| ids.insert(e.g("id").s())).collect();
    if events.is_empty() {
        return Err(E::new("На Афише пока нет концертов для этого города"));
    }
    let cn = if !city_name.is_empty() {
        city_name
    } else {
        CITIES.iter().find(|c| c.0 == slug).map(|c| c.1.to_string()).unwrap_or(slug.clone())
    };
    let mut m = Map::new();
    m.insert("city".into(), json!(slug));
    m.insert("cityName".into(), json!(cn));
    m.insert("url".into(), json!(format!("{}/{}/concert", BASE, slug)));
    m.insert("events".into(), json!(events));
    m.insert("cities".into(), json!(CITIES.iter().map(|c| json!([c.0, c.1])).collect::<Vec<_>>()));
    let data = Value::Object(m);
    CACHE.lock().unwrap().insert(slug, (now_ms(), data.clone()));
    Ok(data)
}
