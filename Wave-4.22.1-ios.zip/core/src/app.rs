//! The process-wide state of the backend: paths, the start key, the two JSON stores, the event channel of the
//! interface (server-sent events), the start-up journal and a «single flight» helper (the JS Map<key, Promise>).

use crate::js::{E, J, R};
use crate::store::Store;
use futures_util::future::{BoxFuture, FutureExt, Shared};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::future::Future;
use std::path::PathBuf;
use std::sync::{Arc, Mutex, OnceLock};

pub struct App {
    pub data: PathBuf,
    pub ui: PathBuf,
    pub port: u16,
    pub key: String,
    pub version: String,
    pub settings: Arc<Store>,
    pub library: Arc<Store>,
    pub events: tokio::sync::broadcast::Sender<String>,
    pub pending_files: Mutex<Vec<PathBuf>>,
}

static APP: OnceLock<App> = OnceLock::new();

pub fn init(a: App) {
    let _ = APP.set(a);
}
pub fn app() -> &'static App {
    APP.get().expect("wave app not initialised")
}
pub fn p(f: &str) -> PathBuf {
    app().data.join(f)
}
pub fn media_base() -> String {
    let a = app();
    format!("http://127.0.0.1:{}/m/{}/", a.port, a.key)
}

/// wave-media://host/path inside answers → an address of this server (the <audio> of the WebView cannot open
/// custom schemes)
pub fn fix_urls(json: &str) -> String {
    json.replace("wave-media://", &media_base())
}
pub fn unfix_urls(v: Value) -> Value {
    let base = media_base();
    let s = v.to_string();
    if s.contains(&base) {
        serde_json::from_str(&s.replace(&base, "wave-media://")).unwrap_or(v)
    } else {
        v
    }
}

fn sse(kind: &str, value: Value) {
    let line = format!("data: {}\n\n", fix_urls(&json!({ "kind": kind, "value": value }).to_string()));
    let _ = app().events.send(line);
}
/// `main.webContents.send("wave:event", value)`
pub fn emit(value: Value) {
    sse("event", value);
}
/// a request for the phone (open a link, copy, sign-in windows)
pub fn native(value: Value) {
    sse("native", value);
}
/// a short message in the interface
pub fn note(text: &str) {
    emit(json!({ "type": "note", "text": text }));
}

#[cfg(target_os = "android")]
mod alog {
    use std::ffi::CString;
    use std::os::raw::{c_char, c_int};
    #[link(name = "log")]
    extern "C" {
        fn __android_log_write(prio: c_int, tag: *const c_char, text: *const c_char) -> c_int;
    }
    pub fn write(s: &str) {
        let tag = CString::new("WaveNode").unwrap();
        let text = CString::new(s.replace('\0', " ")).unwrap_or_default();
        unsafe {
            __android_log_write(4, tag.as_ptr(), text.as_ptr());
        }
    }
}
#[cfg(not(target_os = "android"))]
mod alog {
    pub fn write(s: &str) {
        eprintln!("[wave] {}", s);
    }
}

pub fn log(s: &str) {
    alog::write(s);
}

/// the start-up journal (userData/startup.log), also mirrored to logcat
pub fn blog(s: &str) {
    alog::write(s);
    let Some(a) = APP.get() else { return };
    let f = a.data.join("startup.log");
    if let Ok(m) = std::fs::metadata(&f) {
        if m.len() > 256_000 {
            if let Ok(t) = std::fs::read_to_string(&f) {
                let keep = crate::js::slice_end(&t, 64_000);
                let _ = std::fs::write(&f, keep);
            }
        }
    }
    let line = format!(
        "{} [{}] {}\n",
        chrono::Utc::now().format("%Y-%m-%dT%H:%M:%S%.3fZ"),
        std::process::id(),
        s
    );
    use std::io::Write;
    if let Ok(mut fh) = std::fs::OpenOptions::new().create(true).append(true).open(&f) {
        let _ = fh.write_all(line.as_bytes());
    }
}

/* ---------- single flight: one running job per key, every caller gets its result ---------- */
pub type Job = Shared<BoxFuture<'static, R<Value>>>;

pub struct Jobs {
    m: Mutex<HashMap<String, Job>>,
}
impl Jobs {
    pub fn new() -> Jobs {
        Jobs { m: Mutex::new(HashMap::new()) }
    }
    pub fn has(&self, key: &str) -> bool {
        self.m.lock().unwrap().contains_key(key)
    }
    pub fn get(&self, key: &str) -> Option<Job> {
        self.m.lock().unwrap().get(key).cloned()
    }
    pub fn run<F>(&'static self, key: &str, f: impl FnOnce() -> F) -> Job
    where
        F: Future<Output = R<Value>> + Send + 'static,
    {
        let mut m = self.m.lock().unwrap();
        if let Some(j) = m.get(key) {
            return j.clone();
        }
        let k2 = key.to_string();
        let fut = f();
        let job: Job = async move {
            let r = fut.await;
            self.m.lock().unwrap().remove(&k2);
            r
        }
        .boxed()
        .shared();
        m.insert(key.to_string(), job.clone());
        drive(&job);
        job
    }
}

/// a JS promise runs by itself: the shared job is polled to the end even when every caller stopped waiting
pub fn drive(job: &Job) {
    let j = job.clone();
    tokio::spawn(async move {
        let _ = j.await;
    });
}

pub fn shared<F>(f: F) -> Job
where
    F: Future<Output = R<Value>> + Send + 'static,
{
    let j = f.boxed().shared();
    drive(&j);
    j
}

/// `settings.data[k]`
pub fn setting(k: &str) -> Value {
    app().settings.lock().g(k).clone()
}
pub fn enabled(k: &str) -> bool {
    app().settings.lock().g("sources").g(k) != &Value::Bool(false)
}

pub fn err(m: &str) -> E {
    E::new(m)
}

/// 4.20.1: the interface's localStorage, kept on disk (see the «kv-all» / «kv-set» commands)
pub fn webstore() -> std::sync::Arc<crate::store::Store> {
    static W: std::sync::OnceLock<std::sync::Arc<crate::store::Store>> = std::sync::OnceLock::new();
    W.get_or_init(|| crate::store::Store::open(p("webstorage.json"), serde_json::json!({}))).clone()
}
